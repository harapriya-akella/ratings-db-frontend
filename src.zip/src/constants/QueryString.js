export const StrToObject = (queryString) => {
    console.log(queryString);
    if(queryString!==''){
        var pairs = queryString.slice(1).split('&')
        var query = {};
        pairs.forEach(function(pair) {
            pair = pair.split('=');
            query[pair[0]] = decodeURIComponent(pair[1] || '');
        });

        return query;
    }else{
        return null;
    }
}