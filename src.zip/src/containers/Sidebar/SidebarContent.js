import React, { Component } from "react";
import { connect } from "react-redux";
import { Menu, Icon } from "antd";
import { Link } from "react-router-dom";

import CustomScrollbars from "util/CustomScrollbars";
import SidebarLogo from "./SidebarLogo";

import Auxiliary from "util/Auxiliary";
import UserProfile from "./UserProfile";
import {
  NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR,
  NAV_STYLE_NO_HEADER_MINI_SIDEBAR,
  THEME_TYPE_LITE
} from "../../constants/ThemeSetting";
import IntlMessages from "../../util/IntlMessages";

const SubMenu = Menu.SubMenu;

class SidebarContent extends Component {

  getNoHeaderClass = (navStyle) => {
    if (navStyle === NAV_STYLE_NO_HEADER_MINI_SIDEBAR || navStyle === NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR) {
      return "gx-no-header-notifications";
    }
    return "";
  };
  getNavStyleSubMenuClass = (navStyle) => {
    if (navStyle === NAV_STYLE_NO_HEADER_MINI_SIDEBAR) {
      return "gx-no-header-submenu-popup";
    }
    return "";
  };

  render() {
    const { themeType, navStyle, pathname } = this.props;
    const selectedKeys = pathname.substr(1);
    const defaultOpenKeys = selectedKeys.split('/')[1];
    return (<Auxiliary>

      <SidebarLogo />
      <div className="gx-sidebar-content">
        <div className={`gx-sidebar-notifications ${this.getNoHeaderClass(navStyle)}`}>
          <UserProfile />
          {/* <AppsNavigation/> */}
        </div>
        <CustomScrollbars className="gx-layout-sider-scrollbar">
          <Menu
            defaultOpenKeys={[defaultOpenKeys]}
            selectedKeys={[selectedKeys]}
            theme={themeType === THEME_TYPE_LITE ? 'lite' : 'dark'}
            mode="inline"
          >
            <Menu.Item key="dashboard">
              <Link to="/dashboard"><Icon type="dashboard"></Icon>
                <IntlMessages id="Dashboard"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="user">
              <Link to="/user"><Icon type="user-add" />
                <IntlMessages id="User"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="analysis">
              <Link to="/analysis"><Icon type="edit" />
                <IntlMessages id="Analysis"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="emailData">
              <Link to="/emaildata?id=1"><Icon type="edit" />
                <IntlMessages id="Listings"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="emailalertlist">
              <Link to="/emailalertlist"><Icon type="edit" />
                <IntlMessages id="Alerts List"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="createalerts">
              <Link to="/createalerts"><Icon type="edit" />
                <IntlMessages id="Create Alerts"></IntlMessages>
              </Link>
            </Menu.Item>
            <Menu.Item key="newdevelopmentprojects">
              <Link to="/newdevelopmentprojects"><Icon type="edit" />
                <IntlMessages id="New Projects"></IntlMessages>
              </Link>
            </Menu.Item>
            <SubMenu key="sub1" title="Miscellaneous">
              <Menu.Item key="titles">
                <Link to="/titles"><Icon type="edit" />
                  <IntlMessages id="Titles"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="akas">
                <Link to="/akas"><Icon type="edit" />
                  <IntlMessages id="Akas"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="names">
                <Link to="/names"><Icon type="edit" />
                  <IntlMessages id="Names"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="principals">
                <Link to="/principals"><Icon type="edit" />
                  <IntlMessages id="Principals"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="crews">
                <Link to="/crews"><Icon type="edit" />
                  <IntlMessages id="Crews"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="episodes">
                <Link to="/episodes"><Icon type="edit" />
                  <IntlMessages id="Episodes"></IntlMessages>
                </Link>
              </Menu.Item>
              <Menu.Item key="ratings">
                <Link to="/ratings"><Icon type="edit" />
                  <IntlMessages id="Ratings"></IntlMessages>
                </Link>
              </Menu.Item>
            </SubMenu>
          </Menu>
        </CustomScrollbars>
      </div>
    </Auxiliary>
    );
  }
}

SidebarContent.propTypes = {};
const mapStateToProps = ({ settings }) => {
  const { navStyle, themeType, locale, pathname } = settings;
  return { navStyle, themeType, locale, pathname }
};
export default connect(mapStateToProps)(SidebarContent);

