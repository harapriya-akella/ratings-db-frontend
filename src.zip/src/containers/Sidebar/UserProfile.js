import React, {Component} from "react";
import {connect} from "react-redux";
import {Avatar, Popover} from "antd";
import {userSignOut} from "appRedux/actions/Auth";
import HttpService from "../../services/httpService";
import { getRandomColor, createImageFromInitials } from './../../routes/Components/utils'
class UserProfile extends Component {
  httpService;
  constructor() {
    super();
    this.httpService = new HttpService();
    this.state = {
      profile_pic : '',
      user_name : ''
    }
  }
  componentDidMount() {
    var ID = localStorage.getItem('user_id')
    console.log("ID ---> CHECK", ID);
    this.httpService.post("user/list", { id: ID })
    .then(res => {
      if (res.status === 1) {
        console.log("res-> SIDE", res.data)
        this.setState({
          // profile_pic : res.data[0].profile_pic,
          user_name : res.data[0].first_name,
          last_name : res.data[0].last_name
      })
      } else {
        console.log("status = 0")
      }
    })
  }
  render() {
    const {authUser} = this.props;
    console.log("authUser", authUser)
    const userMenuOptions = (
      <ul className="gx-user-popover">
        <a href = "my_account"><li>My Account</li></a>
        {/* <li>Connections</li> */}
        <li onClick={() => this.props.userSignOut()}>Logout
        </li>
      </ul>
    );

    return (
      <div className="gx-flex-row gx-align-items-center gx-mb-4 gx-avatar-row">
        <Popover placement="bottomRight" content={userMenuOptions} trigger="click">
          <Avatar src = {createImageFromInitials(500, this.state.user_name + ' ' + this.state.last_name, getRandomColor())}
          // src='https://via.placeholder.com/150x150'
                  className="gx-size-40 gx-pointer gx-mr-3" alt=""/>
                  {/* {this.state.user_name} */}
                  {/* <IntlMessages id="Dashboard"></IntlMessages> */}
          <span className="gx-avatar-name">{authUser ? this.state.user_name : "Loading"}<i
            className="icon icon-chevron-down gx-fs-xxs gx-ml-2"/></span>
        </Popover>
      </div>
    )
  }
}

const mapStateToProps = ({auth}) => {
  const {authUser} = auth;
  return {authUser}
};

export default connect(mapStateToProps, {userSignOut})(UserProfile);
