import React from "react";
import { Button, Form, Input } from "antd";
import { connect } from "react-redux";

import { userSignIn } from "../appRedux/actions/Auth";
import IntlMessages from "util/IntlMessages";
import InfoView from "components/InfoView";

const FormItem = Form.Item;

class SignIn extends React.Component {

  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log("values", values);
      // return
      if (!err) {
        this.props.userSignIn(values);
      }
    });
  };

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  componentDidUpdate() {
    if (this.props.authUser !== null) {
      this.props.history.push('/');
    }
  }


  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      // <div>

      <div className="gx-app-login-wrap">
        <div className="gx-app-login-container" style={{ width: 200, height: 50, marginBottom: 20 }}>
          <img alt="example" src={require("assets/images/goqu.png")} />
        </div>
        <div className="gx-app-login-container">
          <div className="gx-app-login-main-content">
            <div className="gx-app-logo-content">
              {/* <div className="gx-app-logo-content-bg"> */}
              <div style={{
                Content: "", position: "absolute", left: 0, top: 0, zIndex: 0, right: 0, bottom: 0, backgroundColor: "#A53963"
                // position: absolute;
                // left: 0;
                // top: 0;
                // z-index: 1;
                // right: 0;
                // bottom: 0;
                // background-color: rgba(3, 143, 222, 0.7)
              }}>
                {/* <img src = "https://www.npci.org.in/sites/default/files/npci-logo_0.png" width = "100" height = "100"/> */}
                {/* <img src="https://via.placeholder.com/272x395" alt='Neature'/> */}
                {/* <img alt="example" src={require("assets/images/unnamed.jpg")} /> */}

              </div>
              <div className="gx-app-logo-wid">
                <h1><IntlMessages id="app.userAuth.signIn" /></h1>
                <p><IntlMessages id="app.userAuth.bySigning" /></p>
                <p><IntlMessages id="app.userAuth.getAccount" /></p>
              </div>
              <div className="gx-app-logo">
                {/* <img alt="example" src={require("assets/images/goqu.png")} /> */}

                {/* <img alt="" width="100px" src="https://www.npci.org.in/sites/default/files/npci-logo_0.png" /> */}

              </div>
            </div>
            <div className="gx-app-login-content">
              <Form onSubmit={this.handleSubmit} className="gx-signin-form gx-form-row0">
                <FormItem>
                  {getFieldDecorator('email', {
                    initialValue: "himanshu.chanda@gmail.com",
                    rules: [{
                      required: true, type: 'email', message: 'The input is not valid E-mail!',
                    }],
                  })(
                    <Input placeholder="Email" />
                  )}
                </FormItem>
                <FormItem>
                  {getFieldDecorator('password', {
                    initialValue: "password",
                    rules: [{ required: true, message: 'Please input your Password!' }],
                  })(
                    <Input.Password placeholder="Password" />
                  )}
                </FormItem>
                {/* <FormItem>
                  {getFieldDecorator('remember', {
                    valuePropName: 'checked',
                    initialValue: true,
                  })(
                    <Checkbox><IntlMessages id="appModule.iAccept"/></Checkbox>
                  )}
                  <span className="gx-signup-form-forgot gx-link"><IntlMessages
                    id="appModule.termAndCondition"/></span>
                </FormItem> */}
                <FormItem>
                  <Button className="gx-mb-0" style={{ backgroundColor: "#4A3A8D", color: "white" }} htmlType="submit">
                    {/* <IntlMessages id="Sign In" /> */}
                    <IntlMessages id="app.userAuth.signIn" />
                  </Button>
                  {/* <span><IntlMessages id="app.userAuth.or"/></span> <Link to="/signup"><IntlMessages */}
                  {/* id="app.userAuth.signUp"/></Link> */}
                </FormItem>
                {/* <span
                  className="gx-text-light gx-fs-sm"> demo user email: 'demo@example.com' and password: 'demo#123'</span> */}
              </Form>
            </div>
            <InfoView />
          </div>
        </div>
      </div>

      /* </div> */
    );
  }
}

const WrappedNormalLoginForm = Form.create()(SignIn);

const mapStateToProps = ({ auth }) => {
  const { userDetail, authUser } = auth;
  return { userDetail, authUser }
};

export default connect(mapStateToProps, { userSignIn })(WrappedNormalLoginForm);
