import React, { Component } from "react";
import { Button, Card, Form, Input, message } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { StrToObject } from "../../constants/QueryString";
import HttpService from "../../services/httpService";
import { user_edit } from "../../appRedux/actions/User";

const FormItem = Form.Item;

class SamplePage extends Component {
    httpService;
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            confirmDirty: false,
            autoCompleteResult: [],
            logoFileList : [],
            first_name : '',
            last_name : '',
            // phone_number : '',
            email : '',
        };
    }
    componentDidMount() {
        const { location } = this.props.routing;
        var query = StrToObject(location.search);
        console.log('query', query)
        if (query) {
            this.httpService.post("user/list", { id: query.id })
            .then(res => {
                if (res.status === 1) {
                    console.log("user ret", res.data)
                    message.success("User data found")
                    this.setState({
                        first_name : res.data[0].first_name,
                        last_name : res.data[0].last_name,
                        // phone_number : res.data[0].phone_number,
                        email : res.data[0].email,
                    })
                    this.props.form.setFieldsValue({
                        first_name: this.state.first_name,
                        last_name: this.state.last_name,
                        // phone_number: this.state.phone_number,
                        email: this.state.email,
                    });
                } else {
                    message.error(res.message)
                }
            })
            .catch(err => {
                message.error(err)
            })
        } else {
            message.error("User ID not provided")
        }
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFieldsAndScroll((err, values) => {
          //console.log(values);
          if (!err) {
            let formData = new FormData();
            for ( var key in values ) {
              if(key === 'profile_pic'){
              }else{
                //console.log(key);
                formData.append(key, values[key]);
              }
            }
            if(this.state.logoFileList.length > 0){
              formData.append("profile_pic", this.state.logoFileList[0].originFileObj);
            }
            // console.log('Received values of form: ', values);
            const { location } = this.props.routing;
            var query = StrToObject(location.search);
            var dataValues = {
                id : query.id,
                first_name : this.props.form.getFieldValue("first_name"),
                last_name : this.props.form.getFieldValue("last_name"),
                // phone_number : this.props.form.getFieldValue("phone_number"),
                email : this.props.form.getFieldValue("email"), 
              }
              console.log("dataValues",dataValues)
              this.props.user_edit(dataValues);
            //   this.props.history.push('/user');
            //   window.location.reload(false)
          }
        });
    }
    handleConfirmBlur = e => {
        const { value } = e.target;
        this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    };
    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('password')) {
          callback('Two passwords that you enter is inconsistent!');
        } else {
          callback();
        }
    };
    validateToNextPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && this.state.confirmDirty) {
          form.validateFields(['confirm'], { force: true });
        }
        callback();
    };
    componentDidUpdate(prevProps,prevState){
        if(this.props.success){
            this.props.history.push('/user');
        }
    }
    render() {

        const { getFieldDecorator } = this.props.form;
        // const { autoCompleteResult } = this.state;

        const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 8 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 16 },
        },
        };
        const tailFormItemLayout = {
        wrapperCol: {
            xs: {
            span: 24,
            offset: 0,
            },
            sm: {
            span: 16,
            offset: 8,
            },
        },
        };

        return (
        <div className="ant-row">
            <div className="ant-col ant-col-sm-24 ant-col-md-24 ant-col-lg-24 ant-col-xl-24">
            <Card className="gx-card" title = "Edit User">
                <Form onSubmit={this.handleSubmit}>
                    <FormItem {...formItemLayout} label={(<span>
                        First Name &nbsp;
                    </span>
                    )}
                    >
                        {getFieldDecorator('first_name', {
                        rules: [{ required: true, message: 'Please enter first name', whitespace: true }],
                        })(
                        <Input placeholder="First Name" />
                        )}
                    </FormItem>
                    <FormItem {...formItemLayout} label={(<span>
                        Last Name &nbsp;
                    </span>
                    )}
                    >
                        {getFieldDecorator('last_name', {
                        rules: [{ required: true, message: 'Please enter last name', whitespace: true }],
                        })(
                        <Input placeholder="Last Name" />
                        )}
                    </FormItem>
                    {/* <FormItem
                        {...formItemLayout}
                        label={(
                            <span>
                            Phone Number&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('phone_number', {
                            rules: [{required: true, message: 'Enter Phone Number', whitespace: true, 'pattern' : '[0-9]{10}'}],
                        })(
                            <Input></Input>
                        )}
                    </FormItem> */}
                    <FormItem
                        {...formItemLayout}
                        label={(
                            <span>
                            Email&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('email', {
                            rules: [{required: true, message: 'Enter email', whitespace: true, email : true}],
                        })(
                            <Input></Input>
                        )}
                    </FormItem>
                    <FormItem {...tailFormItemLayout}>
                        <Link to = {"/user"} className = "btn">Cancel</Link>
                        <Button style={{ backgroundColor: "#4A3A8D", color: "white" }} htmlType="submit">Update</Button>
                    </FormItem>
                </Form>
            </Card>
            </div>
        </div>
        );
    }
}

const RegistrationForm = Form.create()(SamplePage);
const mapStateToProps = ({userList, routing}) => {
    const { success } = userList
    return { routing, success }
};

export default connect(mapStateToProps, {
    user_edit
})(RegistrationForm);
// export default RegistrationForm;