import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Row, Menu, Dropdown } from "antd";
import HttpService from "../../services/httpService";

const { Meta } = Card;

class SamplePage extends Component {
    httpService;
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            html: "",
            loading: true,
        }
    }
    componentDidMount() {
        this.setState({ ...this.state, html: this.props.location.state.html })
        this.httpService.post2("search/create_html", { html: this.props.location.state.html })
            .then(res => {
                console.log("RESULTS", res);
                if (res.status == 1) {
                    this.setState({ ...this.state, loading: false })
                }
            })
            .catch(error => {
                console.log(error);
            })
    }

    render() {
        const { loading } = this.state;
        return (
            <div>
                <Card style={{ height: '1000' }} loading={loading}>
                    <a href="http://139.59.18.134/tpub/htmlfiles/index.html" target="_blank"><Button style={{ background: "#a42e63", color: "white" }}>View HTML page</Button></a>
                    <Button href="/scraper" style={{ background: "white", color: "grey", float: "right" }}>Go back</Button>
                    <hr></hr>
                    {this.state.html}
                </Card>
                {/* <Card>
                    
                </Card> */}
            </div>
        );
    }
}

export default SamplePage