import React, { Component } from "react";
import { Modal, Form, Button } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { CSVLink } from 'react-csv';
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const d = new Date();
var today = monthNames[d.getMonth()] + d.getDate()
class SamplePage extends Component {
    httpService;
    constructor(props) {
        super(props);
        this.httpService = new HttpService();
        this.state = {
            today_date: today,
            excel_name: "",
            analysis_to_download: [],
            disabled: true,
            isModalVisible: false,
            message: "Please wait while we fetch the data...",
        }
    }
    componentDidMount() {
        var id = this.props.location.search.split("=")[1]
        if (localStorage.getItem("filter_is_set_for_new_projects") === "true" || localStorage.getItem("filter_is_set_for_analysis") === "true") {
            this.setState({ isModalVisible: true })
            if (id == 1) {
                var url = "analysis/get-data-for-excel-download"
                var filters = localStorage.getItem("filters_analysis")
            } else if (id == 2) {
                var url = "analysis/new-development-projects-for-excel"
                var filters = localStorage.getItem("filters_new_projects")
            } else {
                window.location.href = "/dashboard"
            }
            this.httpService.post(url, filters)
                .then(res => {
                    if (id == 1) {
                        localStorage.setItem('filter_is_set_for_analysis', false);
                        this.setState({ ...this.state, excel_name: "RatingsDB_" + this.state.today_date + ".csv" })
                    } else if (id == 2) {
                        localStorage.setItem('filter_is_set_for_new_projects', false);
                        this.setState({ ...this.state, excel_name: "NewProjectsDB_" + this.state.today_date + ".csv" })
                    }
                    this.setState({
                        ...this.state,
                        analysis_to_download: res.data_without,
                        disabled: false,
                        message: "Data is ready. Please click the Export CSV button."
                    })
                })
                .catch(err => {
                    this.setState({
                        ...this.state,
                        titles: 0
                    })
                })
        } else {
            window.location.href = "/dashboard"
        }
    }
    showModal = () => {
        this.setState({
            ...this.state,
            isModalVisible: true
        })
    };

    handleOk = () => {
        this.setState({
            ...this.state,
            isModalVisible: false
        })
        window.close();
    };

    handleCancel = () => {
        this.setState({
            ...this.state,
            isModalVisible: false
        })
        window.close();
    };
    render() {
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24" >
                        <Modal title={this.state.message} visible={this.state.isModalVisible} onOk={this.handleOk} onCancel={this.handleCancel}>
                            <Button style={{ backgroundColor: "#a42e63", color: "white" }} disabled={this.state.disabled} onClick={this.handleCancel} >
                                <CSVLink filename={this.state.excel_name} data={this.state.analysis_to_download} >
                                    Export CSV
                                </CSVLink>
                            </Button>
                        </Modal>
                    </div>
                </div>
            </div>
        );
    }
}
const RegistrationForm = Form.create()(SamplePage);
export default connect()(RegistrationForm)