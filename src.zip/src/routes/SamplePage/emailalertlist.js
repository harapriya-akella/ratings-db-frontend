import React, { Component, Fragment } from "react";
import { Button, Card, Table, Form, Menu, Dropdown, notification, Radio } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { Link } from "react-router-dom";
import { user_list_success, user_list, user_delete, reset_state } from "../../appRedux/actions/User";
import moment from "moment";
import IntlMessages from "../../util/IntlMessages";
import SweetAlert from "react-bootstrap-sweetalert/lib/dist/SweetAlert";

class SamplePage extends Component {
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            delete: false,
            id: '',
            number: 0,
            title: 'Email alerts',
            list: [],
            limit: 50,
            offset: 0,
            columns_detailed_view_rating: [],
            columns_detailed_view_votes: [],
            loader: true,
            delete_id: ""
        }
    }
    handleDelete = (ID) => {
        console.log("ID", ID);
        this.setState({
            delete: true,
            delete_id: ID
        })
    }
    onConfirmDelete = () => {
        this.setState({
            delete: false,
            loader: true
        })
        this.httpService.post("emailalerts/remove", { email_id: this.state.delete_id })
            .then(res => {
                if (res.status == 1) {
                    notification.info({
                        message: "Success",
                        description: "Alert deleted successfully.",
                        placement: 'topRight',
                    });
                    this.setState({
                        delete_id: "",
                        list: res.data,
                        loader: false
                    })
                }
            })
            .catch(err => {
                console.log(err);
            })
    }

    onCancelDelete = () => {
        this.setState({
            delete: false,
            id: '',
        });
    }

    componentDidMount() {
        var id = this.props.location.search.split("=")[1]
        if (id) {
            // >1 point Rating growth
            this.setState({
                title: ">1 point Rating growth Listing"
            })
            this.httpService.post("emailalerts/list", { email_id: id })
                .then(res => {
                    this.setState({
                        list: res.data,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        } else {
            this.httpService.post("emailalerts/list")
                .then(res => {
                    this.setState({
                        list: res.data,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize,
            loader: true
        })
        // this.props.analysis_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
        this.httpService.post("analysis/list", {
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
            .then(res => {
                this.setState({
                    list: res.data,
                    analysis_count: res.count,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })

    }
    renderTableData() {
        return this.state.list.map((a, index) => {
            const { _id, name, frequency, created_on, next_date_of_fire } = a
            return ({ key: _id, name, frequency, created_on: moment(created_on).format("LLLL"), next_date_of_fire })
        })
    }

    render() {
        const columns = [
            { title: 'Alert Name', dataIndex: 'name', key: 'name', width: 200 },
            { title: 'Frequency (in days)', dataIndex: 'frequency', key: 'frequency', width: 200 },
            { title: 'Created On', dataIndex: 'created_on', key: 'created_on', width: 200 },
            {
                title: 'Action', key: 'action', render: (text, record) =>
                    <div>
                        <Button style={{ backgroundColor: 'white', color: '#4A3A8D', borderColor: '#4A3A8D' }} onClick={() => { this.props.history.push("/createalerts?id=" + record.key) }}>Preview</Button>
                        <Button style={{ backgroundColor: 'white', color: '#e60000', borderColor: '#e60000' }} onClick={() => this.handleDelete(record.key)}>Delete</Button>
                    </div>
            }
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card title={this.state.title}>
                            <Table className="gx-table-responsive" loading={this.state.loader} columns={columns} dataSource={this.renderTableData()} />
                            <SweetAlert show={this.state.delete}
                                custom
                                showCancel
                                confirmBtnText={<IntlMessages id="button.yes" />}
                                cancelBtnText={<IntlMessages id="button.no" />}
                                confirmBtnBsStyle="primary"
                                cancelBtnBsStyle="default"
                                customIcon={require("./../../assets/del.svg")}
                                title="Are you sure you want to delete this email alert?"
                                onConfirm={this.onConfirmDelete}
                                onCancel={this.onCancelDelete}
                            ></SweetAlert>
                        </Card>
                    </div>
                </div>
            </div>
        );
    }

}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ userList }) => {
    const { users } = userList;
    console.log("userList", userList)
    return { users }
};

export default connect(mapStateToProps, {
    user_list,
    user_list_success,
    user_delete,
    reset_state
})(RegistrationForm)