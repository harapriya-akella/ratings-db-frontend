import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Row, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { Select } from 'antd';
import { languageList, countryList } from '../../appRedux/actions/Common';

import { Input } from 'antd';
import { InputNumber } from 'antd';
import { CSVLink, CSVDownload } from 'react-csv';
import moment from "moment";
import { Link } from "react-router-dom";

const { Option } = Select;
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const d = new Date();
var today = monthNames[d.getMonth()] + d.getDate()
class SamplePage extends Component {
    httpService;
    defaultFilters = {
        limit: 50,
        offset: 0,
        averageRating: "",
        numVotes: "",
        series_type: "",
        genres: "",
        title: "",
        startYear: "",
        startYearOperator: "",
        averageRatingOperator: "",
        numVotesOperator: "",
        sort_rating: "",
        sort_votes: "",
        sort_year: "",
        region: "",
        language: ""
    }
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            filter: this.defaultFilters,
            columns_detailed_view_rating: [],
            columns_detailed_view_votes: [],
            columns_three_week_view_rating: [],
            columns_three_week_view_votes: [],

            is_detailed_view: false,
            is_three_week_view: true,
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',

            analysis: '',
            delete: false,
            id: '',
            analysis: [],
            analysis_count: 0,

            analysis_to_download: [],
            todays_date: "Analysis",
            loader: true,
            excel_name: "RatingsDB_" + today + ".csv",
            isModalVisible: false
        }
    }
    componentDidMount() {
        this.props.languageList();
        this.props.countryList();
        this.httpService.post("analysis/new-development-projects", this.state.filter)
            .then(res => {
                this.setState({
                    analysis: res.data,
                    analysis_count: res.count,
                    loader: false
                })
            })
            .catch(err => {
            })
        // this.httpService.post("analysis/new-development-projects-for-excel")
        //     .then(res => {
        //         this.setState({
        //             analysis_to_download: res.data,
        //             loader: false
        //         })
        //     })
        //     .catch(err => {
        //         this.setState({
        //             titles: 0
        //         })
        //     })
    }
    handleTableChange = (pagination) => {
        this.setState({
            ...this.state,
            filter: {
                ...this.defaultFilters, limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize
            },
            loader: true
        }, () => {
            console.log("FILTERS", this.state.filter);
            this.httpService.post("analysis/new-development-projects", this.state.filter)
                .then(res => {
                    this.setState({
                        analysis: res.data,
                        analysis_count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    this.setState({
                        titles: 0
                    })
                })
        })
    }
    renderTableData() {
        return this.state.analysis.map((a, index) => {
            const { startYear, tconst, titleType, genres, region, language, primaryTitle } = a
            return (
                {
                    key: tconst, startYear, tconst: <a target="_blank" href={'https://www.imdb.com/title/' + tconst}>{tconst}</a>, titleType, genres: genres.replace(/,/g, ", "), region, language, primaryTitle
                }
            )
        })
    }
    onChangeFilterYear = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, startYear: value },
        })
    }
    onChangeFilterYearOperator = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, startYearOperator: value },
        })
    }
    onChangeFilterType = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, series_type: value },
        })
    }
    onChangeFilterGenre = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, genres: value },
        })
    }
    onChangeFilterTitle = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, title: value.target.value },
        })
    }
    onChangeFilterLanguage = (value) => {
        console.log("LANGUAGE", value);
        if (value == "all") {
            var lng = [];
            if (this.props.languages && this.props.languages.length > 0) {
                this.props.languages.map(ele => {
                    lng.push(ele.name);
                })
            }
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, language: lng },

            })
        } else {
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, language: value },
            })
        }
    }
    onChangeFilterRegion = (value) => {
        if (value == "all") {
            console.log("REGION", value);
            var rgn = [];
            if (this.props.countries && this.props.countries.length > 0) {
                this.props.countries.map(ele => {
                    rgn.push(ele.name);
                })
            }
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, region: rgn },
            })
        } else {
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, region: value },
            })
        }
    }
    handleFilterSubmit = () => {
        console.log("hello", moment(new Date).format("LTS"));
        this.setState({
            ...this.state,
            loader: true
        })
        this.httpService.post("analysis/new-development-projects", this.state.filter)
            .then(res => {
                console.log("hello-2", moment(new Date).format("LTS"));
                console.log("FILTERS", this.state.filter);
                this.setState({
                    ...this.state,
                    analysis: res.data,
                    analysis_count: res.count,
                    loader: false,
                })
            })
            .catch(err => {
                this.setState({
                    ...this.state,
                    titles: 0
                })
            })
    }
    handleClearFilter = () => {
        console.log("CLEAR FILTERS", moment(new Date()).format("LTS"));
        this.setState({
            ...this.state,
            loader: true,
            filter: this.defaultFilters
        }, () => {
            this.httpService.post("analysis/new-development-projects", this.state.filter)
                .then(res => {
                    console.log("CLEAR FILTERS-2", moment(new Date()).format("LTS"));
                    this.setState({
                        ...this.state,
                        analysis: res.data,
                        analysis_count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    this.setState({
                        ...this.state,
                        titles: 0
                    })
                })
        })
    }
    handleLocalStorage = () => {
        localStorage.setItem('filters_new_projects', JSON.stringify(this.state.filter));
        localStorage.setItem('filter_is_set_for_new_projects', true);
    }
    render() {
        const columns = [
            { title: 'Title ID', dataIndex: 'tconst', key: 'tconst', width: 110 },
            { title: 'Title', dataIndex: 'primaryTitle', key: 'primaryTitle', width: 150, sorter: (a, b) => a.primaryTitle.localeCompare(b.primaryTitle), },
            { title: 'Year', dataIndex: 'startYear', key: 'startYear', width: 80, sorter: (a, b) => a.startYear - b.startYear },
            // { title: 'Rating', dataIndex: 'averageRating', key: 'averageRating', width: 80, sorter: (a, b) => a.averageRating - b.averageRating },
            // { title: 'Votes', dataIndex: 'numVotes', key: 'numVotes', width: 100, sorter: (a, b) => a.numVotes - b.numVotes },
            { title: 'Type', dataIndex: 'titleType', key: 'titleType', width: 100, },
            { title: 'Genres', dataIndex: 'genres', key: 'genres', width: 150, },
            { title: 'Language', dataIndex: 'language', key: 'language', width: 250, },
            { title: 'Region', dataIndex: 'region', key: 'region', width: 250, },
        ];
        const layout = {
            labelCol: { span: 6 },
            wrapperCol: { span: 18 },
        };
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card>
                            <div className="ant-row">
                                <div className="ant-col-24" style={{ paddingBottom: 5 }}>
                                    <h4 style={{ color: "#545454" }}>Filters</h4>
                                </div>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingBottom: 5 }}>
                                        <Input placeholder="Search with Title" style={{ width: 300 }} onChange={this.onChangeFilterTitle} value={this.state.filter.title} />
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            style={{ width: 300 }}
                                            allowClear
                                            placeholder="Select Type"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterType}
                                            value={this.state.filter.series_type == "" ? [] : this.state.filter.series_type}
                                            filterOption={(input, option) =>
                                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                            <Option value="tvSeries">TV Series</Option>
                                            <Option value="tvMiniSeries">TV Mini Series</Option>
                                        </Select>
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            allowClear
                                            mode="multiple"
                                            style={{ width: 300 }}
                                            placeholder="Select Genres"
                                            optionFilterProp="children"
                                            value={this.state.filter.genres == "" ? [] : this.state.filter.genres}
                                            onChange={this.onChangeFilterGenre}
                                        >
                                            <Option value="all">All</Option>
                                            <Option value="News">News</Option>
                                            <Option value="Comedy">Comedy</Option>
                                            <Option value="Sport">Sport</Option>
                                            <Option value="Talk-Show">Talk-Show</Option>
                                            <Option value="Documentary">Documentary</Option>
                                            <Option value="Drama">Drama</Option>
                                            <Option value="Mystery">Mystery</Option>
                                            <Option value="Sci-Fi">Sci-Fi</Option>
                                            <Option value="Crime">Crime</Option>
                                            <Option value="Fantasy">Fantasy</Option>
                                            <Option value="Animation">Animation</Option>
                                            <Option value="Reality-TV">Reality-TV</Option>
                                            <Option value="Short">Short</Option>
                                            <Option value="Action">Action</Option>
                                            <Option value="Adventure">Adventure</Option>
                                            <Option value="Music">Music</Option>
                                            <Option value="Biography">Biography</Option>
                                            <Option value="Romance">Romance</Option>
                                            <Option value="Thriller">Thriller</Option>
                                            <Option value="History">History</Option>
                                            <Option value="Horror">Horror</Option>
                                            <Option value="Game-Show">Game-Show</Option>
                                            <Option value="Adult">Adult</Option>
                                            <Option value="Family">Family</Option>
                                            <Option value="War">War</Option>
                                            <Option value="Western">Western</Option>
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-10">
                                        <Select
                                            showSearch
                                            style={{ width: 465 }}
                                            allowClear
                                            mode="multiple"
                                            maxTagCount="3"
                                            placeholder="Select Language"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterLanguage}
                                            value={this.state.filter.language == "" ? [] : this.state.filter.language}
                                        >
                                            <Option value="all">Select all</Option>
                                            {this.props.languages && this.props.languages.length > 0 && this.props.languages.map(ele => (
                                                <Option value={ele.name} label={ele.name}>{ele.name}</Option>
                                            ))}
                                        </Select>
                                    </div>
                                    <div className="ant-col-2">
                                    </div>
                                    <div className="ant-col-12">
                                        <Select
                                            showSearch
                                            allowClear
                                            maxTagCount="3"
                                            mode="multiple"
                                            style={{ width: 465 }}
                                            placeholder="Select Region"
                                            optionFilterProp="children"
                                            value={this.state.filter.region == "" ? [] : this.state.filter.region}
                                            onChange={this.onChangeFilterRegion}
                                        >
                                            <Option value="all">Select all</Option>
                                            {this.props.countries && this.props.countries.length > 0 && this.props.countries.map(ele => (
                                                <Option value={ele.name} label={ele.name}>{ele.name}</Option>
                                            ))}
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_year"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Year">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.startYearOperator == "" ? [] : this.state.filter.startYearOperator}
                                                            onChange={this.onChangeFilterYearOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={2015} style={{ width: 150 }} onChange={this.onChangeFilterYear} value={this.state.filter.startYear} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ visibility: "hidden", paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_ratings"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Ratings">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.averageRatingOperator == "" ? [] : this.state.filter.averageRatingOperator}
                                                            onChange={this.onChangeFilterRatingOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} max={10} style={{ width: 150 }}
                                                            onChange={this.onChangeFilterRating}
                                                            value={this.state.filter.averageRating}
                                                        />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ visibility: "hidden", paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Votes">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.numVotesOperator == "" ? [] : this.state.filter.numVotesOperator}
                                                            onChange={this.onChangeFilterVotesOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} style={{ width: 150 }} onChange={this.onChangeFilterVotes} value={this.state.filter.numVotes} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                        </Form>
                                    </div>
                                </Row>
                                <div className="ant-col-8">
                                    <Button style={{ backgroundColor: 'white', color: '#a42e63', borderColor: '#a42e63' }} onClick={this.handleFilterSubmit} type="dashed">Apply Filters</Button>
                                    <Button style={{ backgroundColor: 'white', color: '#808080', borderColor: '#808080' }} onClick={this.handleClearFilter} type="dashed">Clear Filters</Button>
                                </div>
                            </div>
                        </Card>
                    </div>
                    {/*<Button style={{ backgroundColor: "#4A3A8D", color: "white" }}>
                                    <CSVLink filename={this.state.excel_name} data={this.state.analysis_to_download} >Export CSV</CSVLink>
                                </Button> */}
                    <div className="ant-col-24" >
                        <Card title="Not yet developed/released series"
                            extra={<div style={{ marginTop: 15, padding: 0 }}>
                                <Link to={{ pathname: "/export_data?id=2" }} onClick={this.handleLocalStorage} target="_blank">
                                    <Button style={{ backgroundColor: "#4A3A8D", color: "white" }}>
                                        Export CSV
                                    </Button>
                                </Link>

                            </div>
                            }>
                            <Table className="gx-table-responsive" loading={this.state.loader} columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.state.analysis_count, defaultCurrent: 1, defaultPageSize: 50, showTotal: (total => `Total ${total} items`) }} onChange={this.handleTableChange} scroll={{ x: 500, y: 500 }} sticky={true} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ commonData }) => {
    const { countries, languages } = commonData;
    return { countries, languages }
};

export default connect(mapStateToProps, {
    languageList,
    countryList
})(RegistrationForm)