import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";

import { principal_list_success, principal_list, principal_delete, reset_state } from "../../appRedux/actions/Principal";

class SamplePage extends Component {
    httpService;

    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            principals: 0,
            delete: false,
            id: '',
            offset: 0,
            limit: 10

        }
    }

    componentDidMount() {
        var userID = localStorage.getItem('user_id')
        this.httpService.post("user/dashboard", { user_id: userID })
            .then(res => {
                // console.log("res data dashboard")
                this.setState({
                    principals: res.data.principals
                })
            })
            .catch(err => {
                this.setState({
                    principals: 0
                })
            })
        this.props.reset_state();
        this.props.principal_list({ limit: this.state.limit, offset: this.state.offset });

        if (this.props.showMessage) {
            setTimeout(() => {
                this.props.hideMessage();
            }, 100);
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
        this.props.principal_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
    }
    
    renderTableData() {
        return this.props.principals.map((principal, index) => {
            const { tconst, ordering, nconst, category, job, characters } = principal
            return (
                {
                    key: tconst, tconst, ordering, nconst, category, job, characters
                }
            )
        })
    }
    render() {
        const columns = [
            { title: 'T Const', dataIndex: 'tconst', key: 'tconst' },
            { title: 'Ordering', dataIndex: 'ordering', key: 'ordering' },
            { title: 'N Const', dataIndex: 'nconst', key: 'nconst' },
            { title: 'Category', dataIndex: 'category', key: 'category' },
            { title: 'Job', dataIndex: 'job', key: 'job' },
            { title: 'Characters', dataIndex: 'characters', key: 'characters' }
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card title="Principal">
                            <Table className="gx-table-responsive" columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.props.principal_count, defaultCurrent: 1, defaultPageSize: 10 }} onChange={this.handleTableChange} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
    // https://stackoverflow.com/questions/58249361/handle-pagination-sorting-and-filtering-separately-in-antd-table-react
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ principalList }) => {
    const { principals, principal_count } = principalList;
    console.log("principals, principal_count", principals, principal_count);
    return { principals, principal_count }
};

export default connect(mapStateToProps, {
    principal_list,
    principal_list_success,
    principal_delete,
    reset_state
})(RegistrationForm)