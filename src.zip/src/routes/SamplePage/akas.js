import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";

import { akas_list_success, akas_list, akas_delete, reset_state } from "../../appRedux/actions/Akas";

class SamplePage extends Component {
    httpService;

    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            akases: 0,
            delete: false,
            id: '',
            offset: 0,
            limit: 10
        }
    }

    componentDidMount() {
        var userID = localStorage.getItem('user_id')
        this.httpService.post("user/dashboard", { user_id: userID })
            .then(res => {
                // console.log("res data dashboard")
                this.setState({
                    akases: res.data.akases
                })
            })
            .catch(err => {
                this.setState({
                    akases: 0
                })
            })
        this.props.reset_state();
        this.props.akas_list({ limit: this.state.limit, offset: this.state.offset });
        if (this.props.showMessage) {
            setTimeout(() => {
                this.props.hideMessage();
            }, 100);
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
        this.props.akas_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
    }
    renderTableData() {
        return this.props.akases.map((akas, index) => {
            const { titleId, ordering, title, region, language, types, attributes, isOriginalTitle } = akas
            return (
                {
                    key: titleId, titleId, ordering, title, region, language, types, attributes, isOriginalTitle
                }
            )
        })
    }
    render() {
        const columns = [
            { title: 'Title ID', dataIndex: 'titleId', key: 'titleId' },
            { title: 'Ordering', dataIndex: 'ordering', key: 'ordering' },
            { title: 'Title', dataIndex: 'title', key: 'title' },
            { title: 'Region', dataIndex: 'region', key: 'region' },
            { title: 'Language', dataIndex: 'language', key: 'language' },
            { title: 'Types', dataIndex: 'types', key: 'types' },
            { title: 'Attributes', dataIndex: 'attributes', key: 'attributes' },
            { title: 'Is Original Title', dataIndex: 'isOriginalTitle', key: 'isOriginalTitle' }
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card title="Akas">
                            <Table className="gx-table-responsive" columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.props.akas_count, defaultCurrent: 1, defaultPageSize: 10 }} onChange={this.handleTableChange} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
    // https://stackoverflow.com/questions/58249361/handle-pagination-sorting-and-filtering-separately-in-antd-table-react
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ akasList }) => {
    const { akases, akas_count } = akasList;
    console.log("akases, akas_count", akases, akas_count);

    return { akases, akas_count }
};

export default connect(mapStateToProps, {
    akas_list,
    akas_list_success,
    akas_delete,
    reset_state
})(RegistrationForm)