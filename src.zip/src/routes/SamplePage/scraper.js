import React, { Component } from "react";
import { Card, Table, Form, Tooltip, Input, Button } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { user_list_success, user_list, user_delete, reset_state } from "../../appRedux/actions/User";
import { Link } from "react-router-dom";
import moment from "moment";

const { Search } = Input;

class SamplePage extends Component {
    defaultParams = {
        limit: 10,
        offset: 0,
        search: ""
    }
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            filters: this.defaultParams,
            title: 'List of websites scraped',
            list: [],
            columns: [],
            loader: true,
        }
    }

    componentDidMount() {
        this.httpService.post2("search/list", this.state.filters)
            .then(res => {
                this.setState({
                    list: res.data,
                    count: res.count,
                    loader: false
                })
            })
            .catch(err => {
                console.log(err);
            })
    }


    onSearch = (value) => {
        this.setState({
            ...this.state,
            filters: { ...this.state.filters, search: value.target.value },
        })
    }

    handleTableChange = (pagination) => {
        this.setState({
            ...this.state,
            filters: {
                ...this.defaultFilters, limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize
            },
            loader: true
        }, () => {
            this.httpService.post2("search/list", this.state.filters)
                .then(res => {
                    this.setState({
                        ...this.state,
                        list: res.data,
                        count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    this.setState({
                        titles: 0
                    })
                })
        })
        // this.props.analysis_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
    }

    handleSearch = () => {
        this.setState({
            ...this.state,
            loader: true
        }, () => {
            this.httpService.post2("search/list", this.state.filters)
                .then(res => {
                    this.setState({
                        ...this.state,
                        list: res.data,
                        count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    this.setState({
                        titles: 0
                    })
                })
        })
    }

    renderTableData() {
        return this.state.list.map((a, index) => {
            const { _id, Article_Body_Link_On_Local, Article_Headline, Article_Link, Article_Text, Created_On, Date_of_publication, Meta_Keywords } = a
            return ({
                key: _id, index: index + 1, Article_Body_Link_On_Local, Article_Text, Created_On, Meta_Keywords, Date_of_publication: moment(Date_of_publication).format("lll"), Website: "C21Media",
                Article_Headline:
                    <Tooltip title={Article_Headline}>
                        {Article_Headline.substring(0, 100)}
                    </Tooltip>,
                Article_Link:
                    <Tooltip title={Article_Link}>
                        <a target="_blank" href={Article_Link}>
                            <img src="https://img.icons8.com/nolan/64/link.png" width={18} />
                            URL
                        </a>
                    </Tooltip>
            })
        })
    }

    render() {
        const columns = [
            { title: 'S.No.', dataIndex: 'index', key: 'index' },
            { title: 'Website', dataIndex: 'Website', key: 'Website' },
            { title: 'Title', dataIndex: 'Article_Headline', key: 'Article_Headline' },
            { title: 'Scraped On', dataIndex: 'Date_of_publication', key: 'Date_of_publication' },
            { title: 'Link', dataIndex: 'Article_Link', key: 'Article_Link' },
            {
                title: 'View', key: 'action', render: (text, record) =>
                    <div>
                        <a target="_blank" href={record.Article_Link}>
                            <Link to={{ pathname: "/website_html", state: { html: record.Article_Text } }}>
                                <img src="https://img.icons8.com/nolan/64/visible.png" width={25} />
                            </Link>
                        </a>
                    </div>
            },
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-12">
                        <Input placeholder="Search with..." allowClear style={{ width: 500, marginBottom: 10 }} onChange={this.onSearch} ></Input>
                    </div>
                    <div className="ant-col-12">
                        <Button style={{ background: "#a42e63", color: "white" }} onClick={this.handleSearch} >Search</Button>
                    </div>
                    <div className="ant-col-24">
                        <Card title={this.state.title}>
                            <Table className="gx-table-responsive" loading={this.state.loader} columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.state.count, defaultCurrent: 1, defaultPageSize: this.state.filters.limit, showTotal: (total => `Total ${total} items`) }} onChange={this.handleTableChange} scroll={{ x: 500, y: 500 }} sticky={true} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }

}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ userList }) => {
    const { users } = userList;
    console.log("userList", userList)
    return { users }
};

export default connect(mapStateToProps, {
    user_list,
    user_list_success,
    user_delete,
    reset_state
})(RegistrationForm)