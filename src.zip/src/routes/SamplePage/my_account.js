import React, { Component, Fragment } from "react";
import { Form, Card, Button, message, Avatar } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import HttpService from "../../services/httpService";
import { getRandomColor, createImageFromInitials } from '../Components/utils'

class SamplePage extends Component {
    httpService;
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            user_id: ''
        }
    }
    componentDidMount() {
        this.setState({
            user_id: localStorage.getItem('user_id')
        })
        this.httpService.post("user/list", { id: localStorage.getItem('user_id') })
            .then(res => {
                if (res.status === 1) {
                    console.log("user ret", res.data)
                    this.setState({
                        first_name: res.data[0].first_name,
                        last_name: res.data[0].last_name,
                        // phone_number: res.data[0].phone_number,
                        email: res.data[0].email,
                        // profile_pic: res.data[0].profile_pic
                    })
                    this.props.form.setFieldsValue({
                        first_name: this.state.first_name,
                        last_name: this.state.last_name,
                        // phone_number: this.state.phone_number,
                        email: this.state.email,
                    });
                } else {
                    message.error(res.message)
                }
            })
            .catch(err => {
                message.error(err)
            })
    }
    // 500, "HIMANSHU CHANDA", "#4a3a8d"
    render() {
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card style={{ textAlign: 'center' }}>
                            <Fragment>
                                <Link to={"/user_password?id=" + this.state.user_id}><Button shape="round">Change password</Button></Link>
                                <Link to={"/user_edit?id=" + this.state.user_id}><Button shape="round">Change details</Button></Link>
                                {/* <Link to={"/user_profile?id=" + this.state.user_id}><Button shape="round">Change profile pic</Button></Link> */}
                            </Fragment>
                            <Card>
                                <Fragment>
                                    <Avatar src={createImageFromInitials(500, this.state.first_name + ' ' + this.state.last_name, getRandomColor())} size={180}></Avatar>
                                    <div>
                                        <h3><li style={{ paddingTop: '10px' }}>Name : {this.state.first_name + ' ' + this.state.last_name}</li></h3>
                                        <h3><li style={{ paddingTop: '10px' }}>Email ID : {this.state.email}</li></h3>
                                        {/* <h3><li style={{ paddingTop: '10px' }}>Phone Number : {this.state.phone_number}</li></h3> */}
                                    </div>
                                </Fragment>
                            </Card>
                        </Card>

                    </div>
                </div>
            </div>
        );
    }
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ routing }) => {
    return { routing }
};

export default connect(mapStateToProps, {
})(RegistrationForm)