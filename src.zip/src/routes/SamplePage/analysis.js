import React, { Component, Fragment } from "react";
import { Modal, Form, Button, Table, Card, Row, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { Link } from "react-router-dom";
import { analysis_list_success, analysis_list, analysis_delete, reset_state } from "../../appRedux/actions/Analysis";
import { languageList, countryList } from '../../appRedux/actions/Common';
import { Select } from 'antd';
import { Input } from 'antd';
import { InputNumber } from 'antd';
import { CSVLink, CSVDownload } from 'react-csv';
import moment from "moment";
import utf8 from "utf8"
const { Option } = Select;
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const d = new Date();
var today = monthNames[d.getMonth()] + d.getDate()
class SamplePage extends Component {
    httpService;
    defaultFilters = {
        limit: 50,
        offset: 0,
        averageRating: "",
        numVotes: "",
        series_type: "",
        genres: "",
        title: "",
        startYear: "",
        startYearOperator: "",
        averageRatingOperator: "",
        numVotesOperator: "",
        sort_rating: "",
        sort_votes: "",
        sort_year: "",
        region: "",
        language: ""
    }
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            filter: this.defaultFilters,
            columns_detailed_view_rating: [],
            columns_detailed_view_votes: [],
            columns_three_week_view_rating: [],
            columns_three_week_view_votes: [],

            is_detailed_view: false,
            is_three_week_view: true,
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',

            analysis: '',
            delete: false,
            id: '',
            analysis: [],
            analysis_count: 0,

            analysis_to_download: [],
            todays_date: "Analysis",
            loader: true,
            excel_name: "RatingsDB_" + today + ".csv",
            maxYear: 2022,
            isModalVisible: false
        }
    }
    componentDidMount() {
        //Call masters//
        this.props.languageList();
        this.props.countryList();

        this.httpService.post("user/dashboard")
            .then(res => {
                this.setState({
                    todays_date: "Analysis Data Last Updated on " + moment(res.data.todays_date).format("LLL")
                })
            })
            .catch(err => {
                this.setState({
                    todays_date: "Analysis Data"
                })
            })
        this.httpService.get("analysis/get-columns")
            .then(res => {
                this.setState({
                    columns_detailed_view_rating: res.columns_detailed_view.rating_columns,
                    columns_detailed_view_votes: res.columns_detailed_view.votes_columns,
                    columns_three_week_view_rating: res.columns_three_week_view.rating_columns,
                    columns_three_week_view_votes: res.columns_three_week_view.votes_columns
                })
            })
            .catch(err => {
                console.log(err);
            })
        this.httpService.post("analysis/list", this.state.filter)
            .then(res => {
                console.log("res.data", res.data);
                this.setState({
                    ...this.state,
                    analysis: res.data,
                    analysis_count: res.count,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    ...this.state,
                    titles: 0
                })
            })
        if (this.props.showMessage) {
            setTimeout(() => {
                this.props.hideMessage();
            }, 100);
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            ...this.state,
            filter: {
                ...this.defaultFilters, limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize
            },
            loader: true
        }, () => {
            this.httpService.post("analysis/list", this.state.filter)
                .then(res => {
                    this.setState({
                        ...this.state,
                        analysis: res.data,
                        analysis_count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    this.setState({
                        ...this.state,
                        titles: 0
                    })
                })
        })
    }
    renderTableData() {
        return this.state.analysis.map((a, index) => {
            const { startYear, tconst, alternateTitle, main_language, main_country, titleType, averageRating, numVotes, genres, region, language, primaryTitle, week1_rating, week2_rating, week3_rating, week4_rating, week5_rating, week6_rating, week7_rating, week8_rating, week9_rating, week10_rating, week11_rating, week12_rating, week13_rating, week14_rating, week15_rating, week16_rating, week17_rating, week18_rating, week19_rating, week20_rating, week21_rating, week22_rating, week23_rating, week24_rating, week25_rating, week26_rating, week27_rating, week28_rating, week29_rating, week30_rating, week31_rating, week32_rating, week33_rating, week34_rating, week35_rating, week36_rating, week37_rating, week38_rating, week39_rating, week40_rating, week41_rating, week42_rating, week43_rating, week44_rating, week45_rating, week46_rating, week47_rating, week48_rating, week49_rating, week50_rating, week1_votes, week2_votes, week3_votes, week4_votes, week5_votes, week6_votes, week7_votes, week8_votes, week9_votes, week10_votes, week11_votes, week12_votes, week13_votes, week14_votes, week15_votes, week16_votes, week17_votes, week18_votes, week19_votes, week20_votes, week21_votes, week22_votes, week23_votes, week24_votes, week25_votes, week26_votes, week27_votes, week28_votes, week29_votes, week30_votes, week31_votes, week32_votes, week33_votes, week34_votes, week35_votes, week36_votes, week37_votes, week38_votes, week39_votes, week40_votes, week41_votes, week42_votes, week43_votes, week44_votes, week50_votes
            } = a
            return (
                {
                    key: tconst,
                    // alternateTitle: alternateTitle.map((line) => <div><a className="alternatetitle" target="_blank" href={'https://www.imdb.com/title/' + tconst + '/releaseinfo?ref_=tt_dt_dt#akas'}>{this.utfDecoding(line)}</a></div>), 
                    startYear, tconst: <a target="_blank" href={'https://www.imdb.com/title/' + tconst}>{tconst}</a>, titleType, averageRating, numVotes, genres: genres[0].replace(/,/g, ", "), region, language, main_language, main_country, primaryTitle: this.utfDecoding(primaryTitle), week1_rating, week2_rating, week3_rating, week4_rating, week5_rating, week6_rating, week7_rating, week8_rating, week9_rating, week10_rating, week11_rating, week12_rating, week13_rating, week14_rating, week15_rating, week16_rating, week17_rating, week18_rating, week19_rating, week20_rating, week21_rating, week22_rating, week23_rating, week24_rating, week25_rating, week26_rating, week27_rating, week28_rating, week29_rating, week30_rating, week31_rating, week32_rating, week33_rating, week34_rating, week35_rating, week36_rating, week37_rating, week38_rating, week39_rating, week40_rating, week41_rating, week42_rating, week43_rating, week44_rating,
                    week45_rating, week46_rating, week47_rating, week48_rating, week49_rating, week50_rating, week1_votes, week2_votes, week3_votes, week4_votes, week5_votes, week6_votes, week7_votes, week8_votes, week9_votes,
                    week10_votes, week11_votes, week12_votes, week13_votes, week14_votes, week15_votes, week16_votes, week17_votes, week18_votes, week19_votes, week20_votes, week21_votes, week22_votes, week23_votes, week24_votes, week25_votes, week26_votes, week27_votes, week28_votes, week29_votes, week30_votes, week31_votes, week32_votes, week33_votes, week34_votes, week35_votes, week36_votes, week37_votes, week38_votes, week39_votes, week40_votes, week41_votes, week42_votes, week43_votes, week44_votes, week50_votes
                }
            )
        })
    }
    utfDecoding = (title) => {
        try {
            var pt = (title == '0.03') ? '3%' : utf8.decode(title)
        } catch {
            var pt = (title == '0.03') ? '3%' : title
        }
        return pt
    }
    onChangeFilterYear = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, startYear: value },
        })
    }
    onChangeFilterYearOperator = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, startYearOperator: value },
        })
    }
    onChangeFilterRating = (value) => {
        console.log("value", value);
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, averageRating: value },
        })
    }
    onChangeFilterRatingOperator = (value) => {
        console.log("value", value);
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, averageRatingOperator: value },
        })
    }
    onChangeFilterVotes = (value) => {
        this.setState({
            filter: { ...this.state.filter, numVotes: value },
        })
    }
    onChangeFilterVotesOperator = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, numVotesOperator: value },
        })
    }
    onChangeFilterType = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, series_type: value },
        })
    }
    onChangeFilterGenre = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, genres: value },
        })
    }
    onChangeFilterTitle = (value) => {
        this.setState({
            ...this.state,
            filter: { ...this.state.filter, title: value.target.value },
        })
    }
    onChangeFilterLanguage = (value) => {
        console.log("LANGUAGE", value);
        if (value == "all") {
            var lng = [];
            if (this.props.languages && this.props.languages.length > 0) {
                this.props.languages.map(ele => {
                    lng.push(ele.name);
                })
            }
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, language: lng },

            })
        } else {
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, language: value },
            })
        }
    }
    onChangeFilterRegion = (value) => {
        if (value == "all") {
            console.log("REGION", value);
            var rgn = [];
            if (this.props.countries && this.props.countries.length > 0) {
                this.props.countries.map(ele => {
                    rgn.push(ele.name);
                })
            }
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, region: rgn },
            })
        } else {
            this.setState({
                ...this.state,
                filter: { ...this.state.filter, region: value },
            })
        }
    }
    handleDetailedView = () => {
        this.setState({
            loader: true
        })
        console.log("handleDetailedView");
        this.setState({
            ...this.state,
            is_detailed_view: true,
            is_three_week_view: false,
            backgroud_button_three_week_view: '#ab959f',
            backgroud_button_detailed_view: '#a42e63',
            loader: false
        })
    }
    handleThreeWeekView = () => {
        this.setState({
            loader: true
        })
        console.log("handleThreeWeekView");
        this.setState({
            ...this.state,
            is_detailed_view: false,
            is_three_week_view: true,
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',
            loader: false
        })
    }
    onChangeSortYear = (sortOrder) => {
        console.log("herer", sortOrder)
        if (sortOrder == "ascend") {
            if (!this.state.year_ascending) { //false
                this.setState(prevState => ({
                    year_ascending: true,
                    sort_year: "from_2015_to_now"
                }));
            }
        }
        if (sortOrder == "descend") {
            if (!this.state.year_descending) { //false
                this.setState(prevState => ({
                    year_descending: true,
                    sort_year: "from_now_to_2015"
                }));
            }
        }
        return
    }
    handleFilterSubmit = () => {
        console.log("hello", moment(new Date).format("LTS"));
        this.setState({
            ...this.state,
            loader: true
        })
        this.httpService.post("analysis/list", this.state.filter)
            .then(res => {
                console.log("hello-2", moment(new Date).format("LTS"));
                this.setState({
                    ...this.state,
                    analysis: res.data,
                    analysis_count: res.count,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    ...this.state,
                    titles: 0
                })
            })
    }
    handleClearFilter = () => {
        console.log("CLEAR FILTERS", moment(new Date()).format("LTS"));
        this.setState({
            ...this.state,
            loader: true,
            filter: this.defaultFilters
        }, () => {
            this.httpService.post("analysis/list", this.state.filter)
                .then(res => {
                    console.log("CLEAR FILTERS-2", moment(new Date()).format("LTS"));
                    this.setState({
                        ...this.state,
                        analysis: res.data,
                        analysis_count: res.count,
                        loader: false
                    })
                    // this.httpService.post("analysis/get-data-for-excel-download", this.defaultFilters)
                    // .then(res => {
                    //     this.setState({
                    //         ...this.state,
                    //         analysis_to_download: res.data_without,
                    //     })
                    // })
                    // .catch(err => {
                    //     this.setState({
                    //         ...this.state,
                    //         titles: 0
                    //     })
                    // })
                })
                .catch(err => {
                    this.setState({
                        ...this.state,
                        titles: 0
                    })
                })
        })
    }
    handleExcelDownload = () => {
        console.log("handleExcelDownload");
        // this.httpService.post("analysis/get-data-for-excel-download", this.state.filter)
        //     .then(res => {
        //         this.setState({
        //             ...this.state,
        //             analysis_to_download: res.data_without,
        //         }, () => {
        //             this.downloadCSV()
        //         })
        //     })
        //     .catch(err => {
        //         this.setState({
        //             ...this.state,
        //             titles: 0
        //         })
        //     })
    }
    handleLocalStorage = () => {
        localStorage.setItem('filters_analysis', JSON.stringify(this.state.filter));
        localStorage.setItem('filter_is_set_for_analysis', true);
    }
    render() {
        var that = this
        const columns_detailed_view = [
            { title: 'Title ID', dataIndex: 'tconst', key: 'tconst', width: 110, fixed: 'left' },
            {
                title: 'Title',
                dataIndex: 'primaryTitle',
                key: 'primaryTitle',
                width: 150,
                // defaultSortOrder: 'ascend',
                sorter: (a, b) => a.primaryTitle.localeCompare(b.primaryTitle),
                fixed: 'left'
            },
            // {
            //     title: 'Alternate Titles',
            //     dataIndex: 'alternateTitle',
            //     key: 'alternateTitle',
            //     width: 250,
            // },
            {
                title: 'Year',
                dataIndex: 'startYear',
                key: 'startYear',
                // defaultSortOrder: 'descend',
                width: 100,
                setSortYear: function (sortOrder) {
                    that.onChangeSortYear(sortOrder)
                    return;
                    console.log("STATE", sortOrder);
                    if (sortOrder == "ascend" && that.state.sort_year == "from_now_to_2015" || sortOrder == "ascend" && that.state.sort_year == "") {
                        console.log("AAA", that.state.sort_year);
                        // ***
                        that.httpService.post("analysis/list", {
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_2015_to_now"
                        })
                            .then(res => {
                                console.log("res.data ===> ANALYSIS", res.count);
                                that.setState({
                                    analysis: res.data,
                                    analysis_count: res.count,
                                    analysis_to_download: res.data_without
                                })
                            })
                            .catch(err => {
                                that.setState({
                                    titles: 0
                                })
                            })
                        that.setState({
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_2015_to_now"
                        })
                        // ***
                    }
                    if (sortOrder == "descend" && that.state.sort_year == "from_2015_to_now") {
                        // that.setState({
                        //     sort_year: "from_now_to_2015",
                        //     sort_votes: "",
                        //     sort_rating: ""
                        // })
                        // ***
                        that.httpService.post("analysis/list", {
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_now_to_2015"
                        })
                            .then(res => {
                                console.log("res.data ===> ANALYSIS", res.count);
                                that.setState({
                                    analysis: res.data,
                                    analysis_count: res.count,
                                    analysis_to_download: res.data_without
                                })
                            })
                            .catch(err => {
                                that.setState({
                                    titles: 0
                                })
                            })
                        that.setState({
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_now_to_2015"
                        })
                        // ***
                    }
                },
                sorter: function (a, b, sortOrder) {
                    // this.setSortYear(sortOrder)
                    // console.log("that.state", that.state);
                    // console.log("STATE", sortOrder);

                    return a.startYear - b.startYear
                }
            },
            {
                title: 'Rating',
                dataIndex: 'averageRating',
                key: 'averageRating',
                width: 80,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {

                    return a.averageRating - b.averageRating
                }
            },
            {
                title: 'Votes',
                dataIndex: 'numVotes',
                key: 'numVotes',
                width: 100,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {
                    if (sortOrder == "ascend") {
                        this.setState({
                            sort_votes: "from_6_to_10",
                            sort_year: "",
                            sort_rating: ""
                        })
                    } else if (sortOrder == "descend") {
                        this.setState({
                            sort_votes: "from_10_to_6",
                            sort_year: "",
                            sort_rating: ""
                        })
                    } else {
                        this.setState({
                            sort_votes: "",
                            sort_year: "",
                            sort_rating: ""
                        })
                    }
                    console.log(sortOrder);
                    return a.numVotes - b.numVotes
                }
            },
            { title: 'Type', dataIndex: 'titleType', key: 'titleType', width: 100, },
            { title: 'Genres', dataIndex: 'genres', key: 'genres', width: 120, },
            { title: 'Language', dataIndex: 'main_language', key: 'main_language', width: 250, },
            { title: 'Region', dataIndex: 'main_country', key: 'main_country', width: 250, },
        ];
        this.state.columns_detailed_view_rating.forEach(element => {
            columns_detailed_view.push(element)
        });
        this.state.columns_detailed_view_votes.forEach(element => {
            columns_detailed_view.push(element)
        });
        const columns_three_week_view = [
            { title: 'Title ID', dataIndex: 'tconst', key: 'tconst', width: 110, fixed: 'left' },
            {
                title: 'Title',
                dataIndex: 'primaryTitle',
                key: 'primaryTitle',
                width: 150,
                // defaultSortOrder: 'ascend',
                sorter: (a, b) => a.primaryTitle.localeCompare(b.primaryTitle), fixed: 'left'
            },
            // {
            //     title: 'Alternate Titles',
            //     dataIndex: 'alternateTitle',
            //     key: 'alternateTitle',
            //     width: 250,
            // },
            {
                title: 'Year',
                dataIndex: 'startYear',
                key: 'startYear',
                // defaultSortOrder: 'descend',
                width: 100,
                setSortYear: function (sortOrder) {
                    that.onChangeSortYear(sortOrder)
                    return;
                    console.log("STATE", sortOrder);
                    if (sortOrder == "ascend" && that.state.sort_year == "from_now_to_2015" || sortOrder == "ascend" && that.state.sort_year == "") {
                        console.log("AAA", that.state.sort_year);
                        // ***
                        that.httpService.post("analysis/list", {
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_2015_to_now"
                        })
                            .then(res => {
                                console.log("res.data ===> ANALYSIS", res.count);
                                that.setState({
                                    analysis: res.data,
                                    analysis_count: res.count,
                                    analysis_to_download: res.data_without
                                })
                            })
                            .catch(err => {
                                that.setState({
                                    titles: 0
                                })
                            })
                        that.setState({
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_2015_to_now"
                        })
                        // ***
                    }
                    if (sortOrder == "descend" && that.state.sort_year == "from_2015_to_now") {
                        // that.setState({
                        //     sort_year: "from_now_to_2015",
                        //     sort_votes: "",
                        //     sort_rating: ""
                        // })
                        // ***
                        that.httpService.post("analysis/list", {
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_now_to_2015"
                        })
                            .then(res => {
                                console.log("res.data ===> ANALYSIS", res.count);
                                that.setState({
                                    analysis: res.data,
                                    analysis_count: res.count,
                                    analysis_to_download: res.data_without
                                })
                            })
                            .catch(err => {
                                that.setState({
                                    titles: 0
                                })
                            })
                        that.setState({
                            limit: that.state.limit,
                            offset: that.state.offset,
                            averageRating: that.state.averageRating,
                            numVotes: that.state.numVotes,
                            series_type: that.state.series_type,
                            genres: that.state.genres,
                            title: that.state.title,
                            startYear: that.state.startYear,
                            sort_rating: that.state.sort_rating,
                            sort_votes: that.state.sort_votes,
                            sort_year: "from_now_to_2015"
                        })
                        // ***
                    }
                },
                sorter: function (a, b, sortOrder) {
                    // this.setSortYear(sortOrder)
                    // console.log("that.state", that.state);
                    // console.log("STATE", sortOrder);

                    return a.startYear - b.startYear
                }
            },
            {
                title: 'Rating',
                dataIndex: 'averageRating',
                key: 'averageRating',
                width: 80,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {

                    return a.averageRating - b.averageRating
                }
            },
            {
                title: 'Votes',
                dataIndex: 'numVotes',
                key: 'numVotes',
                width: 100,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {
                    if (sortOrder == "ascend") {
                        this.setState({
                            sort_votes: "from_6_to_10",
                            sort_year: "",
                            sort_rating: ""
                        })
                    } else if (sortOrder == "descend") {
                        this.setState({
                            sort_votes: "from_10_to_6",
                            sort_year: "",
                            sort_rating: ""
                        })
                    } else {
                        this.setState({
                            sort_votes: "",
                            sort_year: "",
                            sort_rating: ""
                        })
                    }
                    console.log(sortOrder);
                    return a.numVotes - b.numVotes
                }
            },
            { title: 'Type', dataIndex: 'titleType', key: 'titleType', width: 100, },
            { title: 'Genres', dataIndex: 'genres', key: 'genres', width: 120, },
            { title: 'Language', dataIndex: 'main_language', key: 'main_language', width: 250, },
            { title: 'Region', dataIndex: 'main_country', key: 'main_country', width: 250, },
        ]
        this.state.columns_three_week_view_rating.forEach(element => {
            columns_three_week_view.push(element)
        });
        this.state.columns_three_week_view_votes.forEach(element => {
            columns_three_week_view.push(element)
        });
        const layout = {
            labelCol: { span: 6 },
            wrapperCol: { span: 18 },
        };
        const tailLayout = {
            wrapperCol: { offset: 8, span: 16 },
        };
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card>
                            <div className="ant-row">
                                <div className="ant-col-24" style={{ paddingBottom: 5 }}>
                                    <h4 style={{ color: "#545454" }}>Filters</h4>
                                </div>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingBottom: 5 }}>
                                        <Input placeholder="Search with Title" style={{ width: 300 }} onChange={this.onChangeFilterTitle} value={this.state.filter.title} />
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            style={{ width: 300 }}
                                            allowClear
                                            placeholder="Select Type"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterType}
                                            value={this.state.filter.series_type == "" ? [] : this.state.filter.series_type}
                                            filterOption={(input, option) =>
                                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                            <Option value="tvSeries">TV Series</Option>
                                            <Option value="tvMiniSeries">TV Mini Series</Option>
                                        </Select>
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            allowClear
                                            mode="multiple"
                                            style={{ width: 300 }}
                                            placeholder="Select Genres"
                                            optionFilterProp="children"
                                            value={this.state.filter.genres == "" ? [] : this.state.filter.genres}
                                            onChange={this.onChangeFilterGenre}
                                        >
                                            <Option value="all">All</Option>
                                            <Option value="News">News</Option>
                                            <Option value="Comedy">Comedy</Option>
                                            <Option value="Sport">Sport</Option>
                                            <Option value="Talk-Show">Talk-Show</Option>
                                            <Option value="Documentary">Documentary</Option>
                                            <Option value="Drama">Drama</Option>
                                            <Option value="Mystery">Mystery</Option>
                                            <Option value="Sci-Fi">Sci-Fi</Option>
                                            <Option value="Crime">Crime</Option>
                                            <Option value="Fantasy">Fantasy</Option>
                                            <Option value="Animation">Animation</Option>
                                            <Option value="Reality-TV">Reality-TV</Option>
                                            <Option value="Short">Short</Option>
                                            <Option value="Action">Action</Option>
                                            <Option value="Adventure">Adventure</Option>
                                            <Option value="Music">Music</Option>
                                            <Option value="Biography">Biography</Option>
                                            <Option value="Romance">Romance</Option>
                                            <Option value="Thriller">Thriller</Option>
                                            <Option value="History">History</Option>
                                            <Option value="Horror">Horror</Option>
                                            <Option value="Game-Show">Game-Show</Option>
                                            <Option value="Adult">Adult</Option>
                                            <Option value="Family">Family</Option>
                                            <Option value="War">War</Option>
                                            <Option value="Western">Western</Option>
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-10">
                                        <Select
                                            showSearch
                                            style={{ width: 465 }}
                                            allowClear
                                            mode="multiple"
                                            maxTagCount="3"
                                            placeholder="Select Language"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterLanguage}
                                            value={this.state.filter.language == "" ? [] : this.state.filter.language}
                                        >
                                            <Option value="all">Select all</Option>
                                            {this.props.languages && this.props.languages.length > 0 && this.props.languages.map(ele => (
                                                <Option value={ele.name} label={ele.name}>{ele.name}</Option>
                                            ))}
                                        </Select>
                                    </div>
                                    <div className="ant-col-2">
                                    </div>
                                    <div className="ant-col-12">
                                        <Select
                                            showSearch
                                            allowClear
                                            maxTagCount="3"
                                            mode="multiple"
                                            style={{ width: 465 }}
                                            placeholder="Select Region"
                                            optionFilterProp="children"
                                            value={this.state.filter.region == "" ? [] : this.state.filter.region}
                                            onChange={this.onChangeFilterRegion}
                                        >
                                            <Option value="all">Select all</Option>
                                            {this.props.countries && this.props.countries.length > 0 && this.props.countries.map(ele => (
                                                <Option value={ele.name} label={ele.name}>{ele.name}</Option>
                                            ))}
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_year"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Year">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.startYearOperator == "" ? [] : this.state.filter.startYearOperator}
                                                            onChange={this.onChangeFilterYearOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={2015} max={this.state.maxYear} style={{ width: 150 }} onChange={this.onChangeFilterYear} value={this.state.filter.startYear} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_ratings"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Ratings">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.averageRatingOperator == "" ? [] : this.state.filter.averageRatingOperator}
                                                            onChange={this.onChangeFilterRatingOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} max={10} style={{ width: 150 }}
                                                            onChange={this.onChangeFilterRating}
                                                            value={this.state.filter.averageRating}
                                                        />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Votes">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.filter.numVotesOperator == "" ? [] : this.state.filter.numVotesOperator}
                                                            onChange={this.onChangeFilterVotesOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} style={{ width: 150 }} onChange={this.onChangeFilterVotes} value={this.state.filter.numVotes} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                        </Form>
                                    </div>
                                </Row>
                                <div className="ant-col-8">
                                    <Button style={{ backgroundColor: 'white', color: '#a42e63', borderColor: '#a42e63' }} onClick={this.handleFilterSubmit} type="dashed">Apply Filters</Button>
                                    <Button style={{ backgroundColor: 'white', color: '#808080', borderColor: '#808080' }} onClick={this.handleClearFilter} type="dashed">Clear Filters</Button>
                                </div>
                            </div>
                        </Card>
                    </div>
                    <div className="ant-col-24" >
                        <Card title={this.state.todays_date}
                            extra={<div style={{ marginTop: 15, padding: 0 }}>
                                {/* light -> ab959f */}
                                {/*onClick={this.showModal} */}
                                {/* dark -> a42e63 */}
                                <Button style={{ backgroundColor: this.state.backgroud_button_three_week_view, color: "white" }} onClick={this.handleThreeWeekView}>3 Week View</Button>
                                <Button style={{ backgroundColor: this.state.backgroud_button_detailed_view, color: "white" }} onClick={this.handleDetailedView}>Detailed View</Button>
                                <Link to={{ pathname: "/export_data?id=1" }} onClick={this.handleLocalStorage} target="_blank">
                                    <Button style={{ backgroundColor: "#4A3A8D", color: "white" }}>
                                        Export CSV
                                    </Button>
                                </Link>
                            </div>
                            }>
                            {
                                this.state.is_three_week_view
                                    ?
                                    // showTotal={total => `Total ${total} items`}
                                    <Table className="gx-table-responsive" loading={this.state.loader} columns={columns_three_week_view} dataSource={this.renderTableData()} pagination={{ total: this.state.analysis_count, defaultCurrent: 1, defaultPageSize: 50, showTotal: (total => `Total ${total} items`) }} onChange={this.handleTableChange} scroll={{ x: 500, y: 500 }} sticky={true} />
                                    :
                                    this.state.is_detailed_view
                                        ?
                                        <Table className="gx-table-responsive" loading={this.state.loader} columns={columns_detailed_view} dataSource={this.renderTableData()} pagination={{ total: this.state.analysis_count, defaultCurrent: 1, defaultPageSize: 50 }} onChange={this.handleTableChange} scroll={{ x: 500, y: 500 }} sticky={true} />
                                        :
                                        null
                            }
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
}
const RegistrationForm = Form.create()(SamplePage);
const mapStateToProps = ({ analysisList, commonData }) => {
    const { analysis, analysis_count } = analysisList;
    const { countries, languages } = commonData;
    return { analysis, analysis_count, countries, languages }
};
export default connect(mapStateToProps, {
    analysis_list,
    analysis_list_success,
    analysis_delete,
    reset_state,
    languageList,
    countryList
})(RegistrationForm)