import React, { Component, Fragment } from "react";
import { Button, Card, Table, Form, Menu, Dropdown } from "antd";
import SweetAlert from "react-bootstrap-sweetalert";
import IntlMessages from "util/IntlMessages";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { Link } from "react-router-dom";
import { user_list_success, user_list, user_delete, reset_state } from "../../appRedux/actions/User";
import utf8 from "utf8"

class SamplePage extends Component {
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            delete: false,
            id: '',
            number: 0,
            title: '',
            list: [],
            limit: 50,
            offset: 0,
            columns_detailed_view_rating: [],
            columns_detailed_view_votes: [],
            loader: true,
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',
            margin_of_1: '#ab959f',
            above_500: '#ab959f',
            above_6: '#ab959f',
            below_6: '#ab959f'
        }
    }
    handleDelete = (ID) => {
        this.setState({
            delete: true,
            id: ID,
        });
    }
    onConfirmDelete = () => {
        this.props.user_delete(this.state.id);
        this.setState({
            delete: false,
            // warning_message: ''
        })
    }

    onCancelDelete = () => {
        this.setState({
            delete: false,
            id: '',
        });
    }

    componentDidMount() {
        this.httpService.get("analysis/get-columns")
            .then(res => {
                this.setState({
                    columns_detailed_view_rating: res.columns_detailed_view.rating_columns,
                    columns_detailed_view_votes: res.columns_detailed_view.votes_columns,
                    columns_three_week_view_rating: res.columns_three_week_view.rating_columns,
                    columns_three_week_view_votes: res.columns_three_week_view.votes_columns
                })
            })
            .catch(err => {
                console.log(err);
            })
        var id = this.props.location.search.split("=")[1]
        if (id == 1) {
            // >1 point Rating growth
            this.setState({
                title: ">1 point Rating growth Listing",
                margin_of_1: '#a42e63',
                above_500: '#ab959f',
                above_6: '#ab959f',
                below_6: '#ab959f'
            })
            this.httpService.get("unzip/margin_of_1")
                .then(res => {
                    this.setState({
                        list: res.data,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        } else if (id == 2) {
            //  > 6 Rating; >500 Votes
            this.setState({
                title: "> 6 Rating; >500 Votes Listing",
                margin_of_1: '#ab959f',
                above_500: '#a42e63',
                above_6: '#ab959f',
                below_6: '#ab959f'
            })
            this.httpService.get("unzip/above_500_votes")
                .then(res => {
                    this.setState({
                        list: res.data,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        } else if (id == 3) {
            // New entrants to 6+ Rating
            this.setState({
                title: "New entrants to 6+ Rating Listing",
                margin_of_1: '#ab959f',
                above_500: '#ab959f',
                above_6: '#a42e63',
                below_6: '#ab959f'
            })
            this.httpService.get("unzip/above_6", { limit: this.state.limit, offset: this.state.offset })
                .then(res => {
                    this.setState({
                        list: res.data,
                        //analysis_count: res.count,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        } else if (id == 4) {
            // Ratings drop from 6
            this.setState({
                title: "Ratings drop from 6 Listing",
                margin_of_1: '#ab959f',
                above_500: '#ab959f',
                above_6: '#ab959f',
                below_6: '#a42e63'
            })
            this.httpService.get("unzip/below_6")
                .then(res => {
                    this.setState({
                        list: res.data,
                        loader: false
                    })
                })
                .catch(err => {
                    console.log(err);
                })
        } else {
            this.setState({
                list: [],
                loader: false
            })
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize,
            loader: true
        })
        // this.props.analysis_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
        this.httpService.post("analysis/list", {
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
            .then(res => {
                this.setState({
                    list: res.data,
                    analysis_count: res.count,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })

    }
    renderTableData() {
        return this.state.list.map((a, index) => {
            const { startYear, tconst, titleType, averageRating, numVotes, genres, region, language, primaryTitle, week1_rating, week2_rating, week3_rating, week4_rating, week5_rating, week6_rating, week7_rating, week8_rating, week9_rating, week10_rating, week11_rating, week12_rating, week13_rating, week14_rating, week15_rating, week16_rating, week17_rating, week18_rating, week19_rating, week20_rating, week21_rating, week22_rating, week23_rating, week24_rating, week25_rating, week26_rating, week27_rating, week28_rating, week29_rating, week30_rating, week31_rating, week32_rating, week33_rating, week34_rating, week35_rating, week36_rating, week37_rating, week38_rating, week39_rating, week40_rating, week41_rating, week42_rating, week43_rating, week44_rating, week45_rating, week46_rating, week47_rating, week48_rating, week49_rating, week50_rating, week1_votes, week2_votes, week3_votes, week4_votes, week5_votes, week6_votes, week7_votes, week8_votes, week9_votes, week10_votes, week11_votes, week12_votes, week13_votes, week14_votes, week15_votes, week16_votes, week17_votes, week18_votes, week19_votes, week20_votes, week21_votes, week22_votes, week23_votes, week24_votes, week25_votes, week26_votes, week27_votes, week28_votes, week29_votes, week30_votes, week31_votes, week32_votes, week33_votes, week34_votes, week35_votes, week36_votes, week37_votes, week38_votes, week39_votes, week40_votes, week41_votes, week42_votes, week43_votes, week44_votes, week50_votes } = a
            return (
                {
                    key: tconst, startYear, tconst: <a target="_blank" href={'https://www.imdb.com/title/' + tconst}>{tconst}</a>, titleType, averageRating, numVotes, genres, region, language, primaryTitle: this.utfDecoding(primaryTitle), week1_rating, week2_rating, week3_rating, week4_rating, week5_rating, week6_rating, week7_rating, week8_rating, week9_rating, week10_rating, week11_rating, week12_rating, week13_rating, week14_rating, week15_rating, week16_rating, week17_rating, week18_rating, week19_rating, week20_rating, week21_rating, week22_rating, week23_rating, week24_rating, week25_rating, week26_rating, week27_rating, week28_rating, week29_rating, week30_rating, week31_rating, week32_rating, week33_rating, week34_rating, week35_rating, week36_rating, week37_rating, week38_rating, week39_rating, week40_rating, week41_rating, week42_rating, week43_rating, week44_rating,
                    week45_rating, week46_rating, week47_rating, week48_rating, week49_rating, week50_rating, week1_votes, week2_votes, week3_votes, week4_votes, week5_votes, week6_votes, week7_votes, week8_votes, week9_votes,
                    week10_votes, week11_votes, week12_votes, week13_votes, week14_votes, week15_votes, week16_votes, week17_votes, week18_votes, week19_votes, week20_votes, week21_votes, week22_votes, week23_votes, week24_votes, week25_votes, week26_votes, week27_votes, week28_votes, week29_votes, week30_votes, week31_votes, week32_votes, week33_votes, week34_votes, week35_votes, week36_votes, week37_votes, week38_votes, week39_votes, week40_votes, week41_votes, week42_votes, week43_votes, week44_votes, week50_votes
                }
            )
        })
    }
    utfDecoding = (title) => {
        try {
            var pt = (title == '0.03') ? '3%' : utf8.decode(title)
        } catch {
            var pt = (title == '0.03') ? '3%' : title
        }
        return pt
    }
    render() {
        const columns_detailed_view = [
            { title: 'Title ID', dataIndex: 'tconst', key: 'tconst', width: 110, fixed: 'left' },
            {
                title: 'Title',
                dataIndex: 'primaryTitle',
                key: 'primaryTitle',
                width: 150,
                fixed: 'left',
                // defaultSortOrder: 'ascend',
                sorter: (a, b) => a.primaryTitle.localeCompare(b.primaryTitle),
            },
            {
                title: 'Year',
                dataIndex: 'startYear',
                key: 'startYear',
                // defaultSortOrder: 'descend',
                width: 100,
                sorter: (a, b) => a.startYear - b.startYear
            },
            {
                title: 'Rating',
                dataIndex: 'averageRating',
                key: 'averageRating',
                width: 80,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {
                    return a.averageRating - b.averageRating
                }
            },
            {
                title: 'Votes',
                dataIndex: 'numVotes',
                key: 'numVotes',
                width: 100,
                // defaultSortOrder: 'descend',
                sorter: function (a, b, sortOrder) {
                    return a.numVotes - b.numVotes
                }
            },
            { title: 'Type', dataIndex: 'titleType', key: 'titleType', width: 100, },
            { title: 'Genres', dataIndex: 'genres', key: 'genres', width: 100, },
            { title: 'Language', dataIndex: 'language', key: 'language', width: 250, },
            { title: 'Region', dataIndex: 'region', key: 'region', width: 250, },
        ];
        this.state.columns_detailed_view_rating.forEach(element => {
            columns_detailed_view.push(element)
        });
        this.state.columns_detailed_view_votes.forEach(element => {
            columns_detailed_view.push(element)
        });
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Link to="/emaildata?id=1">
                            <Button style={{ background: this.state.margin_of_1, color: "white" }}>Margin of 1</Button>
                        </Link>
                        <Link to="/emaildata?id=2">
                            <Button style={{ background: this.state.above_500, color: "white" }}>Above 500 votes</Button>
                        </Link>
                        <Link to="/emaildata?id=3">
                            <Button style={{ background: this.state.above_6, color: "white" }}>Ratings above 6</Button>
                        </Link>
                        <Link to="/emaildata?id=4">
                            <Button style={{ background: this.state.below_6, color: "white" }}>Ratings below 6</Button>
                        </Link>
                    </div>
                    <div className="ant-col-24">
                        <Card title={this.state.title}>
                            <Table className="gx-table-responsive" loading={this.state.loader} columns={columns_detailed_view} dataSource={this.renderTableData()} scroll={{ x: 500, y: 500 }} sticky={true} pagination={{ total: this.state.analysis_count, defaultCurrent: 1, defaultPageSize: 50, showTotal: (total => `Total ${total} items`) }} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }

}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ userList }) => {
    const { users } = userList;
    console.log("userList", userList)
    return { users }
};

export default connect(mapStateToProps, {
    user_list,
    user_list_success,
    user_delete,
    reset_state
})(RegistrationForm)