import React, { Component } from "react";
import { Button, Card, Form, Input } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { StrToObject } from "../../constants/QueryString";
import { user_change_password } from "../../appRedux/actions/User";

const FormItem = Form.Item;

class SamplePage extends Component {
    constructor() {
        super();
        this.state = {
            confirmDirty: false,
            autoCompleteResult: [],
        };
    }
    
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFieldsAndScroll((err, values) => {
          //console.log(values);
          if (!err) {
            console.log('Received values of form: ', values);
            const { location } = this.props.routing;
            var query = StrToObject(location.search);
            var dataValues = {
                id : query.id,
                password : values.old_password,
                new_password : values.password, 
                repeat_password : values.repeat_password
            }
            console.log("dataValues", dataValues)
            this.props.user_change_password(dataValues)
            // this.props.history.push('/user');
          }
        });
    }
    componentDidUpdate(prevProps,prevState){
        if(this.props.success){
            this.props.history.push('/user');
        }
    }
    handleConfirmBlur = e => {
        const { value } = e.target;
        this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    };
    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('password')) {
          callback('Two passwords that you enter is inconsistent!');
        } else {
          callback();
        }
    };
    
    validateToNextPassword = (rule, value, callback) => {
    const { form } = this.props;
    if (value && this.state.confirmDirty) {
        form.validateFields(['confirm'], { force: true });
    }
    callback();
    };
    render() {

        const { getFieldDecorator } = this.props.form;
        // const { autoCompleteResult } = this.state;

        const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 8 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 16 },
        },
        };
        const tailFormItemLayout = {
        wrapperCol: {
            xs: {
            span: 24,
            offset: 0,
            },
            sm: {
            span: 16,
            offset: 8,
            },
        },
        };

        return (
        <div className="ant-row">
            <div className="ant-col ant-col-sm-24 ant-col-md-24 ant-col-lg-24 ant-col-xl-24">
            <Card className="gx-card" title = "Change password">
                <Form onSubmit={this.handleSubmit}>
                    <FormItem 
                        {...formItemLayout}
                        label={(
                            <span>
                            Old Password&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('old_password', {
                            rules: [
                            {
                                required: true,
                                message: 'Please input your old password!',
                            },
                            ],
                        })(<Input.Password />)}
                    </FormItem>
                    <FormItem hasFeedback
                        {...formItemLayout}
                        label={(
                            <span>
                            New Password&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('password', {
                            rules: [
                            {
                                required: true,
                                message: 'Please input new password!',
                            },
                            {
                                validator: this.validateToNextPassword,
                            },
                            ],
                        })(<Input.Password />)}
                    </FormItem>
                    <FormItem hasFeedback
                        {...formItemLayout}
                        label={(
                            <span>
                            Confirm Password&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('repeat_password', {
                            rules: [
                            {
                                required: true,
                                message: 'Please confirm your password!',
                            },
                            {
                                validator: this.compareToFirstPassword,
                            },
                            ],
                        })(<Input.Password onBlur={this.handleConfirmBlur} />)}
                    </FormItem>
                    <FormItem {...tailFormItemLayout}>
                        <Link to = {"/user"} className = "btn">Cancel</Link>
                        <Button style={{ backgroundColor: "#4A3A8D", color: "white" }} htmlType="submit">Update</Button>
                    </FormItem>
                </Form>
            </Card>
            </div>
        </div>
        );
    }
}

const RegistrationForm = Form.create()(SamplePage);
const mapStateToProps = ({routing, userList}) => {
    const { success } = userList
    return{ routing, success }
};

export default connect(mapStateToProps, {
    user_change_password
})(RegistrationForm);
// export default RegistrationForm;