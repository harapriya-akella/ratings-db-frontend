import React, { Component } from "react";
import { Col, Row, Card, Table, Progress } from "antd";
import '@fortawesome/fontawesome-free/css/all.min.css';
import PropTypes from "prop-types";
import Metrics from "components/Metrics";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import moment from "moment";
import { Tooltip } from 'antd';
import { Link } from "react-router-dom";
const columns = [
  { title: 'Full Name', dataIndex: 'full_name', key: 'full_name' },
  { title: 'Date of Birth', dataIndex: 'dob', key: 'dob' },
  { title: 'Contact Number', dataIndex: 'mobile_number', key: 'mobile_number' },
  { title: 'Zone', dataIndex: 'zone', key: 'zone' },
  { title: 'Joined since', dataIndex: 'created_on', key: 'created_on' },
];
class SamplePage extends Component {
  httpService;
  constructor() {
    super();
    this.httpService = new HttpService();
    this.state = {
      titles: 0,
      akases: 0,
      names: 0,
      principals: 0,
      crews: 0,
      ratings: 0,
      episodes: 0,
      todays_date: '',
      margin_of_1: 0,
      above_500_votes: 0,
      above_6: 0,
      below_6: 0,
      scraper_count: 0
    }
  }
  componentDidMount() {
    var userID = localStorage.getItem('user_id')
    this.httpService.post("user/dashboard", { user_id: userID })
      .then(res => {
        console.log("res data dashboard PRINCIPAL==============> ", res.data)
        this.setState({
          titles: res.data.titles,
          margin_of_1: res.data.margin_of_1,
          above_500_votes: res.data.above_500_votes,
          above_6: res.data.above_6,
          below_6: res.data.below_6,
          todays_date: 'ALERTS REQUIRED BY ACQUISITION TEAM- Data Last Updated on ' + moment(res.data.todays_date).format("LLL"),
          above_6_list: res.data.above_6_list,
          above_7_list: res.data.above_7_list,
          merge_tv_series_list: res.data.merge_tv_series_list
        })
      })
      .catch(err => {
        this.setState({
          titles: 0,
          margin_of_1: 0,
          above_500_votes: 0,
          above_6: 0,
          below_6: 0,
          todays_date: 'ALERTS REQUIRED BY ACQUISITION TEAM '
        })
      })
    this.httpService.get2("search/count")
      .then(res => {
        this.setState({
          scraper_count: res.count,
        })
      })
      .catch(err => {
        console.log(err);
      })
  }
  renderTableData() {
    console.log("this.state.employees_table", this.state.employees_table)
    return this.state.employees_table.map((empl, index) => {
      console.log("empl===>", empl)
      console.log("surveys", this.state.survey_chart)
      const { id, first_name, last_name, mobile_number, zone, dob, created_on } = empl //destructuring
      return (
        {
          key: id,
          full_name: first_name + " " + last_name,
          mobile_number,
          // email,
          zone,
          dob: moment(dob).format('MMMM Do, YYYY'),
          created_on: moment(created_on).format('MMMM Do, YYYY')
        }
      )
    })
  }
  // const data = [
  //   { name: 'YES', Employees: 200 },
  //   { name: 'NO', Employees: 500 },
  // ];
  renderSurvey() {
    console.log("this.props.surveys", this.props.surveys)
    return this.state.survey_chart.map((survey, index) => {
      console.log("survey===>", survey)
      const { id, question, poll_end, created_on, first_name, last_name, answers } = survey //destructuring
      var s = moment(created_on).format('DD-MM-YYYY')
      var e = moment(poll_end).format('DD-MM-YYYY')
      return (
        {
          key: id,
          question,
          answer_poll: answers,
          poll_start: s,
          poll_end: e,
          raised_by: first_name + ' ' + last_name,
          // zone
        }
      )
    })
  }
  render() {
    const Widget = ({ title, children, styleName, cover, extra, actions }) => {
      return (
        <Card title={title} actions={actions} cover={cover} className={`gx-card-widget ${styleName}`} extra={extra}>
          {children}
        </Card>
      )
    };
    Widget.defaultProps = {
      styleName: '',
    };
    Widget.propTypes = {
      title: PropTypes.node,
      extra: PropTypes.node,
      cover: PropTypes.node,
      actions: PropTypes.node,
      children: PropTypes.node.isRequired
    };
    const IconWithTextCard = ({ cardColor, icon, title, subTitle, iconColor, description }) => {
      return (
        <Widget styleName={`gx-card-full gx-p-3 gx-bg-${cardColor} gx-text-white`}>
          <div className="gx-media gx-align-items-center gx-flex-nowrap">
            <div className="gx-media-body text-right">
              <h3 className="gx-mb-1 gx-text-white">{title}</h3>
              <p className="gx-mb-0 gx-fs-xxl " style={{ fontSize: '50px' }} >{subTitle}</p>
              <p className="gx-mb-0 gx-fs-xxl" style={{ fontSize: '15px' }}><i>{description}</i></p>
            </div>
            <div className="gx-mr-2 gx-mr-xxl-3">
              <i className={`fas fa-${icon} gx-fs-icon-lg`} />
              <img alt="" src={`${icon}`}></img>
            </div>
          </div>
        </Widget>
      );
    };
    const CustomCard = ({ title, subtitle, icon, number, description }) => {
      return (
        <Tooltip title={`${description}`} placement="bottom">
          <Card title={`${title}`} headStyle={{ color: 'white', background: '#a42e63', textAlign: "center" }} style={{ borderRadius: '20px', boxShadow: '0px 0px 5px 0px lightgrey' }}>
            <Row gutter={16}>
              <Col span={8} md={12} xs={12}>
                <Row gutter={8} style={{ padding: '0' }} >
                  <Col span={12} style={{ paddingTop: '3.2px' }} >
                    <img alt="" src={`${icon}`}></img>
                  </Col>
                  <Col span={12} style={{ padding: '0' }}>
                    <h1 style={{ fontSize: '30px' }}>{number}</h1>
                  </Col>
                </Row>
              </Col>
            </Row>
            <Col span={16} md={24} xs={12}><p style={{ paddingTop: '6px', paddingLeft: '0' }}><i>{subtitle}</i></p></Col>
          </Card>
        </Tooltip>
      )
    }
    const survey_columns = [
      { title: 'Question', dataIndex: 'question', key: 'question' },
      {
        title: 'Response', dataIndex: 'answer_poll', key: 'answer_poll',
        render: (answers) => {
          return (
            <span>
              {answers.map(a => (<span><Row>
                <Col span={24}><i>{a.answer}</i><Progress percent={a.count} status="active" /></Col>
              </Row></span>))}
            </span>
          )
        }
      },
      { title: 'Poll Started On', dataIndex: 'poll_start', key: 'poll_start' },
      { title: 'Poll Ends On', dataIndex: 'poll_end', key: 'poll_end' },
      { title: 'Raise By', dataIndex: 'raised_by', key: 'raised_by' },
    ];
    return (
      <div>
        <div > {/* className="gx-d-flex justify-content-center" */}
          {/* {xs: 24, sm: 24, md: 24, lg: 24} */}
          <Row gutter={16}>
            <Col xs={24} sm={12} md={12} lg={24}>
              <Card title={this.state.todays_date} style={{ width: "800" }} headStyle={{ background: "#a42e63", color: "white" }}>
                <Row >
                  <Col xs={24} sm={12} md={12} lg={6} >
                    <Link to="/emaildata?id=1">
                      <CustomCard title=" >1 point Rating growth" description="All Shows that have increased from Above 6 by a margin of 1 full point in ratings" icon="https://img.icons8.com/nolan/64/1-circle.png" number={this.state.margin_of_1} />
                    </Link>
                  </Col>
                  <Col xs={24} sm={12} md={12} lg={6}>
                    <Link to="/emaildata?id=2">
                      <CustomCard title=" > 6 Rating; >500 Votes" description="All Shows that have increased from Above 6 and an increase of atleast 500 votes" icon="https://img.icons8.com/nolan/64/rating.png" number={this.state.above_500_votes} />
                    </Link>
                  </Col>
                  <Col xs={24} sm={12} md={12} lg={6}>
                    <Link to="/emaildata?id=3">
                      <CustomCard title=" New entrants to 6+ Rating" description="All Shows that have increased their rating from below 6 to above 6" icon="https://img.icons8.com/nolan/64/bullish.png" number={this.state.above_6} />
                    </Link>
                  </Col>
                  <Col xs={24} sm={12} md={12} lg={6}>
                    <Link to="/emaildata?id=4">
                      <CustomCard title=" Ratings drop from 6" description="All Shows that have decreased their rating from above 6 to below 6" icon="https://img.icons8.com/nolan/64/bearish.png" number={this.state.below_6} />
                    </Link>
                  </Col>
                </Row>
              </Card>
            </Col>
            <Col xs={24} sm={12} md={12} lg={8}>
              <Link to="/analysis">
                <CustomCard title="ANALYSIS RECORD" description="" subtitle="data for analysis" icon="https://img.icons8.com/nolan/64/merge-files.png" number={this.state.titles} />
              </Link>
            </Col>
            {/* <Col xs={24} sm={12} md={12} lg={8}>
              <Link to="/scraper">
                <CustomCard title="SEARCH USER NEWS" description="" subtitle="data scraped" icon="https://img.icons8.com/nolan/64/process.png" number={this.state.scraper_count} />
              </Link>
            </Col> */}
          </Row>
        </div>
      </div>
    );
  };
}
const mapStateToProps = ({ settings, routing }) => {
  const { width } = settings;
  return { width, routing }
};
export default connect(mapStateToProps)(SamplePage);