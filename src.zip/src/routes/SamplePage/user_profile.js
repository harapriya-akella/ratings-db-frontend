import React, { Component, Fragment } from "react";
import { Button, Card, Form, Upload, Icon, Avatar, message } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { StrToObject } from "../../constants/QueryString";
import HttpService from "../../services/httpService";

const FormItem = Form.Item;

class SamplePage extends Component {
  httpService;
    constructor() {
        super();
        this.httpService = new HttpService();

        this.state = {
            confirmDirty: false,
            autoCompleteResult: [],
            logoFileList : [],
            is_image : false,
        };
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFieldsAndScroll((err, values) => {
          //console.log(values);
          if (!err) {
            console.log('Received values of form: ', values);
            const { location } = this.props.routing;
            var query = StrToObject(location.search);
            let formData = new FormData();
            for ( var key in values ) {
              if(key === 'profile_pic'){
              }else{
                //console.log(key);
                formData.append(key, values[key]);
              }
            }
            if(this.state.logoFileList.length > 0){
              formData.append("profile_pic", this.state.logoFileList[0].originFileObj);
            }
            formData.append('id', query.id);
            this.httpService.post('user/change_profile_pic',formData)
            .then(res => {
              if (res.status === 1) {
                message.success(res.message)
                // this.props.history.push('/user');
                window.location.reload(true);
              } else {
              message.error(res.message)
              }
            })  
            .catch(err => {
              message.error(err)
            })
          }
        });
    }
    handleConfirmBlur = e => {
        const { value } = e.target;
        this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    };
    componentDidMount() {
      const { location } = this.props.routing;
      var query = StrToObject(location.search);
      console.log('query', query)
      if (query) {
          this.httpService.post("user/list", { id: query.id })
          .then(res => {
              if (res.status === 1) {
                  console.log("user ret", res.data)
                  // message.success("User data found")
                  this.setState({
                    profile_pic : res.data[0].profile_pic,
                  })
                  console.log("res.data[0].profile_pic", res.data[0].profile_pic)
                  if (res.data[0].profile_pic !== '') {
                    this.setState({
                      is_image : true
                    })
                  }
              } else {
                  message.error(res.message)
              }
          })
          .catch(err => {
              message.error(err)
          })
      } else {
          message.error("User ID not provided")
      }
  }
    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('password')) {
          callback('Two passwords that you enter is inconsistent!');
        } else {
          callback();
        }
    };
    validateToNextPassword = (rule, value, callback) => {
      const { form } = this.props;
      if (value && this.state.confirmDirty) {
        form.validateFields(['confirm'], { force: true });
      }
      callback();
    };
    handleLogoChange = (info) => {
      this.setState({
        previewLogo : false,
        logoUrl : '',
      })
      let fileList = [...info.fileList];
      console.log(info);
      fileList = fileList.slice(-1);
      fileList = fileList.map(file => {
        if (file.response) {
          // Component will show file.url:link
          file.url = file.response.url;
        }
        return file;
      });
      this.setState({ logoFileList:fileList, is_image : false });
    }
    render() {

        const { getFieldDecorator } = this.props.form;
        // const { autoCompleteResult } = this.state;

        const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 8 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 16 },
        },
        };
        const tailFormItemLayout = {
        wrapperCol: {
            xs: {
            span: 24,
            offset: 0,
            },
            sm: {
            span: 16,
            offset: 8,
            },
        },
        };

        return (
        <div className="ant-row">
            <div className="ant-col ant-col-sm-24 ant-col-md-24 ant-col-lg-24 ant-col-xl-24">
            <Card className="gx-card" title = "Edit profile pic">
                <Form onSubmit={this.handleSubmit}>
                <FormItem {...formItemLayout} label={(<span>
                        Profile Pic &nbsp;
                        </span>
                        )}
                        >
                        {getFieldDecorator('profile_pic', {
                            rules: [{ required: false, message : 'Please select an image'}],
                        })(
                            <Fragment>
                                <Upload onChange={this.handleLogoChange} beforeUpload={() => false} multiple={false} listType="picture" accept=".jpg,.jpeg,.png">
                                    <Button>
                                        <Icon/> Click to upload
                                    </Button>
                                </Upload>
                                {this.state.is_image ? 
                                    <Avatar shape="square" icon="image" size = {100} src = {this.state.profile_pic}/>
                                : null}
                            </Fragment>
                        )}
                    </FormItem>
                    <FormItem {...tailFormItemLayout}>
                        <Link to = {"/user"} className = "btn">Cancel</Link>
                        <Button style={{ backgroundColor: "#4A3A8D", color: "white" }} htmlType="submit">Update</Button>
                    </FormItem>
                </Form>
            </Card>
            </div>
        </div>
        );
    }
}

const RegistrationForm = Form.create()(SamplePage);
const mapStateToProps = ({routing}) => {
  return{routing}
};

export default connect(mapStateToProps, {
})(RegistrationForm);
// export default RegistrationForm;