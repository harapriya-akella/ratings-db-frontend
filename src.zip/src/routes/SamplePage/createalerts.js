import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Row, Menu, Dropdown, Col, Spin, notification, Tooltip } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";
import { languageList, countryList } from '../../appRedux/actions/Common';
import { analysis_list_success, analysis_list, analysis_delete, reset_state } from "../../appRedux/actions/Analysis";
import { Select } from 'antd';
import { Input } from 'antd';
import { InputNumber } from 'antd';
import { CSVLink, CSVDownload } from 'react-csv';
import { Link } from "react-router-dom";
import utf8 from "utf8"

const { Option } = Select;
const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const d = new Date();
var today = monthNames[d.getMonth()] + d.getDate()
class SamplePage extends Component {
    httpService;
    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            columns_detailed_view_rating: [],
            columns_detailed_view_votes: [],
            columns_three_week_view_rating: [],
            columns_three_week_view_votes: [],
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',
            analysis: '',
            delete: false,
            id: '',
            analysis: [],
            analysis_count: 0,
            offset: 0,
            limit: 50,
            startYear: "",
            averageRating: "",
            numVotes: "",
            startYearOperator: "",
            averageRatingOperator: "",
            numVotesOperator: "",
            series_type: "",
            genres: "",
            title: "",
            sort_rating: "",
            sort_year: "",
            sort_votes: "",
            analysis_to_download: [],
            year_ascending: false,
            year_descending: false,
            todays_date: "Analysis",
            loader: true,
            excel_name: "RatingsDB_" + today + ".csv",
            maxYear: new Date().getFullYear() - 1,
            region: "",
            language: "",
            frequency: 1,
            name: "",
            whole_page_spin: false,
            display: 'none',
            display_button: 'block',
            show_preview: 'none',
            sentAlertTo: ""
        }
    }
    componentDidMount() {
        //Call masters//
        this.props.languageList();
        this.props.countryList();

        var id = this.props.location.search.split("=")[1]
        console.log("id", id)
        if (id) {
            console.log("ID PRESENT HERE");
            this.setState({
                display: 'none',
                display_button: 'block',
                show_preview: 'block'
            })
            this.httpService.post("emailalerts/list", { email_id: id })
                .then(res => {
                    // res.data
                    console.log("DATA FROM EMAIL ALERTS LIST API", res.data[0].query[0])
                    this.httpService.post("analysis/list", res.data[0].query[0])
                        .then(res => {
                            this.setState({
                                analysis: res.data,
                                analysis_count: res.count,
                                // analysis_to_download: res.data_without,
                                loader: false
                            })
                        })
                        .catch(err => {
                            console.log("err-1", err);
                        })
                })
                .catch(err => {
                    console.log(err);
                })
        } else {
            console.log("ID NOT PRESENT HERE");
            this.setState({
                display: 'block',
                display_button: 'none'
            })
        }
        this.httpService.post("user/dashboard")
            .then(res => {
                this.setState({
                    todays_date: "Analysis Data Last Updated on " + res.data.todays_date
                })
            })
            .catch(err => {
                this.setState({
                    todays_date: "Analysis Data"
                })
            })
        return;
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize,
            loader: true
        })
        // this.props.analysis_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
        this.httpService.post("analysis/list", {
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize,
            averageRating: this.state.averageRating,
            numVotes: this.state.numVotes,
            series_type: this.state.series_type,
            genres: this.state.genres,
            title: this.state.title,
            startYear: this.state.startYear,
            startYearOperator: this.state.startYearOperator,
            averageRatingOperator: this.state.averageRatingOperator,
            numVotesOperator: this.state.numVotesOperator,
            sort_rating: this.state.sort_rating,
            sort_votes: this.state.sort_votes,
            sort_year: this.state.sort_year,
            language: this.state.language,
            region: this.state.region
        })
            .then(res => {
                this.setState({
                    analysis: res.data,
                    analysis_count: res.count,
                    // analysis_to_download: res.data_without,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })

    }
    renderTableData() {
        console.log("this.state.analysis", this.state.analysis);
        return this.state.analysis.map((a, index) => {
            const { startYear, tconst, titleType, alternateTitle, averageRating, numVotes, genres, region, language, primaryTitle, main_language, main_country } = a
            return (
                {
                    key: tconst, startYear,
                    // alternateTitle: alternateTitle.map((line) => <div><a className="alternatetitle" target="_blank" href={'https://www.imdb.com/title/' + tconst + '/releaseinfo?ref_=tt_dt_dt#akas'}>{this.utfDecoding(line)}</a></div>), 
                    tconst: <a target="_blank" href={'https://www.imdb.com/title/' + tconst}>{tconst}</a>, titleType, averageRating, numVotes, genres, region, language, main_language, main_country, primaryTitle: this.utfDecoding(primaryTitle),
                }
            )
        })
    }
    utfDecoding = (title) => {
        try {
            var pt = (title == '0.03') ? '3%' : utf8.decode(title)
        } catch {
            var pt = (title == '0.03') ? '3%' : title
        }
        return pt
    }
    onChangeFilterYear = (value) => {
        this.setState({
            startYear: value
        })
    }
    onChangeFilterYearOperator = (value) => {
        this.setState({
            startYearOperator: value
        })
    }
    onChangeFilterRating = (value) => {
        this.setState({
            averageRating: value
        })
    }
    onChangeFilterRatingOperator = (value) => {
        this.setState({
            averageRatingOperator: value
        })
    }
    onChangeFilterVotes = (value) => {
        this.setState({
            numVotes: value
        })
    }
    onChangeFilterVotesOperator = (value) => {
        this.setState({
            numVotesOperator: value
        })
    }
    onChangeFilterType = (value) => {
        this.setState({
            series_type: value
        })
    }
    onChangeFilterGenre = (value) => {
        this.setState({
            genres: value
        })
    }
    onChangeFilterTitle = (value) => {
        this.setState({
            title: value.target.value,
        })
    }
    onChangeFilterLanguage = (value) => {
        if (value == "all") {
            console.log("LANGUAGE", value);
            var lng = [];
            if (this.props.languages && this.props.languages.length > 0) {
                this.props.languages.map(ele => {
                    lng.push(ele.code);
                })
            }
            this.setState({
                language: lng
            })
            // this.setState({
            //     language: ["af", "sq", "ar", "hy", "az", "eu", "be", "bg", "ca", "zh", "hr", "cs", "da", "dv", "nl", "en", "eo", "et", "mk", "fo", "fa", "fi", "fr", "gl", "ka", "de", "el", "gu", "he", "hi", "hu", "is", "id", "it", "ja", "kn", "kk", "kok", "ko", "ky", "lv", "lt", "ms", "mt", "mi", "mr", "mn", "ns", "nb", "ps", "pl", "pt", "pa", "qu", "ro", "ru", "se", "sa", "sk", "sl", "es", "sw", "sv", "syr", "tl", "ta", "tt", "te", "th", "ts", "tn", "tr", "uk", "ur", "uz", "vi", "cy", "xh", "zu"]
            // })
        } else {
            this.setState({
                language: value,
            })
        }
    }
    onChangeFilterRegion = (value) => {
        if (value == "all") {
            console.log("REGION", value);
            var rgn = [];
            if (this.props.countries && this.props.countries.length > 0) {
                this.props.countries.map(ele => {
                    rgn.push(ele.code);
                })
            }
            this.setState({
                region: rgn
            })
            // this.setState({
            //     region: ["AF", "AX", "AL", "DZ", "AS", "AD", "AO", "AI", "AQ", "AG", "AR", "AM", "AW", "AU", "AT", "AZ", "BS", "BH", "BD", "BB", "BY", "BE", "BZ", "BJ", "BM", "BT", "BO", "BA", "BW", "BV", "BR", "IO", "VG", "BN", "BG", "BF", "BI", "KH", "CM", "CA", "CV", "KY", "CF", "TD", "CL", "CN", "CX", "CC", "CO", "KM", "CG", "CD", "CK", "CR", "CI", "HR", "CU", "CY", "CZ", "DK", "DJ", "DM", "DO", "EC", "EG", "SV", "GQ", "ER", "EE", "ET", "FK", "FO", "FJ", "FI", "FR", "GF", "PF", "TF", "GA", "GM", "GE", "DE", "GH", "GI", "GB", "GR", "GL", "GD", "GP", "GU", "GT", "GG", "GW", "GN", "GY", "HT", "HM", "HN", "HK", "HU", "IS", "IN", "ID", "IR", "IQ", "IE", "IM", "IL", "IT", "JM", "JP", "JE", "JO", "KZ", "KE", "KI", "KP", "KR", "XKV", "KW", "KG", "LA", "LV", "LB", "LS", "LR", "LY", "LI", "LT", "LU", "MO", "MK", "MG", "MW", "MY", "MV", "ML", "MT", "MH", "MQ", "MR", "MU", "YT", "MX", "FM", "MD", "MC", "MN", "ME", "MS", "MA", "MZ", "MM", "NA", "NR", "NP", "AN", "NL", "NC", "NZ", "NI", "NE", "NG", "NU", "NF", "MP", "NO", "OM", "PK", "PW", "PS", "PA", "PG", "PY", "PE", "PH", "PN", "PL", "PT", "PR", "QA", "RE", "RO", "RU", "RW", "SH", "KN", "LC", "PM", "VC", "WS", "SM", "ST", "SA", "SN", "RS", "SC", "SL", "SG", "SK", "SI", "SB", "SO", "ZA", "GS", "ES", "LK", "SD", "SR", "SJ", "SZ", "SE", "CH", "SY", "TW", "TJ", "TZ", "TH", "TL", "TG", "TK", "TO", "TT", "TN", "TR", "TM", "TC", "TV", "UG", "UA", "AE", "UM", "VI", "US", "UY", "UZ", "VU", "VA", "VE", "VN", "WF", "EH", "YE", "ZM", "ZW"]
            // })
        } else {
            this.setState({
                region: value,
            })
        }
    }
    handleDetailedView = () => {
        this.setState({
            loader: true
        })
        console.log("handleDetailedView");
        this.setState({
            is_detailed_view: true,
            is_three_week_view: false,
            backgroud_button_three_week_view: '#ab959f',
            backgroud_button_detailed_view: '#a42e63',
            loader: false
        })
    }
    handleThreeWeekView = () => {
        this.setState({
            loader: true
        })
        console.log("handleThreeWeekView");
        this.setState({
            is_detailed_view: false,
            is_three_week_view: true,
            backgroud_button_three_week_view: '#a42e63',
            backgroud_button_detailed_view: '#ab959f',
            loader: false
        })
    }
    onChangeSortYear = (sortOrder) => {
        // year_ascending: false,
        // year_descending: false
        console.log("herer", sortOrder)
        if (sortOrder == "ascend") {
            if (!this.state.year_ascending) { //false
                this.setState(prevState => ({
                    year_ascending: true,
                    sort_year: "from_2015_to_now"
                }));
            }
        }
        if (sortOrder == "descend") {
            if (!this.state.year_descending) { //false
                this.setState(prevState => ({
                    year_descending: true,
                    sort_year: "from_now_to_2015"
                }));
            }
        }
        return
    }
    handleFilterSubmit = () => {
        this.setState({
            loader: true,
            show_preview: 'block'
        })
        this.httpService.post("analysis/list", {
            numVotes: this.state.numVotes,
            limit: this.state.limit,
            offset: this.state.offset,
            averageRating: this.state.averageRating,
            title: this.state.title,
            startYear: this.state.startYear,
            series_type: this.state.series_type,
            genres: this.state.genres,
            sort_rating: this.state.sort_rating,
            sort_votes: this.state.sort_votes,
            sort_year: this.state.sort_year,
            numVotesOperator: this.state.numVotesOperator,
            averageRatingOperator: this.state.averageRatingOperator,
            startYearOperator: this.state.startYearOperator,
            language: this.state.language,
            region: this.state.region
        })
            .then(res => {
                this.setState({
                    analysis: res.data,
                    analysis_count: res.count,
                    // analysis_to_download: res.data_without,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })
        this.httpService.post("analysis/get-data-for-excel-download", {
            averageRating: this.state.averageRating,
            numVotes: this.state.numVotes,
            series_type: this.state.series_type,
            genres: this.state.genres,
            title: this.state.title,
            startYear: this.state.startYear,
            startYearOperator: this.state.startYearOperator,
            averageRatingOperator: this.state.averageRatingOperator,
            numVotesOperator: this.state.numVotesOperator,
            sort_rating: this.state.sort_rating,
            sort_votes: this.state.sort_votes,
            sort_year: this.state.sort_year,
            language: this.state.language,
            region: this.state.region
        })
            .then(res => {
                this.setState({
                    analysis_to_download: res.data_without,
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })
    }
    onChangeFrequency = (value) => {
        this.setState({
            frequency: value
        })
    }
    onChangeAlertName = (value) => {
        this.setState({
            name: value.target.value
        })
    }
    onChangeEmails = (value) => {
        this.setState({
            sentAlertTo: value.target.value
        })
    }
    handleCreateAlert = () => {
        if (this.state.sentAlertTo == "") {
            notification['error']({
                message: 'Error',
                description: 'Email addresses not entered.',
            });
        } else {
            var arrayEmail = this.state.sentAlertTo.split(',')
            var regexpEmail = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var error = []

            arrayEmail.forEach(element => {
                element = element.replace(/\s/g, '')
                console.log("element", element);
                if (!regexpEmail.test(element)) {
                    error.push(element)
                }
            });
        }
        if (this.state.name == "") {
            notification['error']({
                message: 'Error',
                description: 'Alert name not entered.',
            });
        } else if (error.length > 0) {
            var errMsg = "Please check these emails- " + error.join()
            notification['error']({
                message: 'Error',
                description: errMsg,
            });
        } else {
            this.setState({
                whole_page_spin: true
            })
            this.httpService.post("emailalerts/create", {
                numVotes: this.state.numVotes,
                limit: this.state.limit,
                offset: this.state.offset,
                averageRating: this.state.averageRating,
                title: this.state.title,
                startYear: this.state.startYear,
                series_type: this.state.series_type,
                genres: this.state.genres,
                sort_rating: this.state.sort_rating,
                sort_votes: this.state.sort_votes,
                sort_year: this.state.sort_year,
                numVotesOperator: this.state.numVotesOperator,
                averageRatingOperator: this.state.averageRatingOperator,
                startYearOperator: this.state.startYearOperator,
                language: this.state.language,
                region: this.state.region,
                frequency: this.state.frequency,
                name: this.state.name,
                sentAlertTo: this.state.sentAlertTo.replace(/\s/g, '')
            })
                .then(res => {
                    console.log("res", res);
                    this.setState({
                        // analysis: res.data,
                        // analysis_count: res.count,
                        whole_page_spin: false,
                    })
                    if (res.status == 1) {
                        notification.info({
                            message: "Email sent",
                            description: res.message,
                            placement: 'topRight',
                        });
                    } else {
                        notification.error({
                            message: 'Error',
                            description: res.message + ". Please check with your backend.",
                            placement: 'topRight',
                        });
                    }
                })
                .catch(err => {
                    this.setState({
                        titles: 0
                    })
                })
        }
    }
    handleClearFilter = () => {
        console.log("CLEAR FILTERS");
        this.setState({
            loader: true
        })
        this.httpService.post("analysis/list", {
            limit: 50,
            offset: 0,
            numVotes: "",
            averageRating: "",
            startYear: "",
            numVotesOperator: "",
            averageRatingOperator: "",
            startYearOperator: "",
            sort_votes: "",
            sort_rating: "",
            sort_year: "",
            title: "",
            series_type: "",
            genres: "",
            language: "",
            region: ""
        })
            .then(res => {
                this.setState({
                    analysis: res.data,
                    analysis_count: res.count,
                    // analysis_to_download: res.data_without,
                    loader: false
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })
        this.setState({
            limit: 50,
            offset: 0,
            numVotes: "",
            averageRating: "",
            startYear: "",
            numVotesOperator: "",
            averageRatingOperator: "",
            startYearOperator: "",
            sort_votes: "",
            sort_rating: "",
            sort_year: "",
            title: "",
            series_type: "",
            genres: "",
            language: "",
            region: ""
        })
        this.httpService.post("analysis/get-data-for-excel-download", {
            numVotes: "",
            averageRating: "",
            startYear: "",
            numVotesOperator: "",
            averageRatingOperator: "",
            startYearOperator: "",
            sort_votes: "",
            sort_rating: "",
            sort_year: "",
            title: "",
            series_type: "",
            genres: "",
            language: "",
            region: ""
        })
            .then(res => {
                this.setState({
                    analysis_to_download: res.data_without,
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })
    }
    render() {
        const columns_detailed_view = [
            { title: 'Title ID', dataIndex: 'tconst', key: 'tconst', width: 110, fixed: "left" },
            {
                title: 'Title',
                dataIndex: 'primaryTitle',
                key: 'primaryTitle',
                width: 150,
                sorter: (a, b) => a.primaryTitle.localeCompare(b.primaryTitle),
                fixed: "left"
            },
            // {
            //     title: 'Alternate Titles',
            //     dataIndex: 'alternateTitle',
            //     key: 'alternateTitle',
            //     width: 250,
            // },
            {
                title: 'Year',
                dataIndex: 'startYear',
                key: 'startYear',
                width: 80,
                sorter: function (a, b, sortOrder) {
                    return a.startYear - b.startYear
                }
            },
            {
                title: 'Rating',
                dataIndex: 'averageRating',
                key: 'averageRating',
                width: 80,
                sorter: function (a, b, sortOrder) {
                    return a.averageRating - b.averageRating
                }
            },
            {
                title: 'Votes',
                dataIndex: 'numVotes',
                key: 'numVotes',
                width: 100,
                sorter: function (a, b, sortOrder) {
                    return a.numVotes - b.numVotes
                }
            },
            { title: 'Type', dataIndex: 'titleType', key: 'titleType', width: 100, },
            { title: 'Genres', dataIndex: 'genres', key: 'genres', width: 100, },
            { title: 'Language', dataIndex: 'main_language', key: 'main_language', width: 250, },
            { title: 'Region', dataIndex: 'main_country', key: 'main_country', width: 250, },
        ];
        const layout = {
            labelCol: { span: 6 },
            wrapperCol: { span: 18 },
        };
        const layoutForfrequency1 = {
            labelCol: { span: 12 },
            wrapperCol: { span: 6 },
        };
        const layoutForfrequency = {
            labelCol: { span: 16 },
            wrapperCol: { span: 8 },
        };
        const layoutForEmail = {
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
        };
        return (
            <Spin spinning={this.state.whole_page_spin} tip="Creating an email alert..." size="large">
                <Button style={{ display: this.state.display_button, backgroundColor: 'white', color: '#4A3A8D', borderColor: '#4A3A8D' }} ><Link to={"/emailalertlist"}>Back</Link></Button>
                <div className="ant-row">
                    <div className="ant-col-24" style={{ display: this.state.display }}>
                        {/* -webkit-text-security : circle */}
                        <Card>
                            <div className="ant-row">
                                <div className="ant-col-24" style={{ paddingBottom: 5 }}>
                                    <h4 style={{ color: "#545454" }}>Filters</h4>
                                </div>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingBottom: 5 }}>
                                        <Input placeholder="Search with Title" style={{ width: 300 }} onChange={this.onChangeFilterTitle} value={this.state.title} />
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            style={{ width: 300 }}
                                            allowClear
                                            placeholder="Select Type"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterType}
                                            value={this.state.series_type == "" ? [] : this.state.series_type}
                                            filterOption={(input, option) =>
                                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                            <Option value="tvSeries">TV Series</Option>
                                            <Option value="tvMiniSeries">TV Mini Series</Option>
                                        </Select>
                                    </div>
                                    <div className="ant-col-8">
                                        <Select
                                            showSearch
                                            allowClear
                                            mode="multiple"
                                            style={{ width: 300 }}
                                            placeholder="Select Genres"
                                            optionFilterProp="children"
                                            value={this.state.genres == "" ? [] : this.state.genres}
                                            onChange={this.onChangeFilterGenre}
                                        >
                                            <Option value="all">All</Option>
                                            <Option value="News">News</Option>
                                            <Option value="Comedy">Comedy</Option>
                                            <Option value="Sport">Sport</Option>
                                            <Option value="Talk-Show">Talk-Show</Option>
                                            <Option value="Documentary">Documentary</Option>
                                            <Option value="Drama">Drama</Option>
                                            <Option value="Mystery">Mystery</Option>
                                            <Option value="Sci-Fi">Sci-Fi</Option>
                                            <Option value="Crime">Crime</Option>
                                            <Option value="Fantasy">Fantasy</Option>
                                            <Option value="Animation">Animation</Option>
                                            <Option value="Reality-TV">Reality-TV</Option>
                                            <Option value="Short">Short</Option>
                                            <Option value="Action">Action</Option>
                                            <Option value="Adventure">Adventure</Option>
                                            <Option value="Music">Music</Option>
                                            <Option value="Biography">Biography</Option>
                                            <Option value="Romance">Romance</Option>
                                            <Option value="Thriller">Thriller</Option>
                                            <Option value="History">History</Option>
                                            <Option value="Horror">Horror</Option>
                                            <Option value="Game-Show">Game-Show</Option>
                                            <Option value="Adult">Adult</Option>
                                            <Option value="Family">Family</Option>
                                            <Option value="War">War</Option>
                                            <Option value="Western">Western</Option>
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-10">
                                        <Select
                                            showSearch
                                            style={{ width: 465 }}
                                            allowClear
                                            mode="multiple"
                                            maxTagCount="3"
                                            placeholder="Select Language"
                                            optionFilterProp="children"
                                            onChange={this.onChangeFilterLanguage}
                                            value={this.state.language == "" ? [] : this.state.language}
                                        // filterOption={(input, option) =>
                                        //     option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        // }
                                        >
                                            <Option value="all">Select all</Option>
                                            {this.props.languages && this.props.languages.length > 0 && this.props.languages.map(ele => (
                                                <Option value={ele.code} label={ele.name}>{ele.name}</Option>
                                            ))}
                                            {/* <Option value="af" label="Afrikaans">Afrikaans</Option>
                                            <Option value="sq" label="Albanian">Albanian</Option>
                                            <Option value="ar" label="Arabic">Arabic</Option>
                                            <Option value="hy" label="Armenian">Armenian</Option>
                                            <Option value="az" label="Azeri (Latin)">Azeri (Latin)</Option>
                                            <Option value="eu" label="Basque">Basque</Option>
                                            <Option value="be" label="Belarusian">Belarusian</Option>
                                            <Option value="bg" label="Bulgarian">Bulgarian</Option>
                                            <Option value="ca" label="Catalan">Catalan</Option>
                                            <Option value="zh" label="Chinese">Chinese</Option>
                                            <Option value="hr" label="Croatian">Croatian</Option>
                                            <Option value="cs" label="Czech">Czech</Option>
                                            <Option value="da" label="Danish">Danish</Option>
                                            <Option value="dv" label="Divehi">Divehi</Option>
                                            <Option value="nl" label="Dutch">Dutch</Option>
                                            <Option value="en" label="English">English</Option>
                                            <Option value="eo" label="Esperanto">Esperanto</Option>
                                            <Option value="et" label="Estonian">Estonian</Option>
                                            <Option value="mk" label="FYRO Macedonian">FYRO Macedonian</Option>
                                            <Option value="fo" label="Faroese">Faroese</Option>
                                            <Option value="fa" label="Farsi">Farsi</Option>
                                            <Option value="fi" label="Finnish">Finnish</Option>
                                            <Option value="fr" label="French">French</Option>
                                            <Option value="gl" label="Galician">Galician</Option>
                                            <Option value="ka" label="Georgian">Georgian</Option>
                                            <Option value="de" label="German">German</Option>
                                            <Option value="el" label="Greek">Greek</Option>
                                            <Option value="gu" label="Gujarati">Gujarati</Option>
                                            <Option value="he" label="Hebrew">Hebrew</Option>
                                            <Option value="hi" label="Hindi">Hindi</Option>
                                            <Option value="hu" label="Hungarian">Hungarian</Option>
                                            <Option value="is" label="Icelandic">Icelandic</Option>
                                            <Option value="id" label="Indonesian">Indonesian</Option>
                                            <Option value="it" label="Italian">Italian</Option>
                                            <Option value="ja" label="Japanese">Japanese</Option>
                                            <Option value="kn" label="Kannada">Kannada</Option>
                                            <Option value="kk" label="Kazakh">Kazakh</Option>
                                            <Option value="kok" label="Konkani">Konkani</Option>
                                            <Option value="ko" label="Korean">Korean</Option>
                                            <Option value="ky" label="Kyrgyz">Kyrgyz</Option>
                                            <Option value="lv" label="Latvian">Latvian</Option>
                                            <Option value="lt" label="Lithuanian">Lithuanian</Option>
                                            <Option value="ms" label="Malay">Malay</Option>
                                            <Option value="mt" label="Maltese">Maltese</Option>
                                            <Option value="mi" label="Maori">Maori</Option>
                                            <Option value="mr" label="Marathi">Marathi</Option>
                                            <Option value="mn" label="Mongolian">Mongolian</Option>
                                            <Option value="ns" label="Northern Sotho">Northern Sotho</Option>
                                            <Option value="nb" label="Norwegian (Bokm?l)">Norwegian (Bokm?l)</Option>
                                            <Option value="ps" label="Pashto">Pashto</Option>
                                            <Option value="pl" label="Polish">Polish</Option>
                                            <Option value="pt" label="Portuguese">Portuguese</Option>
                                            <Option value="pa" label="Punjabi">Punjabi</Option>
                                            <Option value="qu" label="Quechua">Quechua</Option>
                                            <Option value="ro" label="Romanian">Romanian</Option>
                                            <Option value="ru" label="Russian">Russian</Option>
                                            <Option value="se" label="Sami (Northern)">Sami (Northern)</Option>
                                            <Option value="sa" label="Sanskrit">Sanskrit</Option>
                                            <Option value="sk" label="Slovak">Slovak</Option>
                                            <Option value="sl" label="Slovenian">Slovenian</Option>
                                            <Option value="es" label="Spanish">Spanish</Option>
                                            <Option value="sw" label="Swahili">Swahili</Option>
                                            <Option value="sv" label="Swedish">Swedish</Option>
                                            <Option value="syr" label="Syriac">Syriac</Option>
                                            <Option value="tl" label="Tagalog">Tagalog</Option>
                                            <Option value="ta" label="Tamil">Tamil</Option>
                                            <Option value="tt" label="Tatar">Tatar</Option>
                                            <Option value="te" label="Telugu">Telugu</Option>
                                            <Option value="th" label="Thai">Thai</Option>
                                            <Option value="ts" label="Tsonga">Tsonga</Option>
                                            <Option value="tn" label="Tswana">Tswana</Option>
                                            <Option value="tr" label="Turkish">Turkish</Option>
                                            <Option value="uk" label="Ukrainian">Ukrainian</Option>
                                            <Option value="ur" label="Urdu">Urdu</Option>
                                            <Option value="uz" label="Uzbek (Latin)">Uzbek (Latin)</Option>
                                            <Option value="vi" label="Vietnamese">Vietnamese</Option>
                                            <Option value="cy" label="Welsh">Welsh</Option>
                                            <Option value="xh" label="Xhosa">Xhosa</Option>
                                            <Option value="zu" label="Zulu">Zulu</Option> */}
                                        </Select>
                                    </div>
                                    <div className="ant-col-2">
                                    </div>
                                    <div className="ant-col-12">
                                        <Select
                                            showSearch
                                            allowClear
                                            maxTagCount="3"
                                            mode="multiple"
                                            style={{ width: 465 }}
                                            placeholder="Select Region"
                                            // optionFilterProp="children"
                                            value={this.state.region == "" ? [] : this.state.region}
                                            onChange={this.onChangeFilterRegion}
                                        // filterOption={(input, option) =>
                                        // option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        // }
                                        >
                                            <Option value="all">Select All</Option>
                                            {this.props.countries && this.props.countries.length > 0 && this.props.countries.map(ele => (
                                                <Option value={ele.code} label={ele.name}>{ele.name}</Option>
                                            ))}
                                            {/* <Option value="AF" label="Afghanistan">Afghanistan</Option>
                                            <Option value="AX" label="Åland Islands">Åland Islands</Option>
                                            <Option value="AL" label="Albania">Albania</Option>
                                            <Option value="DZ" label="Algeria">Algeria</Option>
                                            <Option value="AS" label="American Samoa">American Samoa</Option>
                                            <Option value="AD" label="Andorra">Andorra</Option>
                                            <Option value="AO" label="Angola">Angola</Option>
                                            <Option value="AI" label="Anguilla">Anguilla</Option>
                                            <Option value="AQ" label="Antarctica">Antarctica</Option>
                                            <Option value="AG" label="Antigua and Barbuda">Antigua and Barbuda</Option>
                                            <Option value="AR" label="Argentina">Argentina</Option>
                                            <Option value="AM" label="Armenia">Armenia</Option>
                                            <Option value="AW" label="Aruba">Aruba</Option>
                                            <Option value="AU" label="Australia">Australia</Option>
                                            <Option value="AT" label="Austria">Austria</Option>
                                            <Option value="AZ" label="Azerbaijan">Azerbaijan</Option>
                                            <Option value="BS" label="Bahamas">Bahamas</Option>
                                            <Option value="BH" label="Bahrain">Bahrain</Option>
                                            <Option value="BD" label="Bangladesh">Bangladesh</Option>
                                            <Option value="BB" label="Barbados">Barbados</Option>
                                            <Option value="BY" label="Belarus">Belarus</Option>
                                            <Option value="BE" label="Belgium">Belgium</Option>
                                            <Option value="BZ" label="Belize">Belize</Option>
                                            <Option value="BJ" label="Benin">Benin</Option>
                                            <Option value="BM" label="Bermuda">Bermuda</Option>
                                            <Option value="BT" label="Bhutan">Bhutan</Option>
                                            <Option value="BO" label="Bolivia">Bolivia</Option>
                                            <Option value="BA" label="Bosnia and Herzegovina">Bosnia and Herzegovina</Option>
                                            <Option value="BW" label="Botswana">Botswana</Option>
                                            <Option value="BV" label="Bouvet Island">Bouvet Island</Option>
                                            <Option value="BR" label="Brazil">Brazil</Option>
                                            <Option value="IO" label="British Indian Ocean Territory">British Indian Ocean Territory</Option>
                                            <Option value="VG" label="British Virgin Islands">British Virgin Islands</Option>
                                            <Option value="BN" label="Brunei Darussalam">Brunei Darussalam</Option>
                                            <Option value="BG" label="Bulgaria">Bulgaria</Option>
                                            <Option value="BF" label="Burkina Faso">Burkina Faso</Option>
                                            <Option value="BI" label="Burundi">Burundi</Option>
                                            <Option value="KH" label="Cambodia">Cambodia</Option>
                                            <Option value="CM" label="Cameroon">Cameroon</Option>
                                            <Option value="CA" label="Canada">Canada</Option>
                                            <Option value="CV" label="Cape Verde">Cape Verde</Option>
                                            <Option value="KY" label="Cayman Islands">Cayman Islands</Option>
                                            <Option value="CF" label="Central African Republic">Central African Republic</Option>
                                            <Option value="TD" label="Chad">Chad</Option>
                                            <Option value="CL" label="Chile">Chile</Option>
                                            <Option value="CN" label="China">China</Option>
                                            <Option value="CX" label="Christmas Island">Christmas Island</Option>
                                            <Option value="CC" label="Cocos (Keeling) Islands">Cocos (Keeling) Islands</Option>
                                            <Option value="CO" label="Colombia">Colombia</Option>
                                            <Option value="KM" label="Comoros">Comoros</Option>
                                            <Option value="CG" label="Congo">Congo</Option>
                                            <Option value="CD" label="Congo, The Democratic Republic of the">Congo, The Democratic Republic of the</Option>
                                            <Option value="CK" label="Cook Islands">Cook Islands</Option>
                                            <Option value="CR" label="Costa Rica">Costa Rica</Option>
                                            <Option value="CI" label="Cote d'Ivoire">Cote d'Ivoire</Option>
                                            <Option value="HR" label="Croatia">Croatia</Option>
                                            <Option value="CU" label="Cuba">Cuba</Option>
                                            <Option value="CY" label="Cyprus">Cyprus</Option>
                                            <Option value="CZ" label="Czech Republic">Czech Republic</Option>
                                            <Option value="DK" label="Denmark">Denmark</Option>
                                            <Option value="DJ" label="Djibouti">Djibouti</Option>
                                            <Option value="DM" label="Dominica">Dominica</Option>
                                            <Option value="DO" label="Dominican Republic">Dominican Republic</Option>
                                            <Option value="EC" label="Ecuador">Ecuador</Option>
                                            <Option value="EG" label="Egypt">Egypt</Option>
                                            <Option value="SV" label="El Salvador">El Salvador</Option>
                                            <Option value="GQ" label="Equatorial Guinea">Equatorial Guinea</Option>
                                            <Option value="ER" label="Eritrea">Eritrea</Option>
                                            <Option value="EE" label="Estonia">Estonia</Option>
                                            <Option value="ET" label="Ethiopia">Ethiopia</Option>
                                            <Option value="FK" label="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</Option>
                                            <Option value="FO" label="Faroe Islands">Faroe Islands</Option>
                                            <Option value="FJ" label="Fiji">Fiji</Option>
                                            <Option value="FI" label="Finland">Finland</Option>
                                            <Option value="FR" label="France">France</Option>
                                            <Option value="GF" label="French Guiana">French Guiana</Option>
                                            <Option value="PF" label="French Polynesia">French Polynesia</Option>
                                            <Option value="TF" label="French Southern Territories">French Southern Territories</Option>
                                            <Option value="GA" label="Gabon">Gabon</Option>
                                            <Option value="GM" label="Gambia">Gambia</Option>
                                            <Option value="GE" label="Georgia">Georgia</Option>
                                            <Option value="DE" label="Germany">Germany</Option>
                                            <Option value="GH" label="Ghana">Ghana</Option>
                                            <Option value="GI" label="Gibraltar">Gibraltar</Option>
                                            <Option value="GB" label="United Kingdom (Great Britain)">United Kingdom (Great Britain)</Option>
                                            <Option value="GR" label="Greece">Greece</Option>
                                            <Option value="GL" label="Greenland">Greenland</Option>
                                            <Option value="GD" label="Grenada">Grenada</Option>
                                            <Option value="GP" label="Guadeloupe">Guadeloupe</Option>
                                            <Option value="GU" label="Guam">Guam</Option>
                                            <Option value="GT" label="Guatemala">Guatemala</Option>
                                            <Option value="GG" label="Guernsey">Guernsey</Option>
                                            <Option value="GW" label="Guinea-Bissau">Guinea-Bissau</Option>
                                            <Option value="GN" label="Guinea">Guinea</Option>
                                            <Option value="GY" label="Guyana">Guyana</Option>
                                            <Option value="HT" label="Haiti">Haiti</Option>
                                            <Option value="HM">Heard Island and McDonald Islands</Option>
                                            <Option value="HN" label="Honduras">Honduras</Option>
                                            <Option value="HK" label="Hong Kong">Hong Kong</Option>
                                            <Option value="HU" label="Hungary">Hungary</Option>
                                            <Option value="IS" label="Iceland">Iceland</Option>
                                            <Option value="IN" label="India">India</Option>
                                            <Option value="ID" label="Indonesia">Indonesia</Option>
                                            <Option value="IR" label="Iran, Islamic Republic of">Iran, Islamic Republic of</Option>
                                            <Option value="IQ" label="Iraq">Iraq</Option>
                                            <Option value="IE" label="Ireland">Ireland</Option>
                                            <Option value="IM" label="Isle of Man">Isle of Man</Option>
                                            <Option value="IL" label="Israel">Israel</Option>
                                            <Option value="IT" label="Italy">Italy</Option>
                                            <Option value="JM" label="Jamaica">Jamaica</Option>
                                            <Option value="JP" label="Japan">Japan</Option>
                                            <Option value="JE" label="Jersey">Jersey</Option>
                                            <Option value="JO" label="Jordan">Jordan</Option>
                                            <Option value="KZ" label="Kazakhstan">Kazakhstan</Option>
                                            <Option value="KE" label="Kenya">Kenya</Option>
                                            <Option value="KI" label="Kiribati">Kiribati</Option>
                                            <Option value="KP" label="Korea, Democratic People's Republic of (North)">Korea, Democratic People's Republic of (North)</Option>
                                            <Option value="KR" label="Korea, Republic of (South)">Korea, Republic of (South)</Option>
                                            <Option value="XKV" label="Kosovo">Kosovo</Option>
                                            <Option value="KW" label="Kuwait">Kuwait</Option>
                                            <Option value="KG" label="Kyrgyzstan">Kyrgyzstan</Option>
                                            <Option value="LA" label="Lao People's Democratic Republic">Lao People's Democratic Republic</Option>
                                            <Option value="LV" label="Latvia">Latvia</Option>
                                            <Option value="LB" label="Lebanon">Lebanon</Option>
                                            <Option value="LS" label="Lesotho">Lesotho</Option>
                                            <Option value="LR" label="Liberia">Liberia</Option>
                                            <Option value="LY" label="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</Option>
                                            <Option value="LI" label="Liechtenstein">Liechtenstein</Option>
                                            <Option value="LT" label="Lithuania">Lithuania</Option>
                                            <Option value="LU" label="Luxembourg">Luxembourg</Option>
                                            <Option value="MO" label="Macao">Macao</Option>
                                            <Option value="MK" label="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</Option>
                                            <Option value="MG" label="Madagascar">Madagascar</Option>
                                            <Option value="MW" label="Malawi">Malawi</Option>
                                            <Option value="MY" label="Malaysia">Malaysia</Option>
                                            <Option value="MV" label="Maldives">Maldives</Option>
                                            <Option value="ML" label="Mali">Mali</Option>
                                            <Option value="MT" label="Malta">Malta</Option>
                                            <Option value="MH" label="Marshall Islands">Marshall Islands</Option>
                                            <Option value="MQ" label="Martinique">Martinique</Option>
                                            <Option value="MR" label="Mauritania">Mauritania</Option>
                                            <Option value="MU" label="Mauritius">Mauritius</Option>
                                            <Option value="YT" label="Mayotte">Mayotte</Option>
                                            <Option value="MX" label="Mexico">Mexico</Option>
                                            <Option value="FM" label="Micronesia, Federated States of">Micronesia, Federated States of</Option>
                                            <Option value="MD" label="Moldova, Republic of">Moldova, Republic of</Option>
                                            <Option value="MC" label="Monaco">Monaco</Option>
                                            <Option value="MN" label="Mongolia">Mongolia</Option>
                                            <Option value="ME" label="Montenegro">Montenegro</Option>
                                            <Option value="MS" label="Montserrat">Montserrat</Option>
                                            <Option value="MA" label="Morocco">Morocco</Option>
                                            <Option value="MZ" label="Mozambique">Mozambique</Option>
                                            <Option value="MM" label="Myanmar">Myanmar</Option>
                                            <Option value="NA" label="Namibia">Namibia</Option>
                                            <Option value="NR" label="Nauru">Nauru</Option>
                                            <Option value="NP" label="Nepal">Nepal</Option>
                                            <Option value="AN" label="Netherlands Antilles">Netherlands Antilles</Option>
                                            <Option value="NL" label="Netherlands">Netherlands</Option>
                                            <Option value="NC" label="New Caledonia">New Caledonia</Option>
                                            <Option value="NZ" label="New Zealand">New Zealand</Option>
                                            <Option value="NI" label="Nicaragua">Nicaragua</Option>
                                            <Option value="NE" label="Niger">Niger</Option>
                                            <Option value="NG" label="Nigeria">Nigeria</Option>
                                            <Option value="NU" label="Niue">Niue</Option>
                                            <Option value="NF" label="Norfolk Island">Norfolk Island</Option>
                                            <Option value="MP" label="Northern Mariana Islands">Northern Mariana Islands</Option>
                                            <Option value="NO" label="Norway">Norway</Option>
                                            <Option value="OM" label="Oman">Oman</Option>
                                            <Option value="PK" label="Pakistan">Pakistan</Option>
                                            <Option value="PW" label="Palau">Palau</Option>
                                            <Option value="PS" label="Palestinian Territory, Occupied">Palestinian Territory, Occupied</Option>
                                            <Option value="PA" label="Panama">Panama</Option>
                                            <Option value="PG" label="Papua New Guinea">Papua New Guinea</Option>
                                            <Option value="PY" label="Paraguay">Paraguay</Option>
                                            <Option value="PE" label="Peru">Peru</Option>
                                            <Option value="PH" label="Philippines">Philippines</Option>
                                            <Option value="PN" label="Pitcairn">Pitcairn</Option>
                                            <Option value="PL" label="Poland">Poland</Option>
                                            <Option value="PT" label="Portugal">Portugal</Option>
                                            <Option value="PR" label="Puerto Rico">Puerto Rico</Option>
                                            <Option value="QA" label="Qatar">Qatar</Option>
                                            <Option value="RE" label="Reunion">Reunion</Option>
                                            <Option value="RO" label="Romania">Romania</Option>
                                            <Option value="RU" label="Russian Federation">Russian Federation</Option>
                                            <Option value="RW" label="Rwanda">Rwanda</Option>
                                            <Option value="SH" label="Saint Helena">Saint Helena</Option>
                                            <Option value="KN" label="Saint Kitts and Nevis">Saint Kitts and Nevis</Option>
                                            <Option value="LC" label="Saint Lucia">Saint Lucia</Option>
                                            <Option value="PM" label="Saint Pierre and Miquelon">Saint Pierre and Miquelon</Option>
                                            <Option value="VC" label="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</Option>
                                            <Option value="WS" label="Samoa">Samoa</Option>
                                            <Option value="SM" label="San Marino">San Marino</Option>
                                            <Option value="ST" label="Sao Tome and Principe">Sao Tome and Principe</Option>
                                            <Option value="SA" label="Saudi Arabia">Saudi Arabia</Option>
                                            <Option value="SN" label="Senegal">Senegal</Option>
                                            <Option value="RS" label="Serbia">Serbia</Option>
                                            <Option value="SC" label="Seychelles">Seychelles</Option>
                                            <Option value="SL" label="Sierra Leone">Sierra Leone</Option>
                                            <Option value="SG" label="Singapore">Singapore</Option>
                                            <Option value="SK" label="Slovakia">Slovakia</Option>
                                            <Option value="SI" label="Slovenia">Slovenia</Option>
                                            <Option value="SB" label="Solomon Islands">Solomon Islands</Option>
                                            <Option value="SO" label="Somalia">Somalia</Option>
                                            <Option value="ZA" label="South Africa">South Africa</Option>
                                            <Option value="GS" label="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</Option>
                                            <Option value="ES" label="Spain">Spain</Option>
                                            <Option value="LK" label="Sri Lanka">Sri Lanka</Option>
                                            <Option value="SD" label="Sudan">Sudan</Option>
                                            <Option value="SR" label="Suriname">Suriname</Option>
                                            <Option value="SJ" label="Svalbard and Jan Mayen">Svalbard and Jan Mayen</Option>
                                            <Option value="SZ" label="Swaziland">Swaziland</Option>
                                            <Option value="SE" label="Sweden">Sweden</Option>
                                            <Option value="CH" label="Switzerland">Switzerland</Option>
                                            <Option value="SY" label="Syrian Arab Republic">Syrian Arab Republic</Option>
                                            <Option value="TW" label="Taiwan, Province of China">Taiwan, Province of China</Option>
                                            <Option value="TJ" label="Tajikistan">Tajikistan</Option>
                                            <Option value="TZ" label="Tanzania, United Republic of">Tanzania, United Republic of</Option>
                                            <Option value="TH" label="Thailand">Thailand</Option>
                                            <Option value="TL" label="Timor-Leste">Timor-Leste</Option>
                                            <Option value="TG" label="Togo">Togo</Option>
                                            <Option value="TK" label="Tokelau">Tokelau</Option>
                                            <Option value="TO" label="Tonga">Tonga</Option>
                                            <Option value="TT" label="Trinidad and Tobago">Trinidad and Tobago</Option>
                                            <Option value="TN" label="Tunisia">Tunisia</Option>
                                            <Option value="TR" label="Turkey">Turkey</Option>
                                            <Option value="TM" label="Turkmenistan">Turkmenistan</Option>
                                            <Option value="TC" label="Turks and Caicos Islands">Turks and Caicos Islands</Option>
                                            <Option value="TV" label="Tuvalu">Tuvalu</Option>
                                            <Option value="UG" label="Uganda">Uganda</Option>
                                            <Option value="UA" label="Ukraine">Ukraine</Option>
                                            <Option value="AE" label="United Arab Emirates">United Arab Emirates</Option>
                                            <Option value="UM" label="United States Minor Outlying Islands">United States Minor Outlying Islands</Option>
                                            <Option value="VI" label="U.S. Virgin Islands">U.S. Virgin Islands</Option>
                                            <Option value="US" label="United States">United States</Option>
                                            <Option value="UY" label="Uruguay">Uruguay</Option>
                                            <Option value="UZ" label="Uzbekistan">Uzbekistan</Option>
                                            <Option value="VU" label="Vanuatu">Vanuatu</Option>
                                            <Option value="VA" label="Holy See (Vatican City State)">Holy See (Vatican City State)</Option>
                                            <Option value="VE" label="Venezuela">Venezuela</Option>
                                            <Option value="VN" label="Vietnam">Vietnam</Option>
                                            <Option value="WF" label="Wallis and Futuna">Wallis and Futuna</Option>
                                            <Option value="EH" label="Western Sahara">Western Sahara</Option>
                                            <Option value="YE" label="Yemen">Yemen</Option>
                                            <Option value="ZM" label="Zambia">Zambia</Option>
                                            <Option value="ZW" label="Zimbabwe">Zimbabwe</Option> */}
                                        </Select>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_year"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Year">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.startYearOperator == "" ? [] : this.state.startYearOperator}
                                                            onChange={this.onChangeFilterYearOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={2015} max={this.state.maxYear} style={{ width: 150 }} onChange={this.onChangeFilterYear} value={this.state.startYear} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic_ratings"
                                            initialValues={{ remember: true }}
                                        >
                                            {/* **** */}
                                            <Form.Item label="Ratings">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.averageRatingOperator == "" ? [] : this.state.averageRatingOperator}
                                                            onChange={this.onChangeFilterRatingOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} max={10} style={{ width: 150 }} onChange={this.onChangeFilterRating} value={this.state.averageRating} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                            {/* **** */}
                                        </Form>
                                    </div>
                                    <div className="ant-col-8" style={{ paddingTop: 5 }}>
                                        <Form
                                            {...layout}
                                            name="basic"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Votes">
                                                <Input.Group compact>
                                                    <Form.Item style={{ width: 100 }}>
                                                        <Select
                                                            style={{ width: 80 }}
                                                            value={this.state.numVotesOperator == "" ? [] : this.state.numVotesOperator}
                                                            onChange={this.onChangeFilterVotesOperator}
                                                        >
                                                            <Option value="$eq">=</Option>
                                                            <Option value="$gte">&gt;</Option>
                                                            <Option value="$lte">&lt;</Option>
                                                        </Select>
                                                    </Form.Item>
                                                    <Form.Item style={{ width: 150 }}>
                                                        <InputNumber min={1} style={{ width: 150 }} onChange={this.onChangeFilterVotes} value={this.state.numVotes} />
                                                    </Form.Item>
                                                </Input.Group>
                                            </Form.Item>
                                        </Form>
                                    </div>
                                </Row>
                                <Row gutter={16}>
                                    <div >
                                        <Form
                                            {...layoutForfrequency}
                                            name="frequency"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Frequency (in days)">
                                                <InputNumber min={1} max={30} onChange={this.onChangeFrequency} style={{ width: 80 }} />
                                            </Form.Item>
                                        </Form>
                                    </div>
                                    <div>
                                        <Form
                                            {...layoutForEmail}
                                            name="name"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Alert name" name="name">
                                                <Input onChange={this.onChangeAlertName} style={{ width: 200 }} />
                                            </Form.Item>
                                        </Form>
                                    </div>
                                    <div>
                                        <Form
                                            {...layoutForEmail}
                                            name="emails"
                                            initialValues={{ remember: true }}
                                        >
                                            <Form.Item label="Email IDs" name="emails">
                                                <Tooltip title="Please use comma to separate the email IDs">
                                                    <Input onChange={this.onChangeEmails} style={{ width: 230 }} />
                                                </Tooltip>
                                            </Form.Item>
                                        </Form>
                                    </div>
                                </Row>
                                <div className="ant-col-24">
                                    <Button style={{ backgroundColor: 'white', color: '#a42e63', borderColor: '#a42e63' }} onClick={this.handleFilterSubmit} type="dashed">Apply Filters and Preview</Button>
                                    <Button style={{ backgroundColor: 'white', color: '#4A3A8D', borderColor: '#4A3A8D' }} onClick={this.handleCreateAlert} type="dashed">Create an Alert</Button>
                                    <Button style={{ backgroundColor: 'white', color: '#808080', borderColor: '#808080' }} onClick={this.handleClearFilter} type="dashed">Clear Filters</Button>
                                </div>
                            </div>
                        </Card>
                    </div>
                    <div className="ant-col-24" style={{ display: this.state.show_preview }}>
                        <Card title="Preview">
                            {
                                <Table className="gx-table-responsive" loading={this.state.loader} columns={columns_detailed_view} dataSource={this.renderTableData()} pagination={{ total: this.state.analysis_count, defaultCurrent: 1, defaultPageSize: 50, showTotal: (total => `Total ${total} items`) }} onChange={this.handleTableChange} scroll={{ x: 500, y: 500 }} sticky={true} />
                            }
                        </Card>
                    </div>
                </div>
            </Spin>
        );
    }
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ analysisList, commonData }) => {
    const { analysis, analysis_count } = analysisList;
    const { countries, languages } = commonData;
    return { analysis, analysis_count, countries, languages }
};

export default connect(mapStateToProps, {
    analysis_list,
    analysis_list_success,
    analysis_delete,
    reset_state,
    languageList,
    countryList
})(RegistrationForm)