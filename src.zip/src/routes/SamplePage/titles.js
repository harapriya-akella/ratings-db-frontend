import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";

import { title_list_success, title_list, title_delete, reset_state } from "../../appRedux/actions/Title";

class SamplePage extends Component {
    httpService;

    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            titles: '',
            delete: false,
            id: '',
            offset: 0,
            limit: 10
        }
    }

    componentDidMount() {
        var userID = localStorage.getItem('user_id')
        this.httpService.post("user/dashboard", { user_id: userID })
            .then(res => {
                console.log("res data dashboard")
                this.setState({
                    titles: res.data.titles
                })
            })
            .catch(err => {
                this.setState({
                    titles: 0
                })
            })
        this.props.reset_state();
        this.props.title_list({ limit: this.state.limit, offset: this.state.offset });

        if (this.props.showMessage) {
            setTimeout(() => {
                this.props.hideMessage();
            }, 100);
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
        this.props.title_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
    }

    renderTableData() {
        return this.props.titles.map((title, index) => {
            const { tconst, titleType, primaryTitle, originalTitle, isAdult, startYear, endYear, runtimeMinutes, genres } = title
            return (
                {
                    key: tconst, tconst, titleType, primaryTitle, originalTitle, isAdult, startYear, endYear, runtimeMinutes, genres
                }
            )
        })
    }
    render() {
        const columns = [
            { title: 'T Const', dataIndex: 'tconst', key: 'tconst' },
            { title: 'Title Type', dataIndex: 'titleType', key: 'titleType' },
            { title: 'Primary Title', dataIndex: 'primaryTitle', key: 'primaryTitle' },
            { title: 'Priginal Title', dataIndex: 'originalTitle', key: 'originalTitle' },
            { title: 'Is Adult', dataIndex: 'isAdult', key: 'isAdult' },
            { title: 'Start Year', dataIndex: 'startYear', key: 'startYear' },
            { title: 'End Year', dataIndex: 'endYear', key: 'endYear' },
            { title: 'Run time Minutes', dataIndex: 'runtimeMinutes', key: 'runtimeMinutes' },
            { title: 'Genres', dataIndex: 'genres', key: 'genres' }
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card title="Title">
                            <Table className="gx-table-responsive" columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.props.title_count, defaultCurrent: 1,defaultPageSize: 10 }} onChange={this.handleTableChange} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
    // https://stackoverflow.com/questions/58249361/handle-pagination-sorting-and-filtering-separately-in-antd-table-react
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ titleList }) => {
    const { titles, title_count } = titleList;
    console.log("titles, title_count", titles, title_count);
    return { titles, title_count }
};

export default connect(mapStateToProps, {
    title_list,
    title_list_success,
    title_delete,
    reset_state
})(RegistrationForm)