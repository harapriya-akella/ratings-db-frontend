import React, { Component, Fragment } from "react";
import { Form, Button, Table, Card, Menu, Dropdown } from "antd";
import { connect } from "react-redux";
import HttpService from "../../services/httpService";

import { rating_list_success, rating_list, rating_delete, reset_state } from "../../appRedux/actions/Rating";

class SamplePage extends Component {
    httpService;

    constructor() {
        super();
        this.httpService = new HttpService();
        this.state = {
            ratings: 0,
            delete: false,
            id: '',
            offset: 0,
            limit: 10

        }
    }

    componentDidMount() {
        var userID = localStorage.getItem('user_id')
        this.httpService.post("user/dashboard", { user_id: userID })
            .then(res => {
                // console.log("res data dashboard")
                this.setState({
                    ratings: res.data.ratings
                })
            })
            .catch(err => {
                this.setState({
                    ratings: 0
                })
            })
        this.props.reset_state();
        this.props.rating_list({ limit: this.state.limit, offset: this.state.offset });

        if (this.props.showMessage) {
            setTimeout(() => {
                this.props.hideMessage();
            }, 100);
        }
    }
    handleTableChange = (pagination) => {
        this.setState({
            limit: pagination.pageSize,
            offset: (pagination.current * pagination.pageSize) - pagination.pageSize
        })
        this.props.rating_list({ limit: pagination.pageSize, offset: (pagination.current * pagination.pageSize) - pagination.pageSize });
    }

    renderTableData() {
        return this.props.ratings.map((rating, index) => {
            const { tconst, averageRating, numVotes } = rating
            return (
                {
                    key: tconst, tconst, averageRating, numVotes
                }
            )
        })
    }
    render() {
        const columns = [
            { title: 'T Const', dataIndex: 'tconst', key: 'tconst' },
            { title: 'Average Rating', dataIndex: 'averageRating', key: 'averageRating' },
            { title: 'Number of Votes', dataIndex: 'numVotes', key: 'numVotes' }
        ];
        return (
            <div>
                <div className="ant-row">
                    <div className="ant-col-24">
                        <Card title="Rating">
                            <Table className="gx-table-responsive" columns={columns} dataSource={this.renderTableData()} pagination={{ total: this.props.rating_count, defaultCurrent: 1,defaultPageSize: 10 }} onChange={this.handleTableChange} />
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
    // https://stackoverflow.com/questions/58249361/handle-pagination-sorting-and-filtering-separately-in-antd-table-react
}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ ratingList }) => {
    const { ratings, rating_count } = ratingList;
    return { ratings, rating_count }
};

export default connect(mapStateToProps, {
    rating_list,
    rating_list_success,
    rating_delete,
    reset_state
})(RegistrationForm)