import React, { Component } from "react";
import { Button, Card, Form, Input, Upload, Icon, Select } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { user_add } from "../../appRedux/actions/User"
// import { zone_list, zone_list_success } from "../../appRedux/actions/Zone"
const FormItem = Form.Item;
const { Option } = Select;

class SamplePage extends Component {
    constructor() {
        super();
        this.state = {
            confirmDirty: false,
            autoCompleteResult: [],
            logoFileList : []
        };
    }
    componentDidMount() {
        // this.props.zone_list();
        // console.log("zoned", this.props.zones)
    }
    handleLogoChange = (info) => {
        this.setState({
          previewLogo : false,
          logoUrl : '',
        })
        let fileList = [...info.fileList];
        console.log(info);
        fileList = fileList.slice(-1);
        fileList = fileList.map(file => {
          if (file.response) {
            // Component will show file.url:link
            file.url = file.response.url;
          }
          return file;
        });
        this.setState({ logoFileList:fileList });
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFieldsAndScroll((err, values) => {
          //console.log(values);
          if (!err) {
            console.log('Received values of form: ', values);
            this.props.user_add(values)
          }
        });
    }
    componentDidUpdate(prevProps,prevState){
        if(this.props.success){
            this.props.history.push('/user');
        }
    }
    handleConfirmBlur = e => {
        const { value } = e.target;
        this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    };
    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('password')) {
          callback('Two passwords that you enter is inconsistent!');
        } else {
          callback();
        }
    };
    validateToNextPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && this.state.confirmDirty) {
          form.validateFields(['confirm'], { force: true });
        }
        callback();
    };
    render() {

        const { getFieldDecorator } = this.props.form;
        // const { autoCompleteResult } = this.state;

        const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 8 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 16 },
        },
        };
        const tailFormItemLayout = {
        wrapperCol: {
            xs: {
            span: 24,
            offset: 0,
            },
            sm: {
            span: 16,
            offset: 8,
            },
        },
        };

        return (
        <div className="ant-row">
            <div className="ant-col ant-col-sm-24 ant-col-md-24 ant-col-lg-24 ant-col-xl-24">
            <Card className="gx-card" title = "Add User">
                <Form onSubmit={this.handleSubmit}>
                    <FormItem {...formItemLayout} label={(<span>
                        First Name &nbsp;
                    </span>
                    )}
                    >
                        {getFieldDecorator('first_name', {
                        rules: [{ required: true, message: 'Please enter first name', whitespace: true }],
                        })(
                        <Input placeholder="First Name" />
                        )}
                    </FormItem>
                    <FormItem {...formItemLayout} label={(<span>
                        Last Name &nbsp;
                    </span>
                    )}
                    >
                        {getFieldDecorator('last_name', {
                        rules: [{ required: true, message: 'Please enter last name', whitespace: true }],
                        })(
                        <Input placeholder="Last Name" />
                        )}
                    </FormItem>
                    {/* <FormItem
                        {...formItemLayout}
                        label={(
                            <span>
                            Phone Number&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('phone_number', {
                            rules: [{required: true, message: 'Enter Phone Number', whitespace: true, 'pattern' : '[0-9]{10}'}],
                        })(
                            <Input></Input>
                        )}
                    </FormItem> */}
                    <FormItem
                        {...formItemLayout}
                        label={(
                            <span>
                            Email&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('email', {
                            rules: [{required: true, message: 'Enter email', whitespace: true, email : true}],
                        })(
                            <Input></Input>
                        )}
                    </FormItem>
                    <FormItem hasFeedback
                        {...formItemLayout}
                        label={(
                            <span>
                            Password&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('password', {
                            rules: [
                            {
                                required: true,
                                message: 'Please input your password!',
                            },
                            {
                                validator: this.validateToNextPassword,
                            },
                            ],
                        })(<Input.Password />)}
                    </FormItem>
                    <FormItem hasFeedback
                        {...formItemLayout}
                        label={(
                            <span>
                            Confirm Password&nbsp;
                            
                        </span>
                        )}
                        >
                        {getFieldDecorator('repeat_password', {
                            rules: [
                            {
                                required: true,
                                message: 'Please confirm your password!',
                            },
                            {
                                validator: this.compareToFirstPassword,
                            },
                            ],
                        })(<Input.Password onBlur={this.handleConfirmBlur} />)}
                    </FormItem>
                    {/* <FormItem {...formItemLayout} label={(<span>
                        Profile Pic &nbsp;
                        </span>
                        )}
                        >
                        {getFieldDecorator('profile_pic', {
                        rules: [{ required: true, message : 'Please select an image'}],
                        })(
                            <Upload fileList={this.state.logoFileList} onChange={this.handleLogoChange} 
                            beforeUpload={() => false} multiple={false} listType="picture"
                            accept=".jpg,.jpeg,.png">
                            <Button>
                            <Icon/> Click to upload
                            </Button>
                        </Upload>
                        )}
                    </FormItem> */}
                    <FormItem {...tailFormItemLayout}>
                        <Link to = {"/user"} className = "btn">Cancel</Link>
                        <Button type="primary" htmlType="submit">Submit</Button>
                    </FormItem>
                </Form>
            </Card>
            </div>
        </div>
        );
    }
}

const RegistrationForm = Form.create()(SamplePage);
const mapStateToProps = ({ userList}) => {
    // zoneList,
    // const { zones } = zoneList
    const { success } = userList
    return{ success }
    // zones, 
};

export default connect(mapStateToProps, {
    user_add,
    // zone_list, 
    // zone_list_success,
})(RegistrationForm);