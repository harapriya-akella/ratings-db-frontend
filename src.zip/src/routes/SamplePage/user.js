import React, { Component, Fragment } from "react";
import { Button, Card, Table, Form, Menu, Dropdown } from "antd";
import SweetAlert from "react-bootstrap-sweetalert";
import IntlMessages from "util/IntlMessages";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { user_list_success, user_list, user_delete, reset_state } from "../../appRedux/actions/User";

class SamplePage extends Component {
  constructor() {
    super();
    this.state = {
      delete: false,
      id: '',
    }
  }
  handleDelete = (ID) => {
    this.setState({
      delete: true,
      id: ID,
    });
  }
  onConfirmDelete = () => {
    this.props.user_delete(this.state.id);
    this.setState({
      delete: false,
      // warning_message: ''
    })
  }

  onCancelDelete = () => {
    this.setState({
      delete: false,
      id: '',
    });
  }

  componentDidMount() {
    this.props.reset_state();
    console.log("this.props step 1", this.props)

    this.props.user_list();

    if (this.props.showMessage) {
      setTimeout(() => {
        this.props.hideMessage();
      }, 100);
    }
  }

  renderTableData() {
    var i = 1;
    console.log("this.props.users", this.props.users)
    return this.props.users.map((user, index) => {
      console.log("user===>", user)
      const { id, first_name, last_name, email, zone } = user //destructuring
      return (
        {
          key: id,
          i: i++,
          // profile_pic: <img alt="" src={profile_pic} width="50" height="50" style={{ borderRadius: '50%' }} />,
          full_name: first_name + " " + last_name,
          // phone_number,
          email,
          // zone,
        }
      )
    })
  }

  render() {
    const columns = [
      // { title: 'Profile Pic', dataIndex: 'profile_pic', key: 'profile_pic' },
      { title: '#', dataIndex: 'i', key: 'i' },
      { title: 'Name', dataIndex: 'full_name', key: 'full_name' },
      // { title: 'Phone Number', dataIndex: 'phone_number', key: 'phone_number' },
      { title: 'Email', dataIndex: 'email', key: 'email' },
      // { title: 'Zone', dataIndex: 'zone', key: 'zone' },

      // {
      //   title: 'Action', key: 'action',
      //   //fixed: 'right',
      //   //width: 100,
      //   render: (text, record) =>
      //     <Dropdown.Button overlay={menu(record)}>
      //       Action
      //     </Dropdown.Button>,
      // }
    ];
    const menu = (record) => (
      <Menu>
        {/* <Menu.Item key="1" > <Link to = {"/user_add"}> Add </Link> </Menu.Item> */}
        <Menu.Item key="2">  <Link to={"/user_edit?id=" + record.key}>  Edit </Link></Menu.Item>
        <Menu.Item key="3">  <Link to={"/user_password?id=" + record.key}>  Change password </Link></Menu.Item>
        <Menu.Item key="4">  <Link to={"/user_profile?id=" + record.key}>  Change profile pic </Link></Menu.Item>
        <Menu.Item key="5" onClick={() => this.handleDelete(record.key)}>Delete</Menu.Item>
      </Menu>
    );
    return (
      <div>
        <div className="ant-row">
          <div className="ant-col-24">
            <Card title="User List" extra={<Fragment><Link to={"/user_add"} title="Add a new user here"><Button style={{ backgroundColor: "#4A3A8D", color: "white" }} shape="circle" icon="plus" /></Link></Fragment>}>
              <Table className="gx-table-responsive" columns={columns} dataSource={this.renderTableData()} />
              {/* scroll={{ x: 2000 }} */}
              <SweetAlert show={this.state.delete}
                custom
                showCancel
                confirmBtnText={<IntlMessages id="button.yes" />}
                cancelBtnText={<IntlMessages id="button.no" />}
                confirmBtnBsStyle="primary"
                cancelBtnBsStyle="default"
                customIcon={require("./../../assets/del.svg")}
                title="Do you want to delete the user?"
                onConfirm={this.onConfirmDelete}
                onCancel={this.onCancelDelete}
              ></SweetAlert>
            </Card>
          </div>
        </div>
      </div>
    );
  }

}
const RegistrationForm = Form.create()(SamplePage);

const mapStateToProps = ({ userList }) => {
  const { users } = userList;
  console.log("userList", userList)
  return { users }
};

export default connect(mapStateToProps, {
  user_list,
  user_list_success,
  user_delete,
  reset_state
})(RegistrationForm)