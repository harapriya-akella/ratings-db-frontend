import React from "react";
import { Route, Switch } from "react-router-dom";

import asyncComponent from "util/asyncComponent";

const App = ({ match }) => (
  <div className="gx-main-content-wrapper">
    <Switch>
      <Route path={`${match.url}dashboard`} component={asyncComponent(() => import('./SamplePage'))} />
      <Route path={`${match.url}user`} component={asyncComponent(() => import('./SamplePage/user'))} />
      <Route path={`${match.url}user_add`} component={asyncComponent(() => import('./SamplePage/user_add'))} />
      <Route path={`${match.url}user_edit`} component={asyncComponent(() => import('./SamplePage/user_edit'))} />
      <Route path={`${match.url}user_profile`} component={asyncComponent(() => import('./SamplePage/user_profile'))} />
      <Route path={`${match.url}user_password`} component={asyncComponent(() => import('./SamplePage/user_password'))} />
      <Route path={`${match.url}my_account`} component={asyncComponent(() => import('./SamplePage/my_account'))} />
      <Route path={`${match.url}export_data`} component={asyncComponent(() => import('./SamplePage/export_data'))} />
      <Route path={`${match.url}analysis`} component={asyncComponent(() => import('./SamplePage/analysis'))} />
      <Route path={`${match.url}emaildata`} component={asyncComponent(() => import('./SamplePage/emaildata'))} />
      <Route path={`${match.url}createalerts`} component={asyncComponent(() => import('./SamplePage/createalerts'))} />
      <Route path={`${match.url}emailalertlist`} component={asyncComponent(() => import('./SamplePage/emailalertlist'))} />
      <Route path={`${match.url}newdevelopmentprojects`} component={asyncComponent(() => import('./SamplePage/newdevelopmentprojects'))} />
      <Route path={`${match.url}scraper`} component={asyncComponent(() => import('./SamplePage/scraper'))} />
      <Route path={`${match.url}website_html`} component={asyncComponent(() => import('./SamplePage/website_html'))} />
    </Switch>
  </div>
);

export default App;
