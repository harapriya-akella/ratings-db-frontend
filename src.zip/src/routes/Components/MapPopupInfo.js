import React, {Component} from "react";
import {GoogleMap, InfoWindow, Marker, withGoogleMap} from "react-google-maps";

const google = window.google;
const PopUpInfoWindowExampleGoogleMap = withGoogleMap(props => (
  <GoogleMap
    defaultZoom={4}
    center={props.center}
  >
    {props.markers.map((marker, index) => (
      <Marker
        defaultIcon={require("assets/images/marker.png")}
        key={index}
        position={marker.position}
        onClick={() => props.onMarkerClick(marker)}
      >
        {/*
         Show info window only if the 'showInfo' key of the marker is true.
         That is, when the Marker pin has been clicked and 'onCloseClick' has been
         Successfully fired.
         */}
        {marker.showInfo && (
          <InfoWindow onCloseClick={() => props.onMarkerClose(marker)}>
            <div>{marker.infoContent}
            </div>
          </InfoWindow>
        )}
      </Marker>
    ))}
  </GoogleMap>
));

/*
 *
 *  Add <script src="https://maps.googleapis.com/maps/api/js"></script>
 *  to your HTML to provide google.maps reference
 *
 *  @author: @chiwoojo
 */
export default class MapPopupInfo extends Component {
  constructor(props) {
    super(props)
    this.state = {
      markers : [],
      center: {
        lat: 20.5937, lng: 78.9629,
      },
    }
  }
  componentDidMount() {
    var positionArray = []
    console.log("coordinates===========================>", this.props.coordinates)
    this.props.coordinates.map((coo) => {
      console.log("lati======>", coo.latitude)
      positionArray.push({'position': new google.maps.LatLng(coo.latitude, coo.longitude), showInfo: false, infoContent: <div>{coo.latitude +', '+ coo.longitude}</div>})
      return(positionArray)
    })
    console.log("positionArray", positionArray)
    this.setState({
      markers : positionArray
    })
  }
  

  // state = {
  //   center: {
  //     lat: 20.5937, lng: 78.9629,
  //   },

    // array of objects of markers

    // markers: this.props.coordinates
    // markers: [

      // {
      //   position: new google.maps.LatLng(19.1663, 72.8526),
      //   showInfo: false,
      //   infoContent: (
      //     <div className="d-flex">
      //       <div>
      //         <svg
      //           id="Layer_1"
      //           xmlns="http://www.w3.org/2000/svg"
      //           width="16"
      //           height="16"
      //           viewBox="0 0 16 16"
      //         >
      //           <path
      //             d="M6 14.5c0 .828-.672 1.5-1.5 1.5S3 15.328 3 14.5 3.672
      //         13 4.5 13s1.5.672 1.5 1.5zM16 14.5c0 .828-.672 1.5-1.5
      //         1.5s-1.5-.672-1.5-1.5.672-1.5 1.5-1.5 1.5.672 1.5 1.5zM16
      //         8V2H4c0-.552-.448-1-1-1H0v1h2l.75 6.438C2.294 8.805 2 9.368
      //         2 10c0 1.105.895 2 2 2h12v-1H4c-.552 0-1-.448-1-1v-.01L16 8z"
      //           />
      //         </svg>
      //       </div>
      //       <div className="ml-1">
      //         <p>University of Washington Intramural Activities (IMA) Building</p>
      //         <p>3924 Montlake Blvd NE</p>
      //         <p>Seattle, WA 98195</p>
      //       </div>

      //     </div>
      //   ),
      // },
    // ],
  // };

  handleMarkerClick = this.handleMarkerClick.bind(this);
  handleMarkerClose = this.handleMarkerClose.bind(this);

  // Toggle to 'true' to show InfoWindow and re-renders simple
  handleMarkerClick(targetMarker) {
    this.setState({
      markers: this.state.markers.map(marker => {
        if (marker === targetMarker) {
          return {
            ...marker,
            showInfo: true,
          };
        }
        return marker;
      }),
    });
  }

  handleMarkerClose(targetMarker) {
    this.setState({
      markers: this.state.markers.map(marker => {
        if (marker === targetMarker) {
          return {
            ...marker,
            showInfo: false,
          };
        }
        return marker;
      }),
    });
  }

  render() {
    return (
      <PopUpInfoWindowExampleGoogleMap
        loadingElement={<div style={{height: `100%`}}/>}
        containerElement={<div style={{height: `550px`}}/>}
        mapElement={<div style={{height: `100%`}}/>}
        center={this.state.center}
        markers={this.state.markers}
        onMarkerClick={this.handleMarkerClick}
        onMarkerClose={this.handleMarkerClose}
      />
    );
  }
}