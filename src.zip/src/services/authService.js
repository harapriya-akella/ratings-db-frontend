import axios from 'axios';

class Auth {
    checkLogin = async (emailId, password) => {
        var baseUrl = 'http://localhost:4010/'

        var data;
        var auth_data = {
            email: emailId,
            password: password
        }
        console.log("auth_data", auth_data)
        await axios.post(baseUrl + 'user/login', auth_data, {
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        })
            .then(res => {
                console.log("res", res)
                data = res.data;
            })
            .catch(err => {
                console.log("err", err)
            })
        return data
    }
}

export default Auth;