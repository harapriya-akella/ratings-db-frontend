import axios from 'axios';
import { message } from 'antd';
import { BrowserRouter } from 'react-router-dom';
import { createBrowserHistory } from 'history'

export const history = createBrowserHistory();

class HttpService extends BrowserRouter {
    base_url = 'http://localhost:4010/';

    base_url2 = 'http://localhost:4003/'

    get = async (url, params) => {
        var data;
        if (url !== '') {
            await axios.get(this.base_url + url, {
                params: params,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            })
                .then(res => {
                    if (res.statusCode === 400) {
                        data = { status: 0, message: 'fail in server validation' };
                    } else if (res.statusCode === 401) {
                        localStorage.clear()
                        message.error("Session time out!!", () => {
                            window.location.href = "http://localhost:3000"
                        })
                    } else {
                        data = res.data;
                    }
                }).catch((err) => {
                    console.log("err====>", err);
                    localStorage.clear()
                    message.error("Session time out!!", () => {
                        window.location.href = "http://localhost:3000"
                    })
                })
            return data
        } else {
            return false;
        }
    }

    post = async (url, dataArr, params) => {
        // console.log("params", dataArr);
        console.log("url,dataArr,params", url, dataArr, params)
        var data;
        if (url !== '') {
            console.log("BASEURL", this.base_url + url);
            await axios.post(this.base_url + url, dataArr, {
                params: params,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            })
                .then(res => {
                    console.log("res", res);
                    if (res.statusCode === 400) {
                        data = { status: 0, message: 'fail in server validation' };
                    }
                    else {
                        data = res.data;
                    }
                }).catch((err) => {
                    var errResp = err.response;
                    if (errResp && errResp.data && errResp.data.statusCode === 401) {
                        localStorage.clear();
                        this.context.history.push('/signin');
                    } else {
                        // message.error('Something went wrong. Please contact your backend');
                    }
                })
            console.log("data ===> HTTPS", data);
            return data
        } else {
            return false;
        }
    }

    post2 = async (url, dataArr, params) => {
        // console.log("params", dataArr);
        console.log("url,dataArr,params", url, dataArr, params)
        var data;
        if (url !== '') {
            console.log("BASEURL", this.base_url2 + url);
            await axios.post(this.base_url2 + url, dataArr, {
                params: params,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            })
                .then(res => {
                    console.log("res", res);
                    if (res.statusCode === 400) {
                        data = { status: 0, message: 'fail in server validation' };
                    }
                    else {
                        data = res.data;
                    }
                }).catch((err) => {
                    var errResp = err.response;
                    if (errResp && errResp.data && errResp.data.statusCode === 401) {
                        localStorage.clear();
                        this.context.history.push('/signin');
                    } else {
                        // message.error('Something went wrong. Please contact your backend');
                    }
                })
            console.log("data ===> HTTPS", data);
            return data
        } else {
            return false;
        }
    }

    get2 = async (url, params) => {
        var data;
        if (url !== '') {
            await axios.get(this.base_url2 + url, {
                params: params,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            })
                .then(res => {
                    if (res.statusCode === 400) {
                        data = { status: 0, message: 'fail in server validation' };
                    } else if (res.statusCode === 401) {
                        localStorage.clear()
                        message.error("Session time out!!", () => {
                            window.location.href = "http://localhost:3000"
                        })
                    } else {
                        data = res.data;
                    }
                }).catch((err) => {
                    console.log("err====>", err);
                    localStorage.clear()
                    message.error("Session time out!!", () => {
                        window.location.href = "http://localhost:3000"
                    })
                })
            return data
        } else {
            return false;
        }
    }
}

export default HttpService;