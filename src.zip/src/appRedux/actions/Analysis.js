import { ANALYSIS_LIST, ANALYSIS_LIST_SUCCESS, ANALYSIS_RETRIEVE, ANALYSIS_RETRIEVE_SUCCESS, ANALYSIS_EDIT, ANALYSIS_ADD, ANALYSIS_DELETE, ANALYSIS_SUCCESS, RESET_STATE } from "../../constants/ActionTypes";

export const analysis_list = (payload) => {
    return {
        type : ANALYSIS_LIST,
        payload
    }
}

export const analysis_list_success = (list, count) => {
    // console.log("list, count ===> ", list, count);
    return {
        type : ANALYSIS_LIST_SUCCESS,
        payload : list,
        count
    }
}

export const analysis_retrieve = (ref) => {
    return {
        type : ANALYSIS_RETRIEVE,
        payload : ref
    }
}

export const analysis_retrieve_success = (ref) => {
    return {
        type : ANALYSIS_RETRIEVE_SUCCESS,
        payload : ref
    }
}

export const analysis_edit = (ref) => {
    return {
        type : ANALYSIS_EDIT,
        payload : ref
    }
}
export const analysis_add = (ref) => {
    return {
        type : ANALYSIS_ADD,
        payload : ref
    }
}
export const analysis_delete = (id) => {
    return {
        type : ANALYSIS_DELETE,
        payload : id
    }
}
export const analysis_success = () => {
    return {
        type : ANALYSIS_SUCCESS
    }
}

export const reset_state = () => {
    return {
        type : RESET_STATE
    }
}