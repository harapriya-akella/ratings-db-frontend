import { USER_LIST, USER_LIST_SUCCESS, USER_RETRIEVE, USER_RETRIEVE_SUCCESS, USER_EDIT, USER_CHANGE_PASSWORD, USER_ADD, USER_DELETE, USER_SUCCESS, RESET_STATE } from "../../constants/ActionTypes";

export const user_list = () => {
    return {
        type : USER_LIST,
    }
}

export const user_list_success = (list) => {
    return {
        type : USER_LIST_SUCCESS,
        payload : list
    }
}

export const user_retrieve = (ref) => {
    return {
        type : USER_RETRIEVE,
        payload : ref
    }
}

export const user_retrieve_success = (ref) => {
    return {
        type : USER_RETRIEVE_SUCCESS,
        payload : ref
    }
}

export const user_edit = (ref) => {
    return {
        type : USER_EDIT,
        payload : ref
    }
}
export const user_change_password = (ref) => {
    return {
        type : USER_CHANGE_PASSWORD,
        payload : ref
    }
}
export const user_add = (ref) => {
    return {
        type : USER_ADD,
        payload : ref
    }
}
export const user_delete = (id) => {
    return {
        type : USER_DELETE,
        payload : id
    }
}
export const user_success = () => {
    return {
        type : USER_SUCCESS
    }
}

export const reset_state = () => {
    return {
        type : RESET_STATE
    }
}