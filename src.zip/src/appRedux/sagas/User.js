import { USER_LIST, USER_RETRIEVE, USER_EDIT, USER_CHANGE_PASSWORD, USER_ADD, USER_DELETE } from '../../constants/ActionTypes';
import { user_list_success, user_retrieve_success, user_success } from '../actions/User';
import { all, call, fork, put, takeEvery } from "redux-saga/effects";
import { message } from 'antd';
import HttpService from '../../services/httpService';

const httpService = new HttpService();

const getList = async () => {
    return httpService.post('user/list');
}
const retrieve_user = async (id) => {
    return httpService.post('user/list', { id });
}
const editUser = async (payload) => {
    return httpService.post('user/update',payload);
}
const addUser = async (payload) => {
    return httpService.post('user/add',payload);
}
const changePasswordUser = async (payload) => {
    return httpService.post('user/change_password',payload);
}
const delete_user = async (id) => {
    return httpService.post('user_controller/remove',{ id });
}
function* list_user() {
    var res = yield call(getList);
    yield put(user_list_success(res.data));
}
function* retrieveUser ({payload}) {
    var res = yield call(retrieve_user,payload.id);
    if(res){
        if(res.status === 1){
            message.success("User data found");
            // var list = yield call(getList);
            yield put(user_retrieve_success({"ret" : res.data}));
        }else{
            message.error(res.message);
        }
    }
}
function* edit_user({payload}){
    var res = yield call(editUser,payload);
    if(res){
        if(res.status === 1){
            // yield call(list_referral);
            // message.success(res.message);
            message.success('User data updated successfully');
            yield put(user_success());
        }else{
            message.error(res.message);
        }
    }   
}
function* add_user({payload}){
    var res = yield call(addUser,payload);
    if(res){
        if(res.status === 1){
            // yield call(list_referral);
            // message.success(res.message);
            message.success('User created successfully');
            yield put(user_success());

        }else{
            message.error(res.message);
        }
    }   
}
function* change_password_user({payload}){
    var res = yield call(changePasswordUser,payload);
    if(res){
        if(res.status === 1){
            message.success(res.message);
            yield put(user_success());
        }else{
            message.error(res.message);
        }
    }   
}
function* deleteUser({payload}){
    var res = yield call(delete_user,payload);
    if(res){
        if(res.status === 1){
            message.success(res.message);
            yield call(list_user);
        }else{
            message.error(res.message);
        }
    }
}
export function* userList() {
    yield takeEvery(USER_LIST, list_user);
}
export function* userRetrieve() {
    yield takeEvery(USER_RETRIEVE, retrieveUser);
}
export function* userEdit() {
    yield takeEvery(USER_EDIT, edit_user);
}
export function* userAdd() {
    yield takeEvery(USER_ADD, add_user);
}
export function* userChangePassword() {
    yield takeEvery(USER_CHANGE_PASSWORD, change_password_user);
}
export function* userDelete(){
    yield takeEvery(USER_DELETE,deleteUser);
}
export default function* rootSaga() {
    yield all(
        [
            fork(userList),
            fork(userRetrieve),
            fork(userEdit),
            fork(userChangePassword),
            fork(userAdd),
            fork(userDelete),
    ]);
}