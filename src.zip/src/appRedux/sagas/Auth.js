import { all, call, fork, put, takeEvery } from "redux-saga/effects";
// import {
//   auth,
//   facebookAuthProvider,
//   githubAuthProvider,
//   googleAuthProvider,
//   twitterAuthProvider
// } from "../../firebase/firebase";
import {
  SIGNIN_FACEBOOK_USER,
  SIGNIN_GITHUB_USER,
  SIGNIN_GOOGLE_USER,
  SIGNIN_TWITTER_USER,
  SIGNIN_USER,
  SIGNOUT_USER,
  SIGNUP_USER,
  SEND_OTP,
  VERIFY_OTP,
  RESET_PASSWORD
} from "constants/ActionTypes";
import { showAuthMessage, userSignInSuccess, userSignOutSuccess, userSignUpSuccess, testConsoleSuccess, send_otp_success, verify_otp_success, reset_password_success } from "../../appRedux/actions/Auth";
import {
  userFacebookSignInSuccess,
  userGithubSignInSuccess,
  userGoogleSignInSuccess,
  userTwitterSignInSuccess
} from "../actions/Auth";
import Auth from '../../services/authService';
import HttpService from "../../services/httpService";
import { message } from "antd";

const authService = new Auth();
const httpService = new HttpService();
// const createUserWithEmailPasswordRequest = async (email, password) =>
//   await auth.createUserWithEmailAndPassword(email, password)
//     .then(authUser => authUser)
//     .catch(error => error);

const signInUserWithEmailPasswordRequest = async (email, password) =>
  await authService.checkLogin(email, password)
    .then(authUser => authUser)
    .catch(error => error);

// const signOutRequest = async () =>
//   await auth.signOut()
//     .then(authUser => authUser)
//     .catch(error => error);


// const signInUserWithGoogleRequest = async () =>
//   await auth.signInWithPopup(googleAuthProvider)
//     .then(authUser => authUser)
//     .catch(error => error);

// const signInUserWithFacebookRequest = async () =>
//   await auth.signInWithPopup(facebookAuthProvider)
//     .then(authUser => authUser)
//     .catch(error => error);

// const signInUserWithGithubRequest = async () =>
//   await auth.signInWithPopup(githubAuthProvider)
//     .then(authUser => authUser)
//     .catch(error => error);

// const signInUserWithTwitterRequest = async () =>
//   await auth.signInWithPopup(twitterAuthProvider)
//     .then(authUser => authUser)
//     .catch(error => error);

// function* createUserWithEmailPassword({ payload }) {
//   const { email, password } = payload;
//   try {
//     const signUpUser = yield call(createUserWithEmailPasswordRequest, email, password);
//     if (signUpUser.message) {
//       yield put(showAuthMessage(signUpUser.message));
//     } else {
//       localStorage.setItem('user_id', signUpUser.user.uid);
//       yield put(userSignUpSuccess(signUpUser.user.uid));
//     }
//   } catch (error) {
//     yield put(showAuthMessage(error));
//   }
// }

// function* signInUserWithGoogle() {
//   try {
//     const signUpUser = yield call(signInUserWithGoogleRequest);
//     if (signUpUser.message) {
//       yield put(showAuthMessage(signUpUser.message));
//     } else {
//       localStorage.setItem('user_id', signUpUser.user.uid);
//       yield put(userGoogleSignInSuccess(signUpUser.user.uid));
//     }
//   } catch (error) {
//     yield put(showAuthMessage(error));
//   }
// }


// function* signInUserWithFacebook() {
//   try {
//     const signUpUser = yield call(signInUserWithFacebookRequest);
//     if (signUpUser.message) {
//       yield put(showAuthMessage(signUpUser.message));
//     } else {
//       localStorage.setItem('user_id', signUpUser.user.uid);
//       yield put(userFacebookSignInSuccess(signUpUser.user.uid));
//     }
//   } catch (error) {
//     yield put(showAuthMessage(error));
//   }
// }


// function* signInUserWithGithub() {
//   try {
//     const signUpUser = yield call(signInUserWithGithubRequest);
//     if (signUpUser.message) {
//       yield put(showAuthMessage(signUpUser.message));
//     } else {
//       localStorage.setItem('user_id', signUpUser.user.uid);
//       yield put(userGithubSignInSuccess(signUpUser.user.uid));
//     }
//   } catch (error) {
//     yield put(showAuthMessage(error));
//   }
// }


// function* signInUserWithTwitter() {
//   try {
//     const signUpUser = yield call(signInUserWithTwitterRequest);
//     if (signUpUser.message) {
//       if (signUpUser.message.length > 100) {
//         yield put(showAuthMessage('Your request has been canceled.'));
//       } else {
//         yield put(showAuthMessage(signUpUser.message));
//       }
//     } else {
//       localStorage.setItem('user_id', signUpUser.user.uid);
//       yield put(userTwitterSignInSuccess(signUpUser.user.uid));
//     }
//   } catch (error) {
//     yield put(showAuthMessage(error));
//   }
// }

function* signInUserWithEmailPassword({ payload }) {
  const { email, password } = payload;
  try {
    const signInUser = yield call(signInUserWithEmailPasswordRequest, email, password);
    console.log("signInUser", signInUser);
    if (signInUser) {
      if (signInUser.status !== 1) {
        console.log('user fail', email, password);
        yield put(showAuthMessage(signInUser.message));
      } else {
        console.log('user success');
        console.log("data from login api", signInUser.data);
        localStorage.setItem('user_id', signInUser.data.id);
        localStorage.setItem('user_first_name', signInUser.data.first_name);
        localStorage.setItem('user_last_name', signInUser.data.last_name);
        localStorage.setItem('user_email', signInUser.data.email);
        // localStorage.setItem('user_phone_number', signInUser.data.phone_number);
        // localStorage.setItem('user_profile_pic', signInUser.data.profile_pic);
        // localStorage.setItem('user_zone', signInUser.data.zone);
        
        yield put(userSignInSuccess({ 
          user_id: signInUser.data.id, 
          user_first_name: signInUser.data.first_name,
          user_last_name: signInUser.data.last_name, 
          user_email: signInUser.data.email, 
          // user_phone_number: signInUser.data.phone_number, 
          // user_profile_pic: signInUser.data.profile_pic,
        }));
      }
    } else {
      console.log("user fail- network error")
    }
  } catch (error) {
    yield put(showAuthMessage(error));
  }
}

function* signOut() {
  try {
    //const signOutUser = yield call(signOutRequest);
    //if (signOutUser === undefined) {
    localStorage.removeItem('user_id');
    localStorage.removeItem('user_first_name');
    localStorage.removeItem('user_last_name');
    localStorage.removeItem('user_email');
    // localStorage.removeItem('user_phone_number');
    // localStorage.removeItem('user_zone');
    // localStorage.removeItem('user_profile_pic');
    yield put(userSignOutSuccess(signOutUser));
    //} else {
    //yield put(showAuthMessage(signOutUser.message));
    //}
  } catch (error) {
    yield put(showAuthMessage(error));
  }
}

function* consoleTest({ payload }) {
  console.log(payload);
  console.log('log in sega');
  if (payload.email !== '') {
    yield put(testConsoleSuccess('No email'));
  } else {
    yield put(userSignOutSuccess(consoleTest));
  }
}
const otp_send = async (data) => {
  return httpService.post('auth/sendOtp', data);
}
function* otpSend({ payload }) {
  var res = yield call(otp_send, payload);
  if (res) {
    if (res.status) {
      message.success(res.message);
      console.log(res);
      yield put(send_otp_success(res.user_id))
    } else {
      message.error(res.message);
    }
  }
}
const otp_verify = async (data) => {
  return httpService.post('auth/verifyOtp', data);
}
function* otpVerify({ payload }) {
  var res = yield call(otp_verify, payload);
  if (res) {
    if (res.status) {
      message.success(res.message);
      yield put(verify_otp_success(res.token));
    } else {
      message.error(res.message);
    }
  }
}
const password_reset = async (data) => {
  return httpService.post('manager/changePassword', data);
}
function* passwordReset({ payload }) {
  var res = yield call(password_reset, payload);
  if (res) {
    if (res.status) {
      message.success(res.message);
      yield put(reset_password_success());
      //console.log(res);
    } else {
      message.error(res.message);
    }
  }
}

// export function* createUserAccount() {
//   yield takeEvery(SIGNUP_USER, createUserWithEmailPassword);
// }

// export function* signInWithGoogle() {
//   yield takeEvery(SIGNIN_GOOGLE_USER, signInUserWithGoogle);
// }

// export function* signInWithFacebook() {
//   yield takeEvery(SIGNIN_FACEBOOK_USER, signInUserWithFacebook);
// }

// export function* signInWithTwitter() {
//   yield takeEvery(SIGNIN_TWITTER_USER, signInUserWithTwitter);
// }

// export function* signInWithGithub() {
//   yield takeEvery(SIGNIN_GITHUB_USER, signInUserWithGithub);
// }

export function* signInUser() {
  yield takeEvery(SIGNIN_USER, signInUserWithEmailPassword);
}

export function* signOutUser() {
  yield takeEvery(SIGNOUT_USER, signOut);
}

export function* testConsole() {
  yield takeEvery('TEST_CONSOLE', consoleTest);
}

export function* sendOtp() {
  yield takeEvery(SEND_OTP, otpSend);
}

export function* verifyOtp() {
  yield takeEvery(VERIFY_OTP, otpVerify);
}

export function* resetPassword() {
  yield takeEvery(RESET_PASSWORD, passwordReset);
}


export default function* rootSaga() {
  yield all([fork(signInUser),
  // fork(createUserAccount),
  // fork(signInWithGoogle),
  // fork(signInWithFacebook),
  // fork(signInWithTwitter),
  // fork(signInWithGithub),
  fork(signOutUser),
  fork(testConsole),
  fork(sendOtp),
  fork(verifyOtp),
  fork(resetPassword),
  ]);

}