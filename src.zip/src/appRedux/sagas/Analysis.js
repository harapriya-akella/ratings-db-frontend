import { ANALYSIS_LIST, ANALYSIS_RETRIEVE, ANALYSIS_EDIT, ANALYSIS_ADD, ANALYSIS_DELETE } from '../../constants/ActionTypes';
import { analysis_list_success, analysis_retrieve_success, analysis_success } from '../actions/Analysis';
import { all, call, fork, put, takeEvery } from "redux-saga/effects";
import { message } from 'antd';
import HttpService from '../../services/httpService';

const httpService = new HttpService();

const getList = async (payload) => {
    // console.log("limit, offset", payload);
    return httpService.post('analysis/list', payload);
}
function* list_analysis({payload}) {
    // console.log("payload- function", payload);

    var res = yield call(getList, payload);
    // console.log("res.data, res.count", res);
    yield put(analysis_list_success(res.data, res.count));
}
export function* analysisList() {
    yield takeEvery(ANALYSIS_LIST, list_analysis);
}
export default function* rootSaga() {
    yield all(
        [
            fork(analysisList),
    ]);
}