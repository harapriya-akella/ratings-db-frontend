import {all} from "redux-saga/effects";
import authSagas from "./Auth";
import answerTypeSagas from "./Answer_type";
import articleSagas from "./Article";
import bannerSagas from "./Banner";
import categorySagas from "./Category";
import emergencySagas from "./Emergency";
import employeeSagas from "./Employee";
import linkCategorySagas from "./Link_category";
import notificationSagas from "./Notification";
import tickerSagas from "./Ticker";
import titleSagas from "./Title";
import principalSagas from "./Principal";
import episodeSagas from "./Episode";
import crewSagas from "./Crew";
import ratingSagas from "./Rating";
import akasSagas from "./Akas";
import nameSagas from "./Name";
import surveySagas from "./Survey";
import userSagas from "./User";
import zoneSagas from "./Zone";
import commonSagas from "./Common";
export default function* rootSaga(getState) {
  yield all([
    authSagas(),
    answerTypeSagas(),
    articleSagas(),
    bannerSagas(),
    categorySagas(),
    emergencySagas(),
    employeeSagas(),
    linkCategorySagas(),
    notificationSagas(),
    tickerSagas(),
    titleSagas(),
    principalSagas(),
    episodeSagas(),
    crewSagas(),
    ratingSagas(),
    akasSagas(),
    nameSagas(),
    surveySagas(),
    userSagas(),
    zoneSagas(),
    commonSagas(),
  ]);
}
