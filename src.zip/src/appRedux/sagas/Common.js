import { all, call, fork, put, takeEvery } from "redux-saga/effects";
import { message } from 'antd';
import HttpService from '../../services/httpService';
import { LIST_LANGUAGE, LIST_COUNTRIES } from "../../constants/ActionTypes";
import { languageListSuccess, countryListSuccess } from "../actions/Common";

const httpService = new HttpService();

const language_list = () => {
    return httpService.get('language/list');
}

function* languageList({ payload }) {
    var res = yield call(language_list, payload);
    if (res) {
        if (res.status === 1) {
            yield put(languageListSuccess(res.data));
        }
    }
}
const country_list = () => {
    return httpService.get('country/list');
}

function* countryList({ payload }) {
    var res = yield call(country_list, payload);
    if (res) {
        if (res.status === 1) {
            yield put(countryListSuccess(res.data));
        }
    }
}

export function* listCountries() {
    yield takeEvery(LIST_COUNTRIES, countryList);
}
export function* listLanguage() {
    yield takeEvery(LIST_LANGUAGE, languageList);
}

export default function* commonSagas() {
    yield all(
        [
            fork(listLanguage),
            fork(listCountries),
        ]);
}