import { USER_LIST, USER_LIST_SUCCESS, USER_RETRIEVE_SUCCESS, USER_SUCCESS, RESET_STATE } from '../../constants/ActionTypes';

const INIT_STATE = {
    users: [],
    success : false,
    user_obj : {}
}

export default (state = INIT_STATE, action) => {
    console.log("list-reducers", action.type)
    switch(action.type){
        case USER_LIST : {
            return {
                ...state,
            }
        }
        case USER_LIST_SUCCESS : {
            return {
                ...state,
                users : action.payload
            }
        }
        case USER_RETRIEVE_SUCCESS : {
            return {
                ...state,
                user_obj : action.payload.ret,
            }
        }
        case USER_SUCCESS : {
            return {
                ...state,
                success : true
            }
        }
        case RESET_STATE : {
            return INIT_STATE
        }
        default : {
            return state;
        }
    }
}