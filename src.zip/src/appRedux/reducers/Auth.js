import {
  HIDE_MESSAGE,
  INIT_URL,
  ON_HIDE_LOADER,
  ON_SHOW_LOADER,
  SHOW_MESSAGE,
  SIGNIN_FACEBOOK_USER_SUCCESS,
  SIGNIN_GITHUB_USER_SUCCESS,
  SIGNIN_GOOGLE_USER_SUCCESS,
  SIGNIN_TWITTER_USER_SUCCESS,
  SIGNIN_USER_SUCCESS,
  SIGNOUT_USER_SUCCESS,
  SIGNUP_USER_SUCCESS,
  FORGOT_PASSWORD,
  SIGNIN_PAGE,
  SEND_OTP_SUCCESS,
  RESET_AUTH_USER,
} from "constants/ActionTypes";
import { 
  VERIFY_OTP_SUCCESS, 
  RESET_PASSWORD_SUCCESS 
} from "../../constants/ActionTypes";

const INIT_STATE = {
  loader: false,
  alertMessage: '',
  showMessage: false,
  initURL: '',
  authUser: localStorage.getItem('user_id'),
  userDetail : JSON.parse(localStorage.getItem('userDetail')),
  signIn : true,
  sendOtp : false,
  verifyOtp : false,
  resetPassword : false,
  otpUserId : null,
  otpToken : ''
};


export default (state = INIT_STATE, action) => {
  
  switch (action.type) {
    case SIGNUP_USER_SUCCESS: {
      return {
        ...state,
        loader: false,
        authUser: action.payload
      }
    }
    case SIGNIN_USER_SUCCESS: {
      console.log("reducers", action.payload)
      return {
        ...state,
        loader: false,
        authUser: action.payload.user_id,
        userDetail : action.payload,
      }
    }
    case INIT_URL: {
      return {
        ...state,
        initURL: action.payload
      }
    }
    case SIGNOUT_USER_SUCCESS: {
      return {
        ...state,
        authUser: null,
        initURL: '/',
        loader: false
      }
    }

    case SHOW_MESSAGE: {
      return {
        ...state,
        alertMessage: action.payload,
        showMessage: true,
        loader: false
      }
    }
    case HIDE_MESSAGE: {
      return {
        ...state,
        alertMessage: '',
        showMessage: false,
        loader: false
      }
    }

    case SIGNIN_GOOGLE_USER_SUCCESS: {
      return {
        ...state,
        loader: false,
        authUser: action.payload
      }
    }
    case SIGNIN_FACEBOOK_USER_SUCCESS: {
      return {
        ...state,
        loader: false,
        authUser: action.payload
      }
    }
    case SIGNIN_TWITTER_USER_SUCCESS: {
      return {
        ...state,
        loader: false,
        authUser: action.payload
      }
    }
    case SIGNIN_GITHUB_USER_SUCCESS: {
      return {
        ...state,
        loader: false,
        authUser: action.payload
      }
    }
    case ON_SHOW_LOADER: {
      return {
        ...state,
        loader: true
      }
    }
    case ON_HIDE_LOADER: {
      return {
        ...state,
        loader: false
      }
    }
    case FORGOT_PASSWORD: {
      return {
        ...state,
        signIn : false,
        sendOtp : true
      }
    }
    case SIGNIN_PAGE: {
      return {
        ...state,
        signIn : true,
        sendOtp : false,
        verifyOtp : false,
        resetPassword : false,
      }
    }
    case SEND_OTP_SUCCESS : {
      return {
        ...state,
        otpUserId : action.payload,
        verifyOtp : true,
        signIn : false,
        sendOtp : false,
        resetPassword : false,
      }
    }
    case VERIFY_OTP_SUCCESS : {
      return {
        ...state,
        otpToken : action.payload,
        resetPassword : true,
        verifyOtp : false,
        signIn : false,
        sendOtp : false,
      }
    }
    case RESET_PASSWORD_SUCCESS : {
      return {
        ...state,
        otpToken : '',
        otpUserId : null,
        signIn : true,
        verifyOtp : false,
        sendOtp : false,
        resetPassword : false
      }
    }
    case "TEST_CONSOLE_SUCCESS":{
      console.log('Test console Reducer');
      return state;
    }
    case RESET_AUTH_USER : {
      return {
        ...state,
        userDetail : action.payload
      };
    }
    default:
      return state;
  }
}


// import {INIT_URL, SIGNOUT_USER_SUCCESS, USER_DATA, USER_TOKEN_SET} from "../../constants/ActionTypes";

// const INIT_STATE = {
//   initURL: '',

// };

// export default (state = INIT_STATE, action) => {
//   switch (action.type) {


//     case INIT_URL: {
//       return {...state, initURL: action.payload};
//     }

//     case SIGNOUT_USER_SUCCESS: {
//       return {
//         ...state,
//         token: null,
//         authUser: null,
//         initURL: ''
//       }
//     }

//     case USER_DATA: {
//       return {
//         ...state,
//         authUser: action.payload,
//       };
//     }

//     case USER_TOKEN_SET: {
//       return {
//         ...state,
//         token: action.payload,
//       };
//     }

//     default:
//       return state;
//   }
// }