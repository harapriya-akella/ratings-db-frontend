import {combineReducers} from "redux";
import {routerReducer} from "react-router-redux";
import Settings from "./Settings";
import Auth from "./Auth";
import Common from "./Common";
import Answer_type from "./Answer_type";
import Article from "./Article";
import Banner from "./Banner";
import Category from "./Category";
import Emergency from "./Emergency";
import Employee from "./Employee";
import Link_category from "./Link_category";
import Notification from "./Notification";
import Ticker from "./Ticker";
import Title from "./Title";
import Analysis from "./Analysis";
import Name from "./Name";
import Principal from "./Principal";
import Episode from "./Episode";
import Crew from "./Crew";
import Rating from "./Rating";
import Akas from "./Akas";
import Survey from "./Survey";
import User from "./User";
import Zone from "./Zone";

const reducers = combineReducers({
  routing: routerReducer,
  settings: Settings,
  auth: Auth,
  commonData: Common,
  answerTypeList : Answer_type,
  articleList : Article,
  bannerList : Banner,
  categoryList: Category,
  emergencyList: Emergency,
  employeeList : Employee,
  linkCategoryList : Link_category,
  notificationList : Notification,
  tickerList : Ticker,
  titleList : Title,
  analysisList : Analysis,
  nameList : Name,
  principalList : Principal,
  akasList : Akas,
  ratingList : Rating,
  crewList : Crew,
  episodeList : Episode,
  surveyList : Survey,
  userList: User,
  zoneList: Zone,
});

export default reducers;
