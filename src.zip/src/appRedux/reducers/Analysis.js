import { ANALYSIS_LIST, ANALYSIS_LIST_SUCCESS, ANALYSIS_RETRIEVE_SUCCESS, ANALYSIS_SUCCESS, RESET_STATE } from '../../constants/ActionTypes';

const INIT_STATE = {
    analysis: [],
    analysis_obj : {},
    success : false,
    analysis_count: 0 
}

export default (state = INIT_STATE, action) => {
    switch(action.type){
        case ANALYSIS_LIST : {
            return {
                ...state,
            }
        }
        case ANALYSIS_LIST_SUCCESS : {
            // console.log("action.payload", action.payload);
            return {
                ...state,
                analysis : action.payload,
                analysis_count: action.count
            }
        }
        case ANALYSIS_RETRIEVE_SUCCESS : {
            return {
                ...state,
                analysis_obj : action.payload.ret,
            }
        }
        case ANALYSIS_SUCCESS : {
            return {
                ...state,
                success : true
            }
        }
        case RESET_STATE : {
            return INIT_STATE
        }
        default : {
            return state;
        }
    }
}