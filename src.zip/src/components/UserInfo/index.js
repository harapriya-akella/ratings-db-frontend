import React, { Component } from "react";
import { connect } from "react-redux";
import { Avatar, Popover } from "antd";
import { userSignOut } from "appRedux/actions/Auth";
import HttpService from "../../services/httpService";

class UserInfo extends Component {
  httpService;
  constructor() {
    super();
    this.httpService = new HttpService();
    this.state = {
      profile_pic: ''
    }
  }
  componentDidMount() {
    var ID = localStorage.getItem('user_id')
    this.httpService.post("user/list", { id: ID })
      .then(res => {
        if (res.status === 1) {
          console.log("res", res.data)
          this.setState({
            profile_pic: res.data[0].profile_pic,
          })
        } else {
          console.log("status = 0")
        }
      })
  }
  render() {
    const userMenuOptions = (
      <ul className="gx-user-popover">
        <a href="my_account"><li style={{ color: "black!important" }}>My Account</li></a>

        {/* <a href="my_account" style={{ color: "#4A3A8D" }}><li >My Account</li></a> */}

        {/* <li>Connections</li> */}
        <li onClick={() => this.props.userSignOut()}>Logout
        </li>
      </ul>
    );

    return (
      <Popover overlayClassName="gx-popover-horizantal" placement="bottomRight" content={userMenuOptions}
        trigger="click">
        <Avatar src={this.state.profile_pic}
          className="gx-avatar gx-pointer" alt="" />
      </Popover>
    )

  }
}

export default connect(null, { userSignOut })(UserInfo);
