import React from "react";
// import loader from "../../assets/images/loader.svg"
// import npci_small from "../../assets/images/NPCI-01.png"


const CircularProgress = ({className}) => <div className={`loader ${className}`}>
  {/* <img style = {{width : '1000px'}} src={npci_small} alt="loader"/> */}
  {/* <img alt = "" src = "https://yt3.ggpht.com/-chRurSaLtfc/AAAAAAAAAAI/AAAAAAAAAAA/Hm6r5mRH6io/s68-c-k-no-mo-rj-c0xffffff/photo.jpg"></img> */}
  
  {/* <img alt = "" src = "http://localhost/imdb_frontend/src/assets/images/imdb.svg"></img> */}
  
  {/* <img src = "https://www.npci.org.in/sites/default/files/npci-logo_0.png" width = "500" height = "200" /> */}
</div>;
export default CircularProgress;
