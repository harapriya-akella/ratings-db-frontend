// import axios from 'axios';

// export default axios.create({
//   baseURL: `http://g-axon.work/jwtauth/api/`,
//   headers: {
//     'Content-Type': 'application/json',
//   }
// });

import axios from 'axios';

export default axios.create({
  baseURL: `http://128.199.212.15:8001/`,
  // baseURL: `http://localhost:8001/`,
  headers: {
    'Content-Type': 'application/json',
  }
});
