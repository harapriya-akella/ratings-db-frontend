var date = new Date()
module.exports = {
  // footerText: 'Copyright Coense Solutions © ' + date.getFullYear(),
  footerText: '',
}
